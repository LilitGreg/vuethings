jQuery(document).ready(function (){

jQuery("#eng-lang").click(function(event){

  jQuery(".project-text-prod").addClass("hide");

  // jQuery(".project-text-prod  h2:nth-child(2)").removeClass("show");
  // jQuery(".project-text-prod  h2:nth-child(2)").addClass("hide");

    event.preventDefault();

})

 jQuery("#ru-lang").click(function(event){

   jQuery(".project-text-prod  h2:nth-child(2)").addClass("show");

   jQuery(".project-text-prod  h2:first-child").removeClass("show");
   jQuery(".project-text-prod  h2:first-child").addClass("hide");



     event.preventDefault();

 })




})
