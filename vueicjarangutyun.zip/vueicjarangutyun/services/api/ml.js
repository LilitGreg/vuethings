import Vue from 'vue'
import { MLInstaller, MLCreate, MLanguage } from 'vue-multilanguage'

Vue.use(MLInstaller)

export default new MLCreate({
  initial: 'english',
  save: process.env.NODE_ENV === 'production',
  languages: [
    new MLanguage('english').create({
      title: 'Hello {0}!',
      msg: 'You have {f} friends and {l} likes'
    }),

    new MLanguage('russion').create({
      title: 'Privet {0}!',
      msg: 'U tebya est {f} druzya {l} likes'
    })

    middleware: (component, path) => {
      const newPath = `${component.$options.name}.${path}`
      // you should return newPath
      return newPath
    }
  ]

})
