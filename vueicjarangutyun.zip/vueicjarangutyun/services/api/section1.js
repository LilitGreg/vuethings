import axios from 'axios'
const request = require('request');
//const OAuth   = require('oauth-1.0a');
const oauthSignature   = require('oauth-signature');
const crypto  = require('crypto');

export default {
  // getSection1Fields() {
  //   return axios.get('http://localhost/mug/wp-json/acf/v3/pages')
  //   .then(response => {
  //     return response;
  //   })
  // },
  // getSection1Fields() {
  //   return axios.get('http://localhost/mug/wp-json/acf/v3/pages').then(response=>{
  //    for(let project in response.data) {
  //      this.projects.push(response.data[project]);
  //    }
  // }, error=> {
  //   alert(error);
  // });
  // },
  // getSection1Fields() {
  //   return axios.get('http://localhost/mug/wp-json/acf/v3/pages').then(response=>{
  //      this.projects = response.data;
  //      console.log(projects);
  //    // for(let project in response.data) {
  //    //   this.projects.push(response.data[project]);
  //    // }
  // }, error=> {
  //   alert(error);
  // });
  // },


  getProductCategory(id){
    var httpMethod = 'GET';
    var timestamp=Math.round(Date.now()/1000);
    //var   url = 'http://localhost/mug/wp-json/wc/v3/products/';
    var url ='http://localhost/mugs/wp-json/wc/v3/products/?category='+ id;
    var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
    var parameters = {
          'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
          'oauth_nonce' : nonce,
          'oauth_timestamp' : timestamp,
          'oauth_signature_method' : 'HMAC-SHA1',
          'category' :id
      }
      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
     var string = 'OAuth ';
     for (var key in parameters) {
        if (parameters.hasOwnProperty(key)) {
            string += key + '=' + parameters[key] + ',';
        }
     }
    string += 'oauth_signature=' + signature ;

     return axios.get(url,
        { headers: {  'Authorization': string }  }
      ).then(response => {
       return response;
     });

  },



  getProductCategories(){
    var httpMethod = 'GET';
    var timestamp=Math.round(Date.now()/1000);
    //var   url = 'http://localhost/mug/wp-json/wc/v3/products/';
    var url ='http://localhost/mugs/wp-json/wc/v3/products/categories';
    var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
    var parameters = {
          'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
          'oauth_nonce' : nonce,
          'oauth_timestamp' : timestamp,
          'oauth_signature_method' : 'HMAC-SHA1',
          //'category' :id
      }
      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
     var string = 'OAuth ';
     for (var key in parameters) {
        if (parameters.hasOwnProperty(key)) {
            string += key + '=' + parameters[key] + ',';
        }
     }
    string += 'oauth_signature=' + signature ;

     return axios.get(url,
        { headers: {  'Authorization': string }  }
      ).then(response => {
       return response;
     });

  },




  getSectionWoocommproduct() {

   // return axios.get('http://localhost/mug/wp-json/wc/v3/products/'+id).then(response => {
   //   return product=response;
   // })
   // const oauth = OAuth({
   // consumer: {
   //   key: 'ck_c730f9e077e564101db07be014d8701187098d70',
   //   secret: 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1'
   // },
   // signature_method: 'HMAC-SHA256',
   // hash_function(base_string, key) {
   //   return CryptoJS.HmacSHA1(base_string, key).toString(CryptoJS.enc.Base64);
   // }
   //  });
   //  const request_data = {
   //   //url: 'http://localhost/mug/wc-auth/v1/authorize?oauth_consumer_key=ck_c730f9e077e564101db07be014d8701187098d70&oauth_timestamp=1551299844&oauth_nonce=5dvXe&oauth_signature_method=HMAC-SHA256',
   //   // url: 'http://localhost/mug/wc-auth/v1/authorize',
   //   url:'http://localhost/mug/wp-json/wc/v3/products'+id,
   //   method: 'GET',
   //   data: { status: 'Hello Ladies + Gentlemen, a signed OAuth request!' }
   // };
   //
   // $.ajax({
   //   url: request_data.url,
   //   type: request_data.method,
   //   data: request_data.data,
   //   headers: oauth.toHeader(oauth.authorize(request_data))
   // }).done(function(data) {
   //   // Process your data here
   // });

   // var httpMethod = 'GET';
   // var timestamp = Math.round(Date.now()/1000);
   // var url = 'http://dev.lam/wp-json/wc/v3/products';
   // var parameters = {
   //     'oauth_consumer_key' : 'ck_7e40491b1331dd64aedfb20c93081708f9c7963a',
   //     'oauth_nonce' : 'DFmdfi',
   //     'oauth_timestamp' : timestamp,
   //     'oauth_signature_method' : 'HMAC-SHA1'
   // };
   // var consumerSecret = 'cs_9f003ade307f11f9cb2a4e0630e3884bf6fb85ff';
   var httpMethod = 'GET';
   var timestamp=Math.round(Date.now()/1000);
   var   url = 'http://localhost/mugs/wp-json/wc/v3/products/';
   //var url ='http://localhost/mug/wp-json/wc/v3/products/categories';
   var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
   var parameters = {
         'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
         'oauth_nonce' : nonce,
         'oauth_timestamp' : timestamp,
         'oauth_signature_method' : 'HMAC-SHA1'
     }
     var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
     var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
    var string = 'OAuth ';
    for (var key in parameters) {
       if (parameters.hasOwnProperty(key)) {
           string += key + '=' + parameters[key] + ',';
       }
    }
   string += 'oauth_signature=' + signature ;
   // console.log(string);

   // return $.ajax({
   //         url: url,
   //         headers: {
   //             'Authorization':string
   //         },
   //         method: 'GET',
   //         // success: function(data){
   //         //     console.log('succes: '+data);
   //         // }
   //     });

   return axios.get(url,
      { headers: {  'Authorization': string }  }
    ).then(response => {
     return response;
   });

     //tokenSecret = 'pfkkdhi9sl3r4s00',
     // generates a RFC 3986 encoded, BASE64 encoded HMAC-SHA1 hash

     // var encodedSignature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);


    //
    // var  signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret,
    //    { encodeSignature: false});
     // generates a BASE64 encode HMAC-SHA1 hash
     //signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret,
         //{ encodeSignature: false});
         //console.log(encodedSignature);
         // console.log(encodedSignature);

     // var parameterscorr = {
     //     // ' Authorization': OAuth realm="http://localhost/mug/",
     //      //'Authorization': 'OAuth realm="http://localhost/mug' ,
     //      'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
     //      'oauth_signature_method' : 'HMAC-SHA256',
     //      'oauth_signature':encodedSignature,
     //      'oauth_timestamp' : timestamp,
     //      'oauth_nonce' : '1SqK3235U',
     //      'oauth_version' : '1.0'
     //  }
     // parameters.oauth_signature = encodedSignature;
     //  var parameterscorr = {
     //      // ' Authorization': OAuth realm="http://localhost/mug/",
     //       //'Authorization': 'OAuth realm="http://localhost/mug' ,
     //
     //         'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
     //           'oauth_nonce' : 'IY57n',
     //          'oauth_signature_method' : 'HMAC-SHA256',
     //          'oauth_timestamp' : timestamp,
     //          'oauth_version' : '1.0',
     //          'oauth_signature':encodedSignature
     //          // 'oauth_signature':'2SbAUMWe2LQwCXvM2mZ%2BCW40n9ZBfAdU7chqUgKEaHc%3D'
     //   }

      // var parameterscorr = {
      //     // ' Authorization': OAuth realm="http://localhost/mug/",
      //      'Authorization': OAuth realm="http://localhost/mug"  oauth_consumer_key = "ck_c730f9e077e564101db07be014d8701187098d70",oauth_signature_method = "HMAC-SHA256",oauth_signature= encodedSignature,oauth_timestamp = timestamp,oauth_nonce =  "1SqK3235U",oauth_version = "1.0"}
      //      // console.log(encodedSignature);
         ///console.log(encodedSignature+'hgjhgjgh');
           //console.log(encodedSignature);
          //  var urlone = Object.keys(parameters).map(function(k) {
          //     return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
          // }).join('&');
          //
          // console.log(urlone);
          // let urlParameters = Object.entries(parameters).map(e => e.join('=')).join('&');
          //
          // console.log(urlParameters);
          // let urlParameters = Object.entries(parameters).map(e => e.join('="')).join('",');
          // let urlParametersn = urlParameters + ' "';
          //  console.log(urlParametersn);
            // var urlown = 'http://localhost/mug/wp-json/wc/v3/products?'+parameters.stringify+'&oauth_signature='+encodedSignature;

           // var urlown = 'http://localhost/mug/wp-json/wc/v3/products?'+urlParameters+'&oauth_signature='+encodedSignature;
           // console.log(urlown);

           // var urlown = 'http://localhost/mug/wp-json/wc/v3/products?'+urlParameters+'&oauth_signature='+encodedSignature;

             // var urlown = 'http://localhost/mug/wp-json/wc/v3/products/'+id+"?"+urlParameters;


            // var urlown = 'http://localhost/mug/wp-json/wc/v3/products'+id;
            //   console.log(urlown);


          //  const oauth = OAuth({
          //    consumer: {
          //      key: 'ck_c730f9e077e564101db07be014d8701187098d70',
          //      secret: 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1'
          //    },
          //    signature_method: 'HMAC-SHA1',
          //    hash_function(base_string, key) {
          //      return CryptoJS.HmacSHA1(base_string, key).toString(CryptoJS.enc.Base64);
          //    }
          //  });
          //
          //  const request_data = {
          //   url: urlown,
          //   method: 'GET',
          //   data: { status: 'Hello Ladies + Gentlemen, a signed OAuth request!' }
          // };
          //  return axios.get(urlown, { headers: {  Authorization: 'OAuth '+urlParametersn }  }  ).then(response => {
          //   return response;
          // })
          //
          // $.ajax({
          //   url: request_data.url,
          //   type: request_data.method,
          //   data: request_data.data,
          //   headers: oauth.toHeader(oauth.authorize(request_data))
          // }).done(function(data) {
          //   // Process your data here
          // });
},
  getSectionField(id, field) {
    return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/' +id +"/"+field).then(response => {
      return response;
    })

  },

  getSectionFields() {
    return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/').then(response => {
      return response;
    })

  },

  // getSectionProductField(id, field) {
  //   return axios.get('http://localhost/mug/wp-json/acf/v3/pages/' +id+"/"+field).then(response => {
  //     return response;
  //   })
  //
  // },

  getSectionProductField(id, field) {
    return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/' +id+"/"+field).then(response => {
      return response;
    })

  },



  // getMap(query) {
  //   return axios.get('https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
  //     /' + query).then(response => {
  //     return response;
  //   })
  //
  // },
  totalcart(){
     ///
     var httpMethod = 'GET';
     var timestamp=Math.round(Date.now()/1000);
     var   url = 'http://localhost/mugs/wp-json/wc/v2/cart/totals';
     //var url ='http://localhost/mug/wp-json/wc/v3/products/categories';
     var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
     var parameters = {
           'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
           'oauth_nonce' : nonce,
           'oauth_timestamp' : timestamp,
           'oauth_signature_method' : 'HMAC-SHA1'
       }
       var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
       var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
      var string = 'OAuth ';
      for (var key in parameters) {
         if (parameters.hasOwnProperty(key)) {
             string += key + '=' + parameters[key] + ',';
         }
      }
     string += 'oauth_signature=' + signature ;

     return axios.get(url,
        { headers: {  'Authorization': string }  }
      ).then(response => {

       return response;
     });
  },


  viewcart(){

    var httpMethod = 'GET';
    var timestamp=Math.round(Date.now()/1000);
    var   url = 'http://localhost/mugs/wp-json/wc/v2/cart';
    //var url ='http://localhost/mug/wp-json/wc/v3/products/categories';
    var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
    var parameters = {
          'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
          'oauth_nonce' : nonce,
          'oauth_timestamp' : timestamp,
          'oauth_signature_method' : 'HMAC-SHA1'
      }
      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
     var string = 'OAuth ';
     for (var key in parameters) {
        if (parameters.hasOwnProperty(key)) {
            string += key + '=' + parameters[key] + ',';
        }
     }
    string += 'oauth_signature=' + signature ;

    return axios.get(url,
       { headers: {  'Authorization': string }  }
     ).then(response => {
      return response;
    });



  },
  // addtocart(product_id,quantity){
  //   var httpMethod = 'POST';
  //   var timestamp=Math.round(Date.now()/1000);
  //   var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
  //   var url ="http://localhost/mug/wp-json/wc/v2/cart/add/";
  //   var parameters = {
  //
  //         'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
  //         'oauth_nonce' : nonce,
  //         'oauth_timestamp' : timestamp,
  //         'oauth_signature_method' : 'HMAC-SHA1'
  //
  //     }
  //
  //     var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
  //     var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
  //
  //     var string = 'OAuth ';
  //     for (var key in parameters) {
  //        if (parameters.hasOwnProperty(key)) {
  //            string += key + '=' + parameters[key] + ',';
  //        }
  //     }
  //     string += 'oauth_signature=' + signature;
  //
  //       console.log("addddd");
  //
  //   return  axios.post(url,  {'product_id':product_id,'quantity':1},
  //        { headers: {  'Authorization': string }  }
  //      ).then(response => {
  //         // console.log("addddd");
  //        console.log(response);
  //       return response;
  //     });
  //
  //
  // },
  getfieldurl(){
  return axios.get("http://localhost/mugs/wp-json/acf/v3/pages/").then(response => {
  return  response;
})
}
}
