<template>
  <div id="prodtem" class="singleprod">

    <Header v-bind:carttable="carttable" />


    <div id="lang_sel_list" class="">
          <ul>
              <li class="icl-en" id="eng-lang">
                 <a href="#eng-lang"  v-on:click="changeenglish()"  class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/en.png" alt="en" title="English">&nbsp;
                 </a>
              </li>
                <li class="icl-ru" id="ru-lang">
                  <a href="#ru-lang"  v-on:click="changerussion()"   class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/ru.png" alt="ru" title="Русский">&nbsp;
                 </a>
              </li>
            </ul>
      </div>
    <!-- <div id="nav">
      <router-link to="/">Home</router-link>
    </div> -->
    <router-view/>
    <div class="products-content clearfix">



    <div v-for="project in projects" class="col-md-12 products-row  clearfix">


    <div  v-if="project.id == $route.params.id">
      <div class="row">


      <!-- <div  v-if="category.name  === project.name "> -->
        <!-- {{category.id}} -->
        <div class="col-md-6">
           <!-- <img :src="project.images[0].src" alt=""> width: 474.6px-->
            <div class="row">


           <hooper>
             <slide>
               <li style="">  <img  class="" v-if="project.images[1].src"  :src="project.images[1].src" alt=""> </li>
             </slide>
             <slide>
             <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li>
             </slide>

             <hooper-navigation slot="hooper-addons">  </hooper-navigation>

           </hooper>
             </div>


        </div>
         <div class="col-md-6 ">
            <div class="row project-text-prod">


             <h2>  {{project.name}} </h2>
             <h2 class="hide"> {{fields[project.id]}} </h2>
             <!-- <h2 class="hide"> {{fields[project.id]}} </h2> -->

               <p  id="descp" class="descp" v-html="project.description">    </p>

               <p class="descp1 hide">  {{fieldsd[project.id]}}  </p>


              <p> {{carttable.price}}: {{project.price}} $ </p>



            </div>


         </div>


      </div>
    </div>
  </div>




</div>




<div class="footer" id="prodfoot">


    <div class="formcontent" >

     <div class="text_wrapp col-md-6">
       <input name="add_email" id="add_email"  type="email"  v-model="emailsubscribe"  :placeholder="carttable.placeholder" required="">
     </div>

     <div class="bnt_wrapp col-md-6">
         <a href="#" v-on:click="addsubscribe(emailsubscribe)" class="btn"> {{carttable.subscribebut}}</a>

     </div>

   </div>


</div>


   </div>
  </div>
</div>
</template>
<script>


  import Header from '../components/Header';
   import router from '../router'
  import sectio1Api from '@/services/api/section1.js'
  import { Hooper, Slide, Navigation as HooperNavigation  } from 'hooper'
  import 'hooper/dist/hooper.css'
  import axios from 'axios'
    //  import jquery from 'jquery'
  const oauthSignature   = require('oauth-signature');


  export default {
    //name:'getSectionField',
    name:'getSectionWoocommproduct',
    components: {
     Header,
     Hooper,
     Slide,
      HooperNavigation

   },

    data() {
      return {
        products: [],
        //errors: [],
        loading:true,
        pages: [],
        obj:{},
        pageone:'',
        // hometextrus :' ',
        // homeback: '',
        // headerlogo: '',
        // headerslider1: ' ',
        // headertextsect2: '',
        // headertextsect2rus: '',
        // headertextsect2a: '',
        // headertextsect2aruss : '',

        // slider1logo1: '',
        // slider1logo2: '',
        // slider1logo3: ' ',
        // slider1logo4: ' ',
        // slider2logo1: ' ',
        // slider2logo2: ' ',
        // slider2logo3: ' ',
        // slider2logo4: ' ',
        // slider2text: ' ',
        // slider2textruss: ' ',
        // headertextsect2b: '',
        // headertextsect2bruss: '',
        // slider3logo1: ' ',
        // slider3logo2: ' ',
        // slider3logo3: ' ',
        // slider3logo4: ' ',
        // slider3text: ' ',
        // section3backimg: ' ',
        // section3img: ' ',
        // section3header: ' ',
        // section3headerruss: ' ',
        // section3text: ' ',
        // section3textruss: ' ',
        // section4backimg: ' ',
        // section4head: ' ',
        // section4headruss: ' ',
        // section4text: ' ',
        // section4textruss: ' ',
        // section5backimg: ' ',
        // section5header: ' ',
        // section5headerruss: ' ',
        // section5text: ' ',
        // section5textruss:' ',
        // section5img1: ' ',
        // section5img2: ' ',
        // section5img3: ' ',
        // section6header: ' ',
        // section6headerruss: ' ',
        // section6text: ' ',
        // section6textruss: ' ',
        // section6img: ' ',slider1: '', slider2: '',slider3: '',slider4: '',
        // imgleft1: ' ',imgleft2: ' ', imgright: ' ', section8header: ' ',section8headerruss: ' ',  section8text: ' ', section8textruss: ' ',
        // section9header: ' ',section9headerruss:' ',  section9lefttext: ' ', section9lefttextruss: ' ', section9righttext: ' ', section9righttextruss: ' ',

        sectionmap: ' ',maparam: ' ',
        product1: ' ',
        projects:[],
        fields:{},
        fieldsd:{},
        fieldscat: {},
        projectsa:[],
        categories:[],
        categoriespitzza:[],
        categoriesbarbecue:[],
        categoriesall:[],
        viewcarts:[],
        addtocarts:[],
        addtocarts2:[],
        addtocarts3:[],
        totalcarta:[],
        category1:'',
        category1russ:'',
        category2:'',
        category2russ:'',
        category3:'',
        category3russ:'',

        footertext: '',
        footertextruss: '',

        list: '',
        ip: "",

        // menu1: ' ',
        // menu1r: ' ',
        // menu2: ' ',
        // menu2r: ' ',
        // menu3: ' ',
        // menu3r: ' ',
        // menu4: ' ',
        // menu4r: ' ',
        // menu5: ' ',
        // menu5r: ' ',
        // menu5a: ' ',
        // menu5ar: ' ',
        // menu6: ' ',
        // menu6r: ' ',
        // menu7: ' ',
        // menu7r: ' ',
        // menu8: ' ',
        // menu8r: ' ',
        // menu9: ' ',
        // menu9r: ' ',
        // menu10: ' ',
        // menu10r: ' ',

        emailsubscribe: '',

        // firstname:'',
        // lastname:'',
        // billingaddress1: '',
        // billingaddress2: '',
        // billingcity: '',
        // billingcompany: '',
        // billingcountry: '',
        // billingemail: '',
        // billingphone: '',
        // billingpostcode: '',
        // billingcomments: '',
        // paymentmethod: ' ',

      //  quantityf: '',
      //  quantityf: 0,
          quantityf: [],

        methodpay: '',
        productstitles:[],
        producttitle: ' ',
        producttitle1: ' ',
        producttitle1a: [],
        errors: [],

          carttable : {
                 // delete:"Delete",
                 // thumbnail:"Thumbnail",
                 // product:"Product",
                 price: "Price",
                 // categoryname:"Category",
                 //  quantity: "Quantity",
                 //  subtotal: "Subtotal",
                 //  update: "Update",
                 //  totalcart:"Total Cart",
                 //  addtocart:"Add to Cart",
                  homemenu:"Home",
                    checkout:"Checkout",
                    products:"Products",
                    placeholder:"Enter your email here",
                    subscribebut: "Subscribe",

              },

          checkouttable : {
                 // billingdetail:"Billing Detail",
                 // firstname: "First Name",
                 // lastname:"Last Name",
                 // companyname:"Company Name",
                 // county:"Country",
                 // selectcountry:"Select Country",
                 // selectoption: "Select an option...",
                 // streetaddress: "Street address",
                 // apartment: "Apartment, suite, unit etc.",
                 // town: "Town / City",
                 // state:"State / County",
                 // postcode:"Postcode/ZIP",
                 // phone: "Phone",
                 // email:"Email Address",
                 // additionalgeneration: "Additional information",
                 // ordernotes: "Order notes (optional)",
                 // yourorder: "Your Order",
                 // total:"Total",
                 // basc:"Direct bank transfer",
                 // bascdesc:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
                 // cheque: "Check payments",
                 // chequedesc: "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
                 // cod: "Cash on delivery",
                 // coddesc: "Pay with cash upon delivery.",
                 // paypal:"Paypal",
                 // paypaldesc:"Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
                 // whatispaypal:"What is Paypal?",
                 // placeorder:"Place Order"
              },


      }
    },
      created:function() {
        return axios.get('http://localhost/mugs/wp-json/acf/v3/pages').then(response=>{
         for(let project in response.data) {
           this.projects.push(response.data[project]);
         }
       }, error=> {
        alert(error);
      });
    },

    methods:{


      changerussion : function() {
                  // this.carttable.delete = "Удалить";
                  // this.carttable.thumbnail= "Картина";
                  // this.carttable.product= "Товар";
                  this.carttable.price= "Чена";
                  this.carttable.placeholder= "Введите свой адрес э. почты",
                    this.carttable.subscribebut= "Подписываться",
                  // this.carttable.categoryname="Категория";
                  // this.carttable.quantity= "Количество";
                  // this.carttable.subtotal= "Подуровень";
                  // this.carttable.update= "Обновить";
                  // this.carttable.totalcart = "Общая Корзина",
                  // this.carttable.addtocart ="Добавить в Корзину",
                  // this.carttable.homemenu = "Главная",
                  // this.carttable.checkout = "Испытание",
                  //   this.carttable.products = "Товары",
                  // this.checkouttable.billingdetail="Платежная информация",
                  // this.checkouttable.firstname="Имя",
                  // this.checkouttable.lastname="Фамилия",
                  // this.checkouttable.companyname="Название Компании",
                  // this.checkouttable.county="Страна",
                  // this.checkouttable.selectcountry= "Выберите страну...",
                  // this.checkouttable.selectoption="Выберите опцию ...",
                  // this.checkouttable.streetaddress="Адрес улицы",
                  // this.checkouttable.apartment="Квартира, люкс, блок и т. Д.",
                  // this.checkouttable.town="Город",
                  // this.checkouttable.state="Штат / Страна",
                  // this.checkouttable.postcode="Почтовый индекс",
                  // this.checkouttable.phone="Телефон",
                  // this.checkouttable.email="Эл. адрес",
                  // this.checkouttable.additionalgeneration= "Дополнительная информация",
                  // this.checkouttable.ordernotes = "Примечания к заказу (необязательно)",
                  // this.checkouttable.yourorder ="Твоя очередь",
                  // this.checkouttable.total ="Сумма",
                  // this.checkouttable.basc= "Прямой банковский перевод",
                  // this.checkouttable.bascdesc= "Внесите платеж прямо на наш банковский счет. Пожалуйста, используйте ваш идентификатор заказа в качестве ссылки для оплаты. Ваш заказ не будет отправлен, пока средства не будут очищены на нашем счете.",
                  // this.checkouttable.cheque= "Проверить платежи",
                  // this.checkouttable.chequedesc= "Пожалуйста, отправьте чек в Название магазина, Улица магазина, Город магазина, Штат Штат / округ, Почтовый индекс магазина.",
                  // this.checkouttable.cod= "Оплата при доставке",
                  // this.checkouttable.coddesc= "Оплата наличными при доставке.",
                  // this.checkouttable.paypal= "Пайпал",
                  // this.checkouttable.paypaldesc= "Оплатить через Пайпал; Вы можете оплатить с помощью кредитной карты, если у вас нет учетной записи Пайпал.",
                  // this.checkouttable.whatispaypal= "Что такое Пайпал?",
                  // this.checkouttable.placeorder ="Разместить заказ",
                  jQuery("#ru-lang").click(function(event){
                      jQuery(".project-text-prod  h2:nth-child(2)").addClass("show");

                      jQuery(".project-text-prod  h2:first-child").removeClass("show");
                      jQuery(".project-text-prod  h2:first-child").addClass("hide");

                      jQuery(".project-text-prod  .descp1").addClass("show");

                      jQuery(".project-text-prod  .descp").removeClass("show");
                      jQuery(".project-text-prod   .descp").addClass("hide");



                        event.preventDefault();
                    })

              },
      changeenglish : function() {
            // this.carttable.delete = "Delete";
            // this.carttable.thumbnail= "Thumbnail";
            // this.carttable.product= "Product";
            this.carttable.price= "Price";
            this.carttable.placeholder= "Enter your email here",
              this.carttable.subscribebut= "Subscribe",
            // this.carttable.categoryname="Category";
            // this.carttable.quantity= "Quantity";
            // this.carttable.subtotal= "Subtotal";
            // this.carttable.update= "Update";
            // this.carttable.totalcart = "Total Cart",
            // this.carttable.addtocart ="Add to Cart",
            // this.carttable.homemenu = "Home",
            // this.carttable.checkout = "Checkout",
            //   this.carttable.products = "Products",
            // this.checkouttable.billingdetail="Billing Detail",
            // this.checkouttable.firstname="First Name",
            // this.checkouttable.lastname="Last Name",
            // this.checkouttable.companyname="Company Name",
            // this.checkouttable.county="Country",
            // this.checkouttable.selectcountry= "Select Country ...",
            // this.checkouttable.selectoption="Select an option ...",
            // this.checkouttable.streetaddress="Street address",
            // this.checkouttable.apartment="Apartment, suite, unit etc.",
            // this.checkouttable.town="Town / City",
            // this.checkouttable.state="State / County",
            // this.checkouttable.postcode="Postcode/ZIP",
            // this.checkouttable.phone="Phone",
            // this.checkouttable.email="Email Address",
            // this.checkouttable.additionalgeneration="Additional Information",
            // this.checkouttable.ordernotes ="Order notes (optional)",
            // this.checkouttable.yourorder ="Your Order"
            // this.checkouttable.total ="Total",
            // this.checkouttable.basc= "Direct bank transfer",
            // this.checkouttable.bascdesc= "Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
            // this.checkouttable.cheque= "Check payments",
            // this.checkouttable.chequedesc= "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
            // this.checkouttable.cod= "Cash on delivery",
            // this.checkouttable.coddesc= "Pay with cash upon delivery.",
            // this.checkouttable.paypal= "Paypal",
            // this.checkouttable.paypaldesc= "Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
            // this.checkouttable.whatispaypal= "What is Paypal?",
            // this.checkouttable.placeorder ="Place Order",
            jQuery("#eng-lang").click(function(event){
              jQuery(".project-text-prod  h2:first-child").addClass("show");

              jQuery(".project-text-prod  h2:nth-child(2)").removeClass("show");
              jQuery(".project-text-prod  h2:nth-child(2)").addClass("hide");


              jQuery(".project-text-prod  .descp").addClass("show");

              jQuery(".project-text-prod  .descp1").removeClass("show");
              jQuery(".project-text-prod   .descp1").addClass("hide");



                event.preventDefault();
            })

      },

      getSectionProductField:function(id, field) {
        return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/' +id+"/"+field).then(response => {
          return response;
        })
      },




      addsubscribe:function(add_email) {

        var url ="http://localhost/mugs/wp-json/subscription/v1/emailsub";
        var httpMethod = 'POST';



        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var parameters = {
              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'
          }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;
        console.log(string);

                console.log("I am email subscibe");

       /// return  axios.post(url,  {'add_email':add_email },


       return  axios.post(url,  {'add_email':add_email},
            { headers: {  'Authorization': string }  }
          ).then(response => {
            console.log(response);
           return response;
         });

       // return axios.get(url,
       //    { headers: {  'Authorization': string }  }
       //  ).then(response => {
       //      console.log("I am email subscibe1");
       //   return response;
       // });

        // return  axios.get(url,
        // { headers: {  'Authorization': string }  }
        //    ).then(response => {
        //
        //      console.log(response);
        //             console.log("I am email subscibe1");
        //
        //     return response;
        //   });

      },

    },
    mounted: function () {

      this.getSectionProductField(id, field);
      // this.addtocart(product_id, quantity);
      // this.updatecart(cart_item_key, quantity);
      // this.processpayment(order_id, payment_method);
      // this.processcheckout(billing_first_name,billing_last_name,billing_company,billing_country,billing_address_1,billing_address_2,billing_city,billing_postcode,billing_phone,billing_email,
      // order_comments,methodpay);
      // this.deletetocart(cart_item_key);

      this.addsubscribe(add_email);
      ///this.totalcart();
      // this.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
      //  })


    },

    computed: {
        iframeUrl: function (sectionmap) {
          // https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
          //   &q=1827 W Verdugo Ave
            return 'https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s&q={sectionmap}';
      }
    },

    mounted() {

      //console.log("from single mounted work first");
       //var str = "abc's test#s";
      /// document.getElementById("descp").replace(/[^a-zA-Z ]/g, "");
       /////console.log(descp);
       /////alert(descp.replace(/[^a-zA-Z ]/g, ""));
     // function preplace() {
     //  var descp = document.getElementById("descp").innerHTML;
     //  //var string = "<p>this is a test with <p class='bold'>multiple</p> p-tags.</p><span>THIS IS COOL</span>";
     //    var result = descp.replace(/<[\/]{0,1}(p)[^><]*>/ig,"");
     //
     //    console.log(result);
     //
     //  }
     //
     //  preplace();

        // jQuery(document).ready(function (){
        //
        //
        //   var desc;
        //
        //    desc = jQuery(".descp").html();
        //   console.log(desc);
        //
        //   console.log("from single mounted work");
        //
        //   // jQuery(".descp").each(function() {
        //   //     var text = $(this).text();
        //   //     console.log(text);
        //   //     $(this).text(text.replace('<p>', ''));
        //   // });
        //    //
        //
        //
        // // $(".descp").text(function(index, text) {
        // //     return text.replace('<p>', ' ');
        // //   });
        //
        // })

    },
    created() {

      // sectio1Api.getSectionWoocommproduct(12).then(product1=>{ this.product1=product1.data["name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      // sectio1Api.getSectionWoocommproduct().then(products=>{ this.products=products.data["name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      //  })
        // sectio1Api.getSectionWoocommproduct(12);
      sectio1Api.getProductCategory(16).then(categories=>{ this.categories=categories.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })
        sectio1Api.getProductCategory(17).then(categoriespitzza=>{ this.categoriespitzza=categoriespitzza.data}).catch(error => console.log(error)).finally(() => {this.loading = true
          })
       sectio1Api.getProductCategory(18).then(categoriesbarbecue=>{ this.categoriesbarbecue=categoriesbarbecue.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })


        sectio1Api.getProductCategories().then(categoriesall=>{ this.categoriesall=categoriesall.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })

          // sectio1Api.getSectionField(454, "category1").then(category1=>{ this.category1=category1.data["category1"];}).catch(error => console.log(error)).finally(() => {this.loading = true
          // })


       sectio1Api.getSectionWoocommproduct().then(projects=>{ this.projects=projects.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       })

              sectio1Api.getSectionWoocommproduct().then(async function(products){
                let data = products.data;
                var fields = {};
              for( let i = 0; i < data.length; i++){
                await sectio1Api.getSectionProductField((data[i]).id,"product-title-russ").then(async function(ttt){
                  fields[(data[i]).id] = await ttt.data["product-title-russ"];
                }).catch(error => console.log(error)).finally(() => {})
              }
              // console.log(fields)
              return fields;
            }).then(fields=>{ this.fields=fields}).catch(error => console.log(error)).finally(() => {this.loading = true
              })
       // sectio1Api.getSectionProductField(12,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       // })


       sectio1Api.getSectionWoocommproduct().then(async function(productsd){
         let data = productsd.data;
         var fieldsd = {};
       for( let i = 0; i < data.length; i++){
         await sectio1Api.getSectionProductField((data[i]).id,"product-description-russ").then(async function(bbb){
           fieldsd[(data[i]).id] = await bbb.data["product-description-russ"];
         }).catch(error => console.log(error)).finally(() => {})
       }

       // console.log(fieldsd)
       return fieldsd;
     }).then(fieldsd=>{ this.fieldsd=fieldsd}).catch(error => console.log(error)).finally(() => {this.loading = true
       })

       sectio1Api.getSectionProductField(179,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       })

      sectio1Api.getSectionField(473, "footer-text").then(footertext=>{ this.footertext=footertext.data["footer-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(473, "footer-text-russ").then(footertextruss=>{ this.footertextruss=footertextruss.data["footer-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(454, "category1russ").then(category1russ=>{ this.category1russ=category1russ.data["category1russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      // sectio1Api.getSectionField(454, "category2").then(category2=>{ this.category2=category2.data["category2"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(454, "category2russ").then(category2russ=>{ this.category2russ=category2russ.data["category2russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      // sectio1Api.getSectionField(454, "category3").then(category3=>{ this.category3=category3.data["category3"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(454, "category3russ").then(category3russ=>{ this.category3russ=category3russ.data["category3russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


    },}</script> <style lang="scss"> #app {font-family: 'Avenir', Helvetica, Arial, sans-serif;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;text-align: center;color: #2c3e50;}#nav {padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
