<template>
  <div class="about">

    <Header v-bind:carttable="carttable" />


    <div id="lang_sel_list" class="">
          <ul>
              <li class="icl-en" id="eng-lang">
                 <a href="#eng-lang"  v-on:click="changeenglish()"  class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/en.png" alt="en" title="English">&nbsp;
                 </a>
              </li>
                <li class="icl-ru" id="ru-lang">
                  <a href="#ru-lang"  v-on:click="changerussion()"   class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/ru.png" alt="ru" title="Русский">&nbsp;
                 </a>
              </li>
            </ul>
      </div>


    <div class="checkout-content clearfix">

        <!-- <a href="#" id="checkout-content"  class="" data-toggle="modal" data-target="#mymodalcheckout"> Checkout </a> -->
        <div class="content-cart  modals" id="mymodalcheckout"   >
        <article   id="post-18" class="post-18 page type-page status-publish hentry entry">
            <header class="entry-header">
            <!-- <h1 class="entry-title">Checkout</h1> -->
           </header>

          <div  class="cart-collaterals">
              <div class="cart_totals ">

              <div class="wc-proceed-to-checkout">


                  <button  v-on:click="processcheckout(firstname,lastname,billingcompany,billingcountry,billingaddress1,billingaddress2,billingcity,billingpostcode,billingphone,billingemail, billingcomments,methodpay)" type="submit" class="button alt" name="woocommerce_checkout_place_order" id="place_order" value="Place order" data-value="Place order"> {{this.checkouttable.placeorder}} </button>

              </div>
             </div>
          </div>

       <div class="entry-content">
        <div class="woocommerce"><div class="woocommerce-notices-wrapper"></div>

        <form class="checkout_coupon woocommerce-form-coupon" method="post" style="display:none">
          <p>If you have a coupon code, please apply it below.</p>
          <p class="form-row form-row-first">
            <input type="text" name="coupon_code" class="input-text" placeholder="Coupon code" id="coupon_code" value="">
          </p>
          <p class="form-row form-row-last">
            <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply coupon</button>
          </p>
          <div class="clear"></div>
        </form>
        <div class="woocommerce-notices-wrapper"></div>
        <form name="checkout" method="post" class="checkout woocommerce-checkout" action="http://localhost/mugs/checkout/" enctype="multipart/form-data" novalidate="novalidate">

          <p v-if="errors.length" class="errors">
            <p>Please correct the following error(s):</p>
            <ul>
              <li v-for="error in errors">{{ error }}</li>
            </ul>
          </p>

            <div class="col2-set" id="customer_details">

    <!--
              <button  v-on:click="processcheckout(firstname,lastname,billingcompany,billingcountry,billingaddress1,billingaddress2,billingcity,billingpostcode,billingphone,billingemail, billingcomments,methodpay)" type="submit" class="button alt" name="woocommerce_checkout_place_order" id="place_order" value="Place order" data-value="Place order">Place order</button> -->

              <div class="col-1">
                <div class="woocommerce-billing-fields">
                    <!-- <h3>Billing details</h3> -->
                    <h3> {{this.checkouttable.billingdetail}}</h3>

              <div class="woocommerce-billing-fields__field-wrapper row">
                <div class="col-md-6">

                  <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                    <label for="billing_first_name" class=""> {{this.checkouttable.firstname}} &nbsp;
                      <abbr class="required" title="required">*</abbr></label>
                      <span class="woocommerce-input-wrapper">
                        <input type="text" class="input-text " name="billing_first_name" id="billing_first_name" placeholder=""  v-model="firstname"  value="" autocomplete="given-name">
                      </span>
                    </p>
                      <p class="form-row form-row-last validate-required" id="billing_last_name_field" data-priority="20">
                        <label for="billing_last_name" class=""> {{this.checkouttable.lastname}} &nbsp;<abbr class="required" title="required">*</abbr></label>
                        <span class="woocommerce-input-wrapper">
                          <input type="text" class="input-text " name="billing_last_name" id="billing_last_name" placeholder="" v-model="lastname"  value="" autocomplete="family-name"></span></p>
                        <p class="form-row form-row-wide" id="billing_company_field" data-priority="30">
                          <label for="billing_company" class=""> {{this.checkouttable.companyname}} <span class="optional">(optional)</span></label>
                          <span class="woocommerce-input-wrapper">
                            <input type="text" class="input-text "  v-model="billingcompany"  name="billing_company" id="billing_company" placeholder=""   value="" autocomplete="organization"></span></p>
                          <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field" data-priority="40">
                            <label for="billing_country" class="">{{this.checkouttable.county}} &nbsp;<abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                              <select name="billing_country" v-model="billingcountry" id="billing_country" class="country_to_state country_select  select2-hidden-accessible" autocomplete="country" tabindex="-1" aria-hidden="true">
                                <option value="" selected="selected">   {{this.checkouttable.selectcountry}} </option>
                                <option value="AX">Åland Islands</option>
                                <option value="AF">Afghanistan</option>
                                <option value="AL">Albania</option>
                                <option value="DZ">Algeria</option>
                                <option value="AS">American Samoa</option>
                                <option value="AD">Andorra</option>
                                <option value="AO">Angola</option>
                                <option value="AI">Anguilla</option>
                                <option value="AQ">Antarctica</option>
                                <option value="AG">Antigua and Barbuda</option>
                                <option value="AR">Argentina</option>
                                <option value="AM">Armenia</option>
                                <option value="AW">Aruba</option>
                                <option value="AU">Australia</option>
                                <option value="AT">Austria</option>
                                <option value="AZ">Azerbaijan</option
                                  ><option value="BS">Bahamas</option>
                                  <option value="BH">Bahrain</option>
                                  <option value="BD">Bangladesh</option>
                                  <option value="BB">Barbados</option>
                                  <option value="BY">Belarus</option>
                                  <option value="PW">Belau</option>
                                  <option value="BE">Belgium</option>
                                  <option value="BZ">Belize</option>
                                  <option value="BJ">Benin</option>
                                  <option value="BM">Bermuda</option>
                                  <option value="BT">Bhutan</option>
                                  <option value="BO">Bolivia</option>
                                  <option value="BQ">Bonaire, Saint Eustatius and Saba</option>
                                  <option value="BA">Bosnia and Herzegovina</option>
                                  <option value="BW">Botswana</option><option value="BV">Bouvet Island</option>
                                  <option value="BR">Brazil</option><option value="IO">British Indian Ocean Territory</option>
                                  <option value="VG">British Virgin Islands</option><option value="BN">Brunei</option>
                                  <option value="BG">Bulgaria</option><option value="BF">Burkina Faso</option>
                                  <option value="BI">Burundi</option>
                                  <option value="KH">Cambodia</option>
                                  <option value="CM">Cameroon</option>
                                  <option value="CA">Canada</option>
                                  <option value="CV">Cape Verde</option><option value="KY">Cayman Islands</option>
                                  <option value="CF">Central African Republic</option>
                                  <option value="TD">Chad</option>
                                  <option value="CL">Chile</option>
                                  <option value="CN">China</option>
                                  <option value="CX">Christmas Island</option>
                                  <option value="CC">Cocos (Keeling) Islands</option>
                                  <option value="CO">Colombia</option><option value="KM">Comoros</option>
                                  <option value="CG">Congo (Brazzaville)</option>
                                  <option value="CD">Congo (Kinshasa)</option>
                                  <option value="CK">Cook Islands</option>
                                  <option value="CR">Costa Rica</option>
                                  <option value="HR">Croatia</option>
                                  <option value="CU">Cuba</option><option value="CW">Curaçao</option>
                                  <option value="CY">Cyprus</option><option value="CZ">Czech Republic</option>
                                  <option value="DK">Denmark</option><option value="DJ">Djibouti</option>
                                  <option value="DM">Dominica</option><option value="DO">Dominican Republic</option>
                                  <option value="EC">Ecuador</option><option value="EG">Egypt</option><option value="SV">El Salvador</option>
                                  <option value="GQ">Equatorial Guinea</option><option value="ER">Eritrea</option>
                                  <option value="EE">Estonia</option><option value="ET">Ethiopia</option><option value="FK">Falkland Islands</option><option value="FO">Faroe Islands</option><option value="FJ">Fiji</option><option value="FI">Finland</option><option value="FR">France</option><option value="GF">French Guiana</option><option value="PF">French Polynesia</option><option value="TF">French Southern Territories</option><option value="GA">Gabon</option><option value="GM">Gambia</option><option value="GE">Georgia</option><option value="DE">Germany</option><option value="GH">Ghana</option><option value="GI">Gibraltar</option><option value="GR">Greece</option><option value="GL">Greenland</option><option value="GD">Grenada</option><option value="GP">Guadeloupe</option><option value="GU">Guam</option><option value="GT">Guatemala</option><option value="GG">Guernsey</option><option value="GN">Guinea</option><option value="GW">Guinea-Bissau</option><option value="GY">Guyana</option><option value="HT">Haiti</option><option value="HM">Heard Island and McDonald Islands</option><option value="HN">Honduras</option><option value="HK">Hong Kong</option><option value="HU">Hungary</option><option value="IS">Iceland</option><option value="IN">India</option><option value="ID">Indonesia</option><option value="IR">Iran</option><option value="IQ">Iraq</option><option value="IE">Ireland</option><option value="IM">Isle of Man</option><option value="IL">Israel</option><option value="IT">Italy</option><option value="CI">Ivory Coast</option><option value="JM">Jamaica</option><option value="JP">Japan</option><option value="JE">Jersey</option><option value="JO">Jordan</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KI">Kiribati</option><option value="KW">Kuwait</option><option value="KG">Kyrgyzstan</option><option value="LA">Laos</option><option value="LV">Latvia</option><option value="LB">Lebanon</option><option value="LS">Lesotho</option><option value="LR">Liberia</option><option value="LY">Libya</option><option value="LI">Liechtenstein</option><option value="LT">Lithuania</option><option value="LU">Luxembourg</option><option value="MO">Macao S.A.R., China</option><option value="MK">Macedonia</option><option value="MG">Madagascar</option><option value="MW">Malawi</option><option value="MY">Malaysia</option><option value="MV">Maldives</option><option value="ML">Mali</option><option value="MT">Malta</option><option value="MH">Marshall Islands</option><option value="MQ">Martinique</option><option value="MR">Mauritania</option><option value="MU">Mauritius</option><option value="YT">Mayotte</option><option value="MX">Mexico</option><option value="FM">Micronesia</option><option value="MD">Moldova</option><option value="MC">Monaco</option><option value="MN">Mongolia</option><option value="ME">Montenegro</option><option value="MS">Montserrat</option><option value="MA">Morocco</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NA">Namibia</option><option value="NR">Nauru</option><option value="NP">Nepal</option><option value="NL">Netherlands</option><option value="NC">New Caledonia</option><option value="NZ">New Zealand</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nigeria</option><option value="NU">Niue</option><option value="NF">Norfolk Island</option><option value="KP">North Korea</option><option value="MP">Northern Mariana Islands</option><option value="NO">Norway</option><option value="OM">Oman</option><option value="PK">Pakistan</option><option value="PS">Palestinian Territory</option><option value="PA">Panama</option><option value="PG">Papua New Guinea</option><option value="PY">Paraguay</option><option value="PE">Peru</option><option value="PH">Philippines</option><option value="PN">Pitcairn</option><option value="PL">Poland</option><option value="PT">Portugal</option><option value="PR">Puerto Rico</option><option value="QA">Qatar</option><option value="RE">Reunion</option><option value="RO">Romania</option><option value="RU">Russia</option><option value="RW">Rwanda</option><option value="ST">São Tomé and Príncipe</option><option value="BL">Saint Barthélemy</option><option value="SH">Saint Helena</option><option value="KN">Saint Kitts and Nevis</option><option value="LC">Saint Lucia</option><option value="SX">Saint Martin (Dutch part)</option><option value="MF">Saint Martin (French part)</option><option value="PM">Saint Pierre and Miquelon</option><option value="VC">Saint Vincent and the Grenadines</option><option value="WS">Samoa</option><option value="SM">San Marino</option><option value="SA">Saudi Arabia</option><option value="SN">Senegal</option><option value="RS">Serbia</option><option value="SC">Seychelles</option><option value="SL">Sierra Leone</option><option value="SG">Singapore</option><option value="SK">Slovakia</option><option value="SI">Slovenia</option><option value="SB">Solomon Islands</option><option value="SO">Somalia</option><option value="ZA">South Africa</option><option value="GS">South Georgia/Sandwich Islands</option><option value="KR">South Korea</option><option value="SS">South Sudan</option><option value="ES">Spain</option><option value="LK">Sri Lanka</option><option value="SD">Sudan</option><option value="SR">Suriname</option><option value="SJ">Svalbard and Jan Mayen</option><option value="SZ">Swaziland</option><option value="SE">Sweden</option><option value="CH">Switzerland</option><option value="SY">Syria</option><option value="TW">Taiwan</option><option value="TJ">Tajikistan</option><option value="TZ">Tanzania</option><option value="TH">Thailand</option><option value="TL">Timor-Leste</option><option value="TG">Togo</option><option value="TK">Tokelau</option><option value="TO">Tonga</option><option value="TT">Trinidad and Tobago</option><option value="TN">Tunisia</option><option value="TR">Turkey</option><option value="TM">Turkmenistan</option><option value="TC">Turks and Caicos Islands</option><option value="TV">Tuvalu</option><option value="UG">Uganda</option><option value="UA">Ukraine</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom (UK)</option><option value="US">United States (US)</option><option value="UM">United States (US) Minor Outlying Islands</option><option value="VI">United States (US) Virgin Islands</option><option value="UY">Uruguay</option><option value="UZ">Uzbekistan</option><option value="VU">Vanuatu</option><option value="VA">Vatican</option><option value="VE">Venezuela</option><option value="VN">Vietnam</option><option value="WF">Wallis and Futuna</option><option value="EH">Western Sahara</option><option value="YE">Yemen</option><option value="ZM">Zambia</option>
                                  <option value="ZW">Zimbabwe</option></select>
                                  <span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;">
                                    <span class="selection"><span class="select2-selection select2-selection--single" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-billing_country-container" role="combobox">
                                      <span class="select2-selection__rendered" id="select2-billing_country-container" role="textbox" aria-readonly="true" title="Argentina"> </span>
                                      <span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span><noscript><button type="submit" name="woocommerce_checkout_update_totals" value="Update country">Update country</button></noscript></span></p>
                                      <p class="form-row form-row-wide address-field validate-required" id="billing_address_1_field" data-priority="50">
                                        <label for="billing_address_1" class="">  {{this.checkouttable.streetaddress}} &nbsp;<abbr class="required" title="required">*</abbr></label>
                                        <span class="woocommerce-input-wrapper">
                                          <input type="text" class="input-text"  v-model="billingaddress1"   name="billing_address_1" id="billing_address_1" placeholder="" value="" autocomplete="address-line1" data-placeholder="House number and street name"></span></p>

                                  </div>

                                  <div class="col-md-6">


                                    <p class="form-row form-row-wide address-field" id="billing_address_2_field" data-priority="60"><label for="billing_address_2" class="screen-reader-text">{{this.checkouttable.apartment}} &nbsp;<span class="optional">(optional)</span></label><span class="woocommerce-input-wrapper">
                                      <input type="text" class="input-text " name="billing_address_2" v-model="billingaddress2"  id="billing_address_2" placeholder="" value="" autocomplete="address-line2" data-placeholder="Apartment, suite, unit etc. (optional)"></span></p><p class="form-row form-row-wide address-field validate-required" id="billing_city_field" data-priority="70" data-o_class="form-row form-row-wide address-field validate-required">
                                        <label for="billing_city" class=""> {{this.checkouttable.town}} &nbsp;
                                        <abbr class="required" title="required">*</abbr></label><span class="woocommerce-input-wrapper">
                                        <input type="text" class="input-text " v-model="billingcity"  name="billing_city" id="billing_city" placeholder="" value="" autocomplete="address-level2"></span></p><p class="form-row form-row-wide address-field validate-required validate-state" id="billing_state_field" data-priority="80" data-o_class="form-row form-row-wide address-field validate-required validate-state">



                    <!-- <label for="billing_state" class=""> {{this.checkouttable.state}} &nbsp;<abbr class="required" title="required">*</abbr></label><span class="woocommerce-input-wrapper">
                      <select name="billing_state" id="billing_state" class="state_select  select2-hidden-accessible" autocomplete="address-level1" data-placeholder="" tabindex="-1" aria-hidden="true">
                    <option value="" selected="selected"> {{this.checkouttable.selectoption}} </option><option value="C">
                      Ciudad Autónoma de Buenos Aires</option>
                      <option value="B">Buenos Aires</option>
                      <option value="K">Catamarca</option>
                      <option value="H">Chaco</option>
                      <option value="U">Chubut</option>
                      <option value="X">Córdoba</option>
                      <option value="W">Corrientes</option>
                      <option value="E">Entre Ríos</option>
                      <option value="P">Formosa</option>
                      <option value="Y">Jujuy</option>
                      <option value="L">La Pampa</option>
                      <option value="F">La Rioja</option>
                      <option value="M">Mendoza</option>
                      <option value="N">Misiones</option>
                      <option value="Q">Neuquén</option>
                      <option value="R">Río Negro</option>
                      <option value="A">Salta</option>
                      <option value="J">San Juan</option>
                      <option value="D">San Luis</option>
                      <option value="Z">Santa Cruz</option>
                      <option value="S">Santa Fe</option>
                      <option value="G">Santiago del Estero</option>
                      <option value="V">Tierra del Fuego</option>
                      <option value="T">Tucumán</option>
                    </select> -->


                    <span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;">
                      <span class="selection"><span class="select2-selection select2-selection--single" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-billing_state-container" role="combobox">
                        <span class="select2-selection__rendered" id="select2-billing_state-container" role="textbox" aria-readonly="true" title="Santa Fe"> </span>
                        <span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span>
                        <span class="dropdown-wrapper" aria-hidden="true"></span></span></span></p>
                        <p class="form-row form-row-wide address-field validate-required validate-postcode" id="billing_postcode_field" data-priority="90" data-o_class="form-row form-row-wide address-field validate-required validate-postcode">
                          <label for="billing_postcode" class=""> {{this.checkouttable.postcode}} &nbsp;
                            <abbr class="required" title="required">*</abbr></label>
                            <span class="woocommerce-input-wrapper">
                              <input type="text" class="input-text " v-model ="billingpostcode" name="billing_postcode" id="billing_postcode" placeholder="" value="" autocomplete="postal-code"></span></p>
                              <p class="form-row form-row-wide validate-required validate-phone" id="billing_phone_field" data-priority="100">
                                <label for="billing_phone" class="">{{  this.checkouttable.phone }} &nbsp;<abbr class="required" title="required">*</abbr></label>
                                <span class="woocommerce-input-wrapper">
                                  <input type="tel" class="input-text"  v-model = "billingphone" name="billing_phone" id="billing_phone" placeholder="" value="" autocomplete="tel"></span></p>
                                <p class="form-row form-row-wide validate-required validate-email" id="billing_email_field" data-priority="110"><label for="billing_email" class="">  {{this.checkouttable.email}} &nbsp;<abbr class="required" title="required">*</abbr></label>
                                  <span class="woocommerce-input-wrapper">
                                    <input type="email" class="input-text "v-model="billingemail" name="billing_email" id="billing_email" placeholder="" value="" autocomplete="email username">
                                  </span>
                                </p>
                              </div>
                          </div>
                      </div>

                    </div>

                      <div class="col-2">
                        <div class="woocommerce-shipping-fields">
                         </div>
                          <div class="woocommerce-additional-fields">
                                <h3> {{this.checkouttable.additionalgeneration}}</h3>
                              <div class="woocommerce-additional-fields__field-wrapper">
                            <p class="form-row notes" id="order_comments_field" data-priority="">
                              <label for="order_comments" class="">{{this.checkouttable.ordernotes}} &nbsp; </label><span class="woocommerce-input-wrapper">
                              <textarea name="order_comments" class="input-text " v-model="billingcomments" id="order_comments" placeholder="" rows="2" cols="5"></textarea></span></p>					</div>

                            </div>
                      </div>
                    </div>
          <h3 id="order_review_heading"> {{this.checkouttable.yourorder}} </h3>
          <div id="order_review" class="woocommerce-checkout-review-order">
        <table   class="shop_table woocommerce-checkout-review-order-table">
          <thead>
            <tr>
              <th class="product-name"> {{this.carttable.product}} </th>
              <th class="product-total">{{this.checkouttable.total}}</th>
            </tr>
          </thead>
          <tbody>
        <tr  v-for="viewcart in viewcarts" class="cart_item">
          <td class="product-name">
             <!-- {{viewcart.product_name}} -->
             <div v-for="project in projects" class="checkout-product-name">
               <div  v-if="project.name ===viewcart.product_name">
                  <a href="#"> {{viewcart.product_name}} </a>
                  <a href="#" class="hide">  {{fields[project.id]}}    </a>
               </div>
             </div>
            <span class="product-quantity">× {{viewcart.quantity}} </span>
          </td>
          <td class="product-total">
            <span class="woocommerce-Price-amount amount">
              <span class="woocommerce-Price-currencySymbol">£</span> {{viewcart.line_total}}   </span>
          </td>
        </tr>


      </tbody>
      <tfoot>

        <tr  class="cart-subtotal">
          <!-- <th>Subtotal</th> -->
          <!-- <td><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>210.00</span></td> -->

        </tr>

        <!-- <tr  v-for="viewcart in viewcarts" class="order-total">
          <th>Total</th>
          <td><strong><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>   {{viewcart.line_total}} </span></strong> </td>
        </tr> -->

      </tfoot>
     </table>

     <div id="payment" class="woocommerce-checkout-payment">
       <!-- {{ methodpay }} -->
        <ul class="wc_payment_methods payment_methods methods">
          <li class="wc_payment_method payment_method_bacs">
          <input  v-model="methodpay" name="methodpay" v-bind:value="'bacs'"   id="payment_method_bacs" type="radio" class="input-radio"   data-order_button_text="">



          <label for="payment_method_bacs">   {{ this.checkouttable.basc }}	</label>
              <div class="payment_box payment_method_bacs">
              <p>
                 {{ this.checkouttable.bascdesc }}
              </p>
             </div>
          </li>
          <li class="wc_payment_method payment_method_cheque">
            <!-- v-model="methodpay" name="methodpay" v-bind:value="'cheque'" -->
            <input  v-model="methodpay" name="methodpay" v-bind:value="'cheque'"  id="payment_method_cheque" type="radio" class="input-radio"  data-order_button_text="">

            <label for="payment_method_cheque"> {{ this.checkouttable.cheque }}	 	</label>
                <div class="payment_box payment_method_cheque" >
                <p>
                  {{ this.checkouttable.chequedesc }}
                </p>
              </div>
            </li>
            <li class="wc_payment_method payment_method_cod">
              <!-- v-model="methodpay" name="methodpay" v-bind:value="'cod'" -->
              <input  v-model="methodpay" name="methodpay" v-bind:value="'cod'"  id="payment_method_cod" type="radio" class="input-radio"   data-order_button_text="">
              <label for="payment_method_cod">
                  {{ this.checkouttable.cod }}
               </label>
                  <div class="payment_box payment_method_cod" >
                  <p>  {{ this.checkouttable.coddesc }}</p>
                </div>
              </li>
            <li class="wc_payment_method payment_method_paypal">
              <!-- v-model="methodpay" name="methodpay" v-bind:value="'paypal'" -->
              <input v-model="methodpay" name="methodpay" v-bind:value="'paypal'"  id="payment_method_paypal" type="radio" class="input-radio"   data-order_button_text="Proceed to PayPal">

              <label for="payment_method_paypal">
                {{this.checkouttable.paypal}}
                <!-- <img src="https://www.paypalobjects.com/webstatic/mktg/Logo/AM_mc_vs_ms_ae_UK.png" alt="PayPal acceptance mark"> -->
                  <a href="https://www.paypal.com/gb/webapps/mpp/paypal-popup" class="about_paypal" onclick="javascript:window.open('https://www.paypal.com/gb/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;">
                    {{this.checkouttable.whatispaypal}}
                  </a>	</label>
                  <div class="payment_box payment_method_paypal">
                  <p>
                      {{this.checkouttable.paypaldesc}}
                  </p>
                </div>
              </li>
            </ul>
            <div class="form-row place-order">
            <noscript>
              Since your browser does not support JavaScript, or it is disabled, please ensure you click the <em>Update Totals</em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			<br/><button type="submit" class="button alt" name="woocommerce_checkout_update_totals" value="Update totals">Update totals</button>
            </noscript>



            <input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="0dcec4fc30"><input type="hidden" name="_wp_http_referer" value="/mug/?wc-ajax=update_order_review">	</div>

        </div>
          </div>
        </form>
        </div>

        <!-- <div class="wc-proceed-to-checkout">

            <button  v-on:click="processcheckout(firstname,lastname,billingcompany,billingcountry,billingaddress1,billingaddress2,billingcity,billingpostcode,billingphone,billingemail, billingcomments,methodpay)" type="submit" class="button alt" name="woocommerce_checkout_place_order" id="place_order" value="Place order" data-value="Place order">Place order</button>

        </div> -->
      </div><!-- .entry-content -->

      </article>
      </div>
    </div>



    <div class="footer" id="prodfoot">


      <div class="formcontent" >

       <div class="text_wrapp col-md-6">
         <input name="add_email" id="add_email"  type="email"  v-model="emailsubscribe"  :placeholder="carttable.placeholder" required="">
       </div>

       <div class="bnt_wrapp col-md-6">
           <a href="#" v-on:click="addsubscribe(emailsubscribe)" class="btn"> {{carttable.subscribebut}}</a>

       </div>

     </div>


    </div>

  </div>






</template>

<script>


import Header from '../components/Header';
import sectio1Api from '@/services/api/section1.js'
import { Hooper, Slide, Navigation as HooperNavigation  } from 'hooper'
import 'hooper/dist/hooper.css'
import axios from 'axios'
const oauthSignature   = require('oauth-signature');




export default {
  //name:'getSectionField',
  name:'checkout',
  components: {
    Header,
   Hooper,
   Slide,
    HooperNavigation

 },
 // props: [''],
  data() {
    return {
      products: [],
      //errors: [],
      loading:true,
      pages: [],
      obj:{},
      pageone:'',
      hometextrus :' ',
      homeback: '',
      headerlogo: '',
      headerslider1: ' ',
      headertextsect2: '',
      headertextsect2rus: '',
      headertextsect2a: '',
      headertextsect2aruss : '',

      slider1logo1: '',
      slider1logo2: '',
      slider1logo3: ' ',
      slider1logo4: ' ',
      slider2logo1: ' ',
      slider2logo2: ' ',
      slider2logo3: ' ',
      slider2logo4: ' ',
      slider2text: ' ',
      slider2textruss: ' ',
      headertextsect2b: '',
      headertextsect2bruss: '',
      slider3logo1: ' ',
      slider3logo2: ' ',
      slider3logo3: ' ',
      slider3logo4: ' ',
      slider3text: ' ',
      section3backimg: ' ',
      section3img: ' ',
      section3header: ' ',
      section3headerruss: ' ',
      section3text: ' ',
      section3textruss: ' ',
      section4backimg: ' ',
      section4head: ' ',
      section4headruss: ' ',
      section4text: ' ',
      section4textruss: ' ',
      section5backimg: ' ',
      section5header: ' ',
      section5headerruss: ' ',
      section5text: ' ',
      section5textruss:' ',
      section5img1: ' ',
      section5img2: ' ',
      section5img3: ' ',
      section6header: ' ',
      section6headerruss: ' ',
      section6text: ' ',
      section6textruss: ' ',
      section6img: ' ',slider1: '', slider2: '',slider3: '',slider4: '',
      imgleft1: ' ',imgleft2: ' ', imgright: ' ', section8header: ' ',section8headerruss: ' ',  section8text: ' ', section8textruss: ' ',
      section9header: ' ',section9headerruss:' ',  section9lefttext: ' ', section9lefttextruss: ' ', section9righttext: ' ', section9righttextruss: ' ', sectionmap: ' ',maparam: ' ',
      product1: ' ',
      projects:[],
      fields:{},
      fieldscat: {},
      projectsa:[],
      categories:[],
      categoriespitzza:[],
      categoriesbarbecue:[],
      categoriesall:[],
      viewcarts:[],
      addtocarts:[],
      addtocarts2:[],
      addtocarts3:[],
      totalcarta:[],
      category1:'',
      category1russ:'',
      category2:'',
      category2russ:'',
      category3:'',
      category3russ:'',

      footertext: '',
      footertextruss: '',

      list: '',
      ip: "",

      menu1: ' ',
      menu1r: ' ',
      menu2: ' ',
      menu2r: ' ',
      menu3: ' ',
      menu3r: ' ',
      menu4: ' ',
      menu4r: ' ',
      menu5: ' ',
      menu5r: ' ',
      menu5a: ' ',
      menu5ar: ' ',
      menu6: ' ',
      menu6r: ' ',
      menu7: ' ',
      menu7r: ' ',
      menu8: ' ',
      menu8r: ' ',
      menu9: ' ',
      menu9r: ' ',
      menu10: ' ',
      menu10r: ' ',

      emailsubscribe: '',

      firstname:'',
      lastname:'',
      billingaddress1: '',
      billingaddress2: '',
      billingcity: '',
      billingcompany: '',
      billingcountry: '',
      billingemail: '',
      billingphone: '',
      billingpostcode: '',
      billingcomments: '',
      paymentmethod: ' ',

    //  quantityf: '',
    //  quantityf: 0,
        quantityf: [],


      methodpay: '',
      productstitles:[],
      producttitle: ' ',
      producttitle1: ' ',
      producttitle1a: [],
      errors: [],

        carttable : {
               delete:"Delete",
               thumbnail:"Thumbnail",
               product:"Product",
               price: "Price",
                quantity: "Quantity",
                subtotal: "Subtotal",
                update: "Update",
                totalcart:"Total Cart",
                addtocart:"Add to Cart",
                homemenu:"Home",
                  checkout:"Checkout",
                  products:"Products",
                  placeholder:"Enter your email here",
                  subscribebut: "Subscribe",

            },

        checkouttable : {
               billingdetail:"Billing Detail",
               firstname: "First Name",
               lastname:"Last Name",
               companyname:"Company Name",
               county:"Country",
               selectcountry:"Select Country",
               selectoption: "Select an option...",
               streetaddress: "Street address",
               apartment: "Apartment, suite, unit etc.",
               town: "Town / City",
               state:"State / County",
               postcode:"Postcode/ZIP",
               phone: "Phone",
               email:"Email Address",
               additionalgeneration: "Additional information",
               ordernotes: "Order notes (optional)",
               yourorder: "Your Order",
               total:"Total",
               basc:"Direct bank transfer",
               bascdesc:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
               cheque: "Check payments",
               chequedesc: "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
               cod: "Cash on delivery",
               coddesc: "Pay with cash upon delivery.",
               paypal:"Paypal",
               paypaldesc:"Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
               whatispaypal:"What is Paypal?",
               placeorder:"Place Order"
            },

    }
  },
    created:function() {
      return axios.get('http://localhost/mugs/wp-json/acf/v3/pages').then(response=>{
       for(let project in response.data) {
         this.projects.push(response.data[project]);
       }
     }, error=> {
      alert(error);
    });
  },

  methods:{


    changerussion : function() {
                this.carttable.delete = "Удалить";
                this.carttable.thumbnail= "Картина";
                this.carttable.product= "Товар";
                this.carttable.price= "Чена";
                this.carttable.quantity= "Количество";
                this.carttable.subtotal= "Подуровень";
                this.carttable.update= "Обновить";
                this.carttable.totalcart = "Общая Корзина",
                this.carttable.addtocart ="Добавить в Корзину",
                this.carttable.placeholder= "Введите свой адрес э. почты",
                  this.carttable.subscribebut= "Подписываться",
                this.carttable.homemenu = "Главная",
                this.carttable.checkout = "Испытание",
                  this.carttable.products = "Товары",
                this.checkouttable.billingdetail="Платежная информация",
                this.checkouttable.firstname="Имя",
                this.checkouttable.lastname="Фамилия",
                this.checkouttable.companyname="Название Компании",
                this.checkouttable.county="Страна",
                this.checkouttable.selectcountry= "Выберите страну...",
                this.checkouttable.selectoption="Выберите опцию ...",
                this.checkouttable.streetaddress="Адрес улицы",
                this.checkouttable.apartment="Квартира, люкс, блок и т. Д.",
                this.checkouttable.town="Город",
                this.checkouttable.state="Штат / Страна",
                this.checkouttable.postcode="Почтовый индекс",
                this.checkouttable.phone="Телефон",
                this.checkouttable.email="Эл. адрес",
                this.checkouttable.additionalgeneration= "Дополнительная информация",
                this.checkouttable.ordernotes = "Примечания к заказу (необязательно)",
                this.checkouttable.yourorder ="Твоя очередь",
                this.checkouttable.total ="Сумма",
                this.checkouttable.basc= "Прямой банковский перевод",
                this.checkouttable.bascdesc= "Внесите платеж прямо на наш банковский счет. Пожалуйста, используйте ваш идентификатор заказа в качестве ссылки для оплаты. Ваш заказ не будет отправлен, пока средства не будут очищены на нашем счете.",
                this.checkouttable.cheque= "Проверить платежи",
                this.checkouttable.chequedesc= "Пожалуйста, отправьте чек в Название магазина, Улица магазина, Город магазина, Штат Штат / округ, Почтовый индекс магазина.",
                this.checkouttable.cod= "Оплата при доставке",
                this.checkouttable.coddesc= "Оплата наличными при доставке.",
                this.checkouttable.paypal= "Пайпал",
                this.checkouttable.paypaldesc= "Оплатить через Пайпал; Вы можете оплатить с помощью кредитной карты, если у вас нет учетной записи Пайпал.",
                this.checkouttable.whatispaypal= "Что такое Пайпал?",
                this.checkouttable.placeorder ="Разместить заказ",
                jQuery("#ru-lang").click(function(event){

                  jQuery(".checkout-product-name div a:nth-last-child(1)").addClass("show");
                  jQuery(".checkout-product-name div a:first-child").removeClass("show");
                  jQuery(".checkout-product-name div a:first-child").addClass("hide");

                })

            },
    changeenglish : function() {
          this.carttable.delete = "Delete";
          this.carttable.thumbnail= "Thumbnail";
          this.carttable.product= "Product";
          this.carttable.price= "Price";
          this.carttable.quantity= "Quantity";
          this.carttable.subtotal= "Subtotal";
          this.carttable.update= "Update";
          this.carttable.totalcart = "Total Cart",
          this.carttable.placeholder= "Enter your email here",
            this.carttable.subscribebut= "Subscribe",
          this.carttable.homemenu = "Home",
          this.carttable.checkout = "Checkout",
            this.carttable.products = "Products",
          this.carttable.addtocart ="Add to Cart",
          this.checkouttable.billingdetail="Billing Detail",
          this.checkouttable.firstname="First Name",
          this.checkouttable.lastname="Last Name",
          this.checkouttable.companyname="Company Name",
          this.checkouttable.county="Country",
          this.checkouttable.selectcountry= "Select Country ...",
          this.checkouttable.selectoption="Select an option ...",
          this.checkouttable.streetaddress="Street address",
          this.checkouttable.apartment="Apartment, suite, unit etc.",
          this.checkouttable.town="Town / City",
          this.checkouttable.state="State / County",
          this.checkouttable.postcode="Postcode/ZIP",
          this.checkouttable.phone="Phone",
          this.checkouttable.email="Email Address",
          this.checkouttable.additionalgeneration="Additional Information",
          this.checkouttable.ordernotes ="Order notes (optional)",
          this.checkouttable.yourorder ="Your Order"
          this.checkouttable.total ="Total",
          this.checkouttable.basc= "Direct bank transfer",
          this.checkouttable.bascdesc= "Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
          this.checkouttable.cheque= "Check payments",
          this.checkouttable.chequedesc= "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
          this.checkouttable.cod= "Cash on delivery",
          this.checkouttable.coddesc= "Pay with cash upon delivery.",
          this.checkouttable.paypal= "Paypal",
          this.checkouttable.paypaldesc= "Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
          this.checkouttable.whatispaypal= "What is Paypal?",
          this.checkouttable.placeorder ="Place Order",

          jQuery("#eng-lang").click(function(event){
            jQuery(".checkout-product-name div a:first-child").addClass("show");
            jQuery(".checkout-product-name div a:nth-last-child(1)").removeClass("show");
            jQuery(".checkout-product-name div a:nth-last-child(1)").addClass("hide");

          })

    },

    getSectionProductField:function(id, field) {
      return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/' +id+"/"+field).then(response => {
        return response;
      })
    },

    addtocart:function(product_id, quantity) {
      //console.log("adddcarteli");
      var httpMethod = 'POST';
      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var url ="http://localhost/mugs/wp-json/wc/v2/cart/add/";
      var parameters = {

            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'

        }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;

          //console.log("addddd");

      return  axios.post(url,  {'product_id':product_id,'quantity':1},
           { headers: {  'Authorization': string }  }
         ).then(response => {
            // console.log("addddd");
            //comm
            sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
            });

           console.log(response);
          return response;
        });

    },

    updatecart:function(cart_item_key, quantity) {
      //console.log("adddcarteli");
      var httpMethod = 'POST';
      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var url ="http://localhost/mugs/wp-json/wc/v2/cart/cart-item/";
      var parameters = {

            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'

        }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;

          //console.log("addddd");

      return  axios.post(url,  {'cart_item_key':cart_item_key,'quantity':quantity},
           { headers: {  'Authorization': string }  }
         ).then(response => {
            // console.log("addddd");

            ////commm
            sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
            });

           console.log(response);
          return response;
        });

    },



   viewcart:function() {

      var httpMethod = 'GET';
      var timestamp=Math.round(Date.now()/1000);
      var   url = 'http://localhost/mugs/wp-json/wc/v2/cart';
      //var url ='http://localhost/mugs/wp-json/wc/v3/products/categories';
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var parameters = {
            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'
        }
        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
       var string = 'OAuth ';
       for (var key in parameters) {
          if (parameters.hasOwnProperty(key)) {
              string += key + '=' + parameters[key] + ',';
          }
       }
      string += 'oauth_signature=' + signature ;

      return axios.get(url,
         { headers: {  'Authorization': string }  }
       ).then(response => {
        return response;
      });



    },

    deletetocart:function(cart_item_key) {
      console.log("deletecarteli");
      var httpMethod = 'DELETE';
      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var url ="http://localhost/mugs/wp-json/wc/v2/cart/cart-item/";
      var parameters = {
            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'
        }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;


        console.log(string);

          //console.log("addddd");

      // return  axios.delete(url, { headers: {  'Authorization': string }  }, {data:{'cart_item_key':cart_item_key}}
        return  axios.delete(url,  {data:{'cart_item_key':cart_item_key}, headers: {  'Authorization': string }}
         ).then(response => {
           ///commm
           sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
           });
            // console.log("addddd");
           console.log(response);
          return response;
        });

    },

    totalcart:function(){
       ///
       var httpMethod = 'GET';
       var timestamp=Math.round(Date.now()/1000);
       var   url = 'http://localhost/mugs/wp-json/wc/v2/cart/totals';
       //var url ='http://localhost/mugs/wp-json/wc/v3/products/categories';
       var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
       var parameters = {
             'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
             'oauth_nonce' : nonce,
             'oauth_timestamp' : timestamp,
             'oauth_signature_method' : 'HMAC-SHA1'
         }
         var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
         var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
       string += 'oauth_signature=' + signature ;

       return axios.get(url,
          { headers: {  'Authorization': string }  }
        ).then(response => {

          sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
          });
          // sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
          // });
         return response;
       });
    },


    processpayment:function(order_id, payment_method) {
      console.log("I am process payment");

      var url ="http://localhost/mugs/wp-json/wc/v2/process_payment/";
      var httpMethod = 'POST';
      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var parameters = {
            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'
        }

      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

      var string = 'OAuth ';
      for (var key in parameters) {
         if (parameters.hasOwnProperty(key)) {
             string += key + '=' + parameters[key] + ',';
         }
      }
      string += 'oauth_signature=' + signature;

      return  axios.post(url,  {'order_id':order_id,'payment_method':payment_method},
           { headers: {  'Authorization': string }  }
         ).then(response => {
           console.log("chigalissspaymentaddddd");

           console.log(response);
           sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
            });
          return response;
        });


    },
    processcheckout:function(billing_first_name,billing_last_name,billing_company,billing_country,billing_address_1,billing_address_2,billing_city,billing_postcode,billing_phone,billing_email,
    order_comments,methodpay) {
      console.log("I am process checkout");

      var url ="http://localhost/mugs/wp-json/wc/v2/cart/process_checkout_wc/";
      var httpMethod = 'POST';
      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var parameters = {
            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'
        }

      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

      var string = 'OAuth ';
      for (var key in parameters) {
         if (parameters.hasOwnProperty(key)) {
             string += key + '=' + parameters[key] + ',';
         }
      }
      string += 'oauth_signature=' + signature;



      return  axios.post(url,  {'billing_first_name':billing_first_name,'billing_last_name':billing_last_name,
        'billing_company':billing_company, 'billing_country':billing_country, 'billing_address_1':billing_address_1, 'billing_address_2':billing_address_2,
        'billing_city':billing_city, 'billing_postcode':billing_postcode, 'billing_phone':billing_phone, 'billing_email':billing_email,
        'order_comments':order_comments,'methodpay':methodpay },
           { headers: {  'Authorization': string }  }
         ).then(response => {
           //console.log("chigalissspaymentaddddd");
           console.log(response);
           this.processpayment( response.data, methodpay);
           sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
           });
          return response;
        });

    },

    addsubscribe:function(add_email) {

      var url ="http://localhost/mugs/wp-json/subscription/v1/emailsub";
      var httpMethod = 'POST';



      var timestamp=Math.round(Date.now()/1000);
      var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
      var parameters = {
            'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
            'oauth_nonce' : nonce,
            'oauth_timestamp' : timestamp,
            'oauth_signature_method' : 'HMAC-SHA1'
        }

      var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
      var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

      var string = 'OAuth ';
      for (var key in parameters) {
         if (parameters.hasOwnProperty(key)) {
             string += key + '=' + parameters[key] + ',';
         }
      }
      string += 'oauth_signature=' + signature;
      console.log(string);

              console.log("I am email subscibe");

     /// return  axios.post(url,  {'add_email':add_email },


     return  axios.post(url,  {'add_email':add_email},
          { headers: {  'Authorization': string }  }
        ).then(response => {
          console.log(response);
         return response;
       });

     // return axios.get(url,
     //    { headers: {  'Authorization': string }  }
     //  ).then(response => {
     //      console.log("I am email subscibe1");
     //   return response;
     // });

      // return  axios.get(url,
      // { headers: {  'Authorization': string }  }
      //    ).then(response => {
      //
      //      console.log(response);
      //             console.log("I am email subscibe1");
      //
      //     return response;
      //   });

    },


  },
  mounted: function () {
    // this.getCart();
    //this.total();
    this.getSectionProductField(id, field);
    this.addtocart(product_id, quantity);
    this.updatecart(cart_item_key, quantity);
    this.processpayment(order_id, payment_method);
    this.processcheckout(billing_first_name,billing_last_name,billing_company,billing_country,billing_address_1,billing_address_2,billing_city,billing_postcode,billing_phone,billing_email,
    order_comments,methodpay);
    this.deletetocart(cart_item_key);

    this.addsubscribe(add_email);
    ///this.totalcart();
    // this.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
    //  })


  },

  computed: {
      iframeUrl: function (sectionmap) {
        // https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
        //   &q=1827 W Verdugo Ave
          return 'https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s&q={sectionmap}';
    }
  },

  mounted() {
        // axios({ method: "GET", "url": "https://httpbin.org/ip" }).then(result => {
        //     this.ip = result.data.origin;
        //     //console.log(ip);
        // }, error => {
        //     console.error(error);
        // });
  },
  created() {

    // sectio1Api.getProductCategory(16).then(categories=>{ this.categories=categories.data}).catch(error => console.log(error)).finally(() => {this.loading = true
    //   })
    //   sectio1Api.getProductCategory(17).then(categoriespitzza=>{ this.categoriespitzza=categoriespitzza.data}).catch(error => console.log(error)).finally(() => {this.loading = true
    //     })
    //  sectio1Api.getProductCategory(18).then(categoriesbarbecue=>{ this.categoriesbarbecue=categoriesbarbecue.data}).catch(error => console.log(error)).finally(() => {this.loading = true
    //   })
    //
    //
    //   sectio1Api.getProductCategories().then(categoriesall=>{ this.categoriesall=categoriesall.data}).catch(error => console.log(error)).finally(() => {this.loading = true
    //   })


     sectio1Api.getSectionWoocommproduct().then(projects=>{ this.projects=projects.data}).catch(error => console.log(error)).finally(() => {this.loading = true
     })

            sectio1Api.getSectionWoocommproduct().then(async function(products){
              let data = products.data;
              var fields = {};
            for( let i = 0; i < data.length; i++){
              await sectio1Api.getSectionProductField((data[i]).id,"product-title-russ").then(async function(ttt){
                fields[(data[i]).id] = await ttt.data["product-title-russ"];
              }).catch(error => console.log(error)).finally(() => {})
            }
            console.log(fields)
            return fields;
          }).then(fields=>{ this.fields=fields}).catch(error => console.log(error)).finally(() => {this.loading = true
            })
     // sectio1Api.getSectionProductField(12,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
     // })

     sectio1Api.getSectionProductField(179,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
     })


  sectio1Api.totalcart().then(totalcarta=>{ this.totalcarta = totalcarta.data

     }).catch(error => console.log(error)).finally(() => {this.loading = true
  })



    sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
     })


    // sectio1Api.getSectionField(72, "menu-item-name").then(menu1=>{ this.menu1=menu1.data["menu-item-name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(72, "menu-item-name-russ").then(menu1r=>{ this.menu1r=menu1r.data["menu-item-name-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(72, "home-text").then(pageone=>{ this.pageone=pageone.data["home-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(72, "home-text-rus").then(hometextrus=>{ this.hometextrus=hometextrus.data["home-text-rus"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //


    // sectio1Api.getSectionField(72, "home-back-image").then(homeback=>{ this.homeback=homeback.data["home-back-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })


    // sectio1Api.getSectionField(75, "menu-item2").then(menu2=>{ this.menu2=menu2.data["menu-item2"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75, "menu-item2-russ").then(menu2r=>{ this.menu2r=menu2r.data["menu-item2-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(75, "slider1-header").then(headerlogo=>{ this.headerlogo=headerlogo.data["slider1-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75, "slider1-header-russ").then(headerslider1=>{ this.headerslider1=headerslider1.data["slider1-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(75, "slider-1-logo-1").then(slider1logo1=>{ this.slider1logo1=slider1logo1.data["slider-1-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-1-logo-2").then(slider1logo2=>{ this.slider1logo2=slider1logo2.data["slider-1-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-1-logo-3").then(slider1logo3=>{ this.slider1logo3=slider1logo3.data["slider-1-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-1-logo-4").then(slider1logo4=>{ this.slider1logo4=slider1logo4.data["slider-1-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
    // sectio1Api.getSectionField(75 , 'slider-1-text').then(headertextsect2=>{ this.headertextsect2=headertextsect2.data["slider-1-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75 , 'slider-1-text-russ').then(headertextsect2rus=>{ this.headertextsect2rus=headertextsect2rus.data["slider-1-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75 , 'slider2-header').then(headertextsect2a=>{ this.headertextsect2a=headertextsect2a.data["slider2-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75 , 'slider2-header-russ').then(headertextsect2aruss=>{ this.headertextsect2aruss=headertextsect2aruss.data["slider2-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(75, "slider-2-logo-1").then(slider2logo1=>{ this.slider2logo1=slider2logo1.data["slider-2-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-2-logo-2")
    // .then(slider2logo2=>{ this.slider2logo2=slider2logo2.data["slider-2-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-2-logo-3").then(slider2logo3=>{ this.slider2logo3=slider2logo3.data["slider-2-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-2-logo-4").then(slider2logo4=>{ this.slider2logo4=slider2logo4.data["slider-2-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
    // sectio1Api.getSectionField(75, "slider-2-text")
    // .then(slider2text=>{ this.slider2text=slider2text.data["slider-2-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(75, "slider-2-text-russ")
    // .then(slider2textruss=>{ this.slider2textruss=slider2textruss.data["slider-2-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(75 , 'slider3-header')
    // .then(headertextsect2b=>{ this.headertextsect2b=headertextsect2b.data["slider3-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    //
    // sectio1Api.getSectionField(75 , 'slider3-header-russ')
    // .then(headertextsect2bruss=>{ this.headertextsect2bruss=headertextsect2bruss.data["slider3-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-logo-1").then(slider3logo1=>{ this.slider3logo1=slider3logo1.data["slider-3-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-logo-2")
    // .then(slider3logo2=>{ this.slider3logo2=slider3logo2.data["slider-3-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-logo-3")
    // .then(slider3logo3=>{ this.slider3logo3=slider3logo3.data["slider-3-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-logo-4")
    // .then(slider3logo4=>{ this.slider3logo4=slider3logo4.data["slider-3-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-text")
    // .then(slider3text=>{ this.slider3text=slider3text.data["slider-3-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(75, "slider-3-text-russ")
    // .then(slider3textruss=>{ this.slider3textruss=slider3textruss.data["slider-3-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(80, "menu-item3").then(menu3=>{ this.menu3=menu3.data["menu-item3"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(80, "menu-item3-russ").then(menu3r=>{ this.menu3r=menu3r.data["menu-item3-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })


    sectio1Api.getSectionField(473, "footer-text").then(footertext=>{ this.footertext=footertext.data["footer-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    })

    sectio1Api.getSectionField(473, "footer-text-russ").then(footertextruss=>{ this.footertextruss=footertextruss.data["footer-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    })


    // sectio1Api.getSectionField(80, "back-image")
    // .then(section3backimg=>{ this.section3backimg=section3backimg.data["back-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(80, "section3-image")
    // .then(section3img=>{ this.section3img=section3img.data["section3-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(80, "section3-header")
    // .then(section3header=>{ this.section3header=section3header.data["section3-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(80, "section3-header-russ")
    // .then(section3headerruss=>{ this.section3headerruss=section3headerruss.data["section3-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(80, "section3-text")
    // .then(section3text=>{ this.section3text=section3text.data["section3-text"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(80, "section3-text-russ")
    // .then(section3textruss=>{ this.section3textruss=section3textruss.data["section3-text-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })

    // sectio1Api.getSectionField(91, "menu-item4").then(menu4=>{ this.menu4=menu4.data["menu-item4"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(91, "menu-item4-russ").then(menu4r=>{ this.menu4r=menu4r.data["menu-item4-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(91, "section4-back-img")
    // .then(section4backimg=>{ this.section4backimg=section4backimg.data["section4-back-img"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(91, "section4-header")
    // .then(section4head=>{ this.section4head=section4head.data["section4-header"];})
    // .catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(91, "section4-header-russ")
    // .then(section4headruss=>{ this.section4headruss=section4headruss.data["section4-header-russ"];})
    // .catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(91, "section4-text")
    // .then(section4text=>{ this.section4text=section4text.data["section4-text"];})
    // .catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(91, "section4-text-russ")
    // .then(section4textruss=>{ this.section4textruss=section4textruss.data["section4-text-russ"];})
    // .catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(95, "menu-item5").then(menu5=>{ this.menu5=menu5.data["menu-item5"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    //
    // sectio1Api.getSectionField(95, "menu-item5-russ").then(menu5r=>{ this.menu5r=menu5r.data["menu-item5-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(95, "section5-back-img")
    // .then(section5backimg=>{ this.section5backimg=section5backimg.data["section5-back-img"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-header")
    // .then(section5header=>{ this.section5header=section5header.data["section5-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-header-russ")
    // .then(section5headerruss=>{ this.section5headerruss=section5headerruss.data["section5-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-text")
    // .then(section5text=>{ this.section5text=section5text.data["section5-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-text-russ")
    // .then(section5textruss=>{ this.section5textruss=section5textruss.data["section5-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-img-1")
    // .then(section5img1=>{ this.section5img1=section5img1.data["section5-img-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(95, "section5-img-2")
    // .then(section5img2=>{ this.section5img2=section5img2.data["section5-img-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
    // sectio1Api.getSectionField(95, "section5-img-3")
    // .then(section5img3=>{ this.section5img3=section5img3.data["section5-img-3"]["url"];}).catch(error => console.log(error))
    // .finally(() => {
    //   this.loading = true
    // })



    // sectio1Api.getSectionField(454, "menu-item5a").then(menu5a=>{ this.menu5a=menu5a.data["menu-item5a"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    // sectio1Api.getSectionField(454, "menu-item5a-russ").then(menu5ar=>{ this.menu5ar=menu5ar.data["menu-item5a-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })

    // sectio1Api.getSectionField(454, "category1").then(category1=>{ this.category1=category1.data["category1"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    sectio1Api.getSectionField(454, "category1russ").then(category1russ=>{ this.category1russ=category1russ.data["category1russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    })

    // sectio1Api.getSectionField(454, "category2").then(category2=>{ this.category2=category2.data["category2"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    sectio1Api.getSectionField(454, "category2russ").then(category2russ=>{ this.category2russ=category2russ.data["category2russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    })

    // sectio1Api.getSectionField(454, "category3").then(category3=>{ this.category3=category3.data["category3"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    // })
    sectio1Api.getSectionField(454, "category3russ").then(category3russ=>{ this.category3russ=category3russ.data["category3russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
    })



    // sectio1Api.getSectionField(99, "menu-item6")
    // .then(menu6=>{ this.menu6=menu6.data["menu-item6"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(99, "menu-item6-russ")
    // .then(menu6r=>{ this.menu6r=menu6r.data["menu-item6-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })

    // sectio1Api.getSectionField(99, "section6-header")
    // .then(section6header=>{ this.section6header=section6header.data["section6-header"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(99, "section6-header-russ")
    // .then(section6headerruss=>{ this.section6headerruss=section6headerruss.data["section6-header-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(99, "section6-text")
    // .then(section6text=>{ this.section6text=section6text.data["section6-text"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(99, "section6-text-russ")
    // .then(section6textruss=>{ this.section6textruss=section6textruss.data["section6-text-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(99, "section6-img")
    // .then(section6img=>{ this.section6img=section6img.data["section6-img"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })

    // sectio1Api.getSectionField(102, "menu-item7")
    // .then(menu7=>{ this.menu7=menu7.data["menu-item7"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(102, "menu-item7-russ")
    // .then(menu7r=>{ this.menu7r=menu7r.data["menu-item7-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(102, "slider1")
    // .then(slider1=>{ this.slider1=slider1.data["slider1"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(102, "slider2")
    // .then(slider2=>{ this.slider2=slider2.data["slider2"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(102, "slider3").then(slider3=>{ this.slider3=slider3.data["slider3"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(102, "slider4")
    // .then(slider4=>{ this.slider4=slider4.data["slider4"]["url"];}).catch(error => console.log(error))
    // .finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(105, "menu-item8")
    // .then(menu8=>{ this.menu8=menu8.data["menu-item8"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(105, "menu-item8-russ")
    // .then(menu8r=>{ this.menu8r=menu8r.data["menu-item8-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })

    // sectio1Api.getSectionField(105, "image-left1")
    // .then(imgleft1=>{ this.imgleft1=imgleft1.data["image-left1"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "image-left2")
    // .then(imgleft2=>{ this.imgleft2=imgleft2.data["image-left2"]["url"];}).catch(error => console.log(error))
    // .finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "Image-Right")
    // .then(imgright=>{ this.imgright=imgright.data["Image-Right"]["url"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "section8-header")
    // .then(section8header=>{ this.section8header=section8header.data["section8-header"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "section8-header-russ")
    // .then(section8headerruss=>{ this.section8headerruss=section8headerruss.data["section8-header-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "section8-text")
    // .then(section8text=>{ this.section8text=section8text.data["section8-text"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(105, "section8-text-russ")
    // .then(section8textruss=>{ this.section8textruss=section8textruss.data["section8-text-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(108, "menu-item9")
    // .then(menu9=>{ this.menu9=menu9.data["menu-item9"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(108, "menu-item9-russ")
    // .then(menu9r=>{ this.menu9r=menu9r.data["menu-item9-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    //
    // sectio1Api.getSectionField(108, "section9-header")
    // .then(section9header=>{ this.section9header=section9header.data["section9-header"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(108, "section9-header-russ")
    // .then(section9headerruss=>{ this.section9headerruss=section9headerruss.data["section9-header-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(108, "section-left-text")
    // .then(section9lefttext=>{ this.section9lefttext=section9lefttext.data["section-left-text"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(108, "section-left-text-russ")
    // .then(section9lefttextruss=>{ this.section9lefttextruss=section9lefttextruss.data["section-left-text-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    // sectio1Api.getSectionField(108, "section-reft-text")
    // .then(section9righttext=>{ this.section9righttext=section9righttext.data["section-reft-text"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //
    // sectio1Api.getSectionField(108, "section-right-text-russ")
    // .then(section9righttextruss=>{ this.section9righttextruss=section9righttextruss.data["section-right-text-russ"];}).catch(error => console.log(error)).finally(() => {
    //   this.loading = true
    // })
    //

    sectio1Api.getSectionField(108, "section-map")
    .then(sectionmap=>{ this.sectionmap=sectionmap.data["section-map"];}).catch(error => console.log(error)).finally(() => {
      this.loading = true
    })
  },}


</script>
