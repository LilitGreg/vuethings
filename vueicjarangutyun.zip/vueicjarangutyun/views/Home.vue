<template>
  <div id="app" class="page pagehome">


    <Header v-bind:carttable="carttable" />

    <!-- <div class="dropdown drop-button">
      <button  class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fa fa-bars"></i>
      </button>
      <div class="dropdown-menu ddmenu" aria-labelledby="dropdownMenuButton">
          <router-link    class="dropdown-item" to="/"> {{carttable.homemenu}} </router-link>
          <router-link class="dropdown-item" to="/checkout">{{carttable.checkout}}</router-link>
            <router-link  class="dropdown-item" to="/barbequeproducts"> {{carttable.products}} </router-link>
      </div>
    </div> -->


    <div id="lang_sel_list" class="">
          <ul>
              <li class="icl-en" id="eng-lang">
                 <a href="#eng-lang"  v-on:click="changeenglish()"  class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/en.png" alt="en" title="English">&nbsp;
                 </a>
              </li>
                <li class="icl-ru" id="ru-lang">
                  <a href="#ru-lang"  v-on:click="changerussion()"   class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/ru.png" alt="ru" title="Русский">&nbsp;
                 </a>
              </li>
            </ul>
      </div>


<!--
      <a href="#" class="bbb" v-on:click="jscodehome()" >bbb</a> -->
    <!-- <div id="nav">
      <router-link to="/">Home</router-link>
    </div> -->
    <router-view/>
    <div class="">
      <div class="vNav">
            <ul class="vNav">
                 <li class="animated fadeInDown">
                     <a href="#secton1" class="sect-menu">
                         <div class="labelactive labele">   {{menu1}}</div>
                          <div class="hiden labelr">  {{menu1r}} </div>
                     </a>
                 </li>
                 <li class="animated fadeInDown">
                     <a href="#section2"   class="sect-menu">
                         <div class="labele" > {{menu2}} </div>
                         <div class="hiden labelr">   {{menu2r}}   </div>
                     </a>
                 </li>
                 <li class="animated fadeInDown">
                     <a href="#section3"  class="sect-menu">
                         <div class="labele">   {{menu3}} </div>
                          <div class="hiden labelr">     {{menu3r}}  </div>
                     </a>
                 </li>
                 <li class="animated fadeInDown">
                     <a href="#section4"  class="sect-menu">
                         <div class="labele">  {{menu4}}</div>
                         <div class="hiden labelr">   {{menu4r}}   </div>
                     </a>
                 </li>
                  <li class="animated fadeInDown">
                     <a href="#section5"  class="sect-menu">
                          <div class="labele">  {{menu5}}</div>
                          <div class="hiden labelr">  {{menu5r}} </div>
                     </a>
                 </li>
                 <li class="animated fadeInDown">
                    <a href="#section5a"  class="sect-menu">
                        <div class="labele">  {{menu5a}} </div>
                        <div class="hiden labelr">  {{menu5ar}} </div>
                    </a>
                </li>
                 <li class="animated fadeInDown">
                    <a href="#section6"  class="sect-menu">
                        <div class="labele"> {{menu6}} </div>
                        <div class="hiden labelr">  {{menu6r}} </div>
                    </a>
                </li>
                <li class="animated fadeInDown">
                   <a href="#section7"  class="sect-menu">
                       <div class="labele"> {{menu7}}</div>
                        <div class="hiden labelr">  {{menu7r}} </div>
                   </a>
               </li>
               <li class="animated fadeInDown">
                  <a href="#section8"  class="sect-menu">
                      <div class="labele">{{menu8}}</div>
                      <div class="hiden labelr"> {{menu8r}} </div>
                  </a>
              </li>
              <li class="animated fadeInDown">
                 <a href="#section9"  class="sect-menu">
                     <div class="labele">{{menu9}}</div>
                     <div class="hiden labelr">{{ menu9r}} </div>
                 </a>
             </li>
          </ul>
         </div>
    <!--EHERE HAVE JS-->
       <div class="section1 fixed-section1 par" id="secton1">
          <div class="container-fluid">
            <div class="row">
              <!-- <div id="lang_sel_list" class="">
                    <ul>
                        <li class="icl-en" id="eng-lang">
                           <a href="#eng-lang"  v-on:click="changeenglish()"  class="lang_sel_other">
                             <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/en.png" alt="en" title="English">&nbsp;
                           </a>
                        </li>
                          <li class="icl-ru" id="ru-lang">
                            <a href="#ru-lang"  v-on:click="changerussion()"   class="lang_sel_other">
                             <img class="iclflag" src="http://localhost/mugs/wp-content/uploads/2019/03/ru.png" alt="ru" title="Русский">&nbsp;
                           </a>
                        </li>
                      </ul>
                </div> -->


               <div class="blackscreen animated" id="blackscreen"> </div>

                     <!-- <img  class="section1-slider" id="section1-slider"  src="http://localhost/mugs/wp-content/uploads/2019/02/home_bg_middlea.png" alt=""> -->
                     <!-- {{homeback}} -->
                     <div  id="section1-slider" class="section1-slider" v-bind:style="{ backgroundImage: 'url(' + homeback + ')' }">

                     </div>
                     <!-- <img class="section1-slider" id="section1-slider"  :src="homeback" alt=""> -->

                     <!-- <img src="" alt="" :style="{ backgroundImage: `url('${bgImage}')}> -->

                     <!-- <img src="" alt="" v-bind:style="{ backgroundImage: 'url(' + homeback + ')' }"> -->
                     <!-- <img src="{{homeback}}" class="section1-slider" id="section1-slider" alt=""> -->
                      <div class="titleslide animated" id="titleslide">
                          <div class="logo align-middle">
                              <!-- <div class="point1"><img src="http://le-mugs.com/wp-content/themes/mugs/images/point.svg"></div>
                              <div class="point2"><img src="http://le-mugs.com/wp-content/themes/mugs/images/point.svg"></div> -->
                              <div class="title">

                                <!-- <img src="../assets/img/logob1.png" alt=""> -->

                                <img :src="barbeqlogo" class=""  alt="">
                                  <!-- <svg version="1.1"  id="logo" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                 width="250px"  viewBox="0 0 758 254.5" enable-background="new 0 0 758 254.5" xml:space="preserve">
                                 <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                                 M7.833,243.252V8.584l92,118.357l92-118.357v146.333c0,0-2.334,47.334,41.333,73.667s90.556,14.312,112-2.333
                                 s37.285-31.001,36.309-82.334l-0.348-17.682"/>
                                 <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                                 M573.616,35.451c-20.337-16.784-46.409-26.866-74.837-26.866c-64.977,0-117.651,52.674-117.651,117.651
                                 s52.675,117.652,117.651,117.652c50.261,0,93.16-31.516,110.015-75.865H467.167"/>
                                 <path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                                 M751.542,50.551c0,0-28.042-43.768-97.709-41.909S563.834,46.834,563.5,71.167s12.334,50.333,67,58.667s86.424,8.439,102.333,38.667
                                 c13.333,25.333-1.333,64.667-44.333,75.444c-24.646,6.178-70.268,12.248-110.801-27.265"/>
                               </svg> -->
                              </div>
                              <!-- <div class="titleunder">
                                  <img src="http://le-mugs.com/wp-content/themes/mugs/images/FDDG-fr.svg">
                              </div> -->
                          </div>
                      </div>
                      <div class="containerText animated" id="containerText">
                         <div class="textIntro">
                             <div class="bloc" id="bloc">
                               <!-- <div v-for='projects in project'> -->
                                <h1> {{pageone}} </h1>
                                <h1 class="hide"> {{hometextrus}}  </h1>
                              <!-- </div> -->

                                </div><a href="#section2" id="arrow">  <span>  <i class="fa fa-angle-down" aria-hidden="true"></i>
                                </span> </a>
                         </div>
                     </div>
               </div>
          </div>
       </div>
       <div class="section2 par" id="section2">
         <section class="panel animation-element" id="panel1">
           <div class="bg1 animation-element">
             <div class="inside row">
                 <div class="title">
                     <div class="titleObj">
                         <h2 class="animated fadeInLeft">  {{headerlogo}}   </h2>
                         <h2 class="animated fadeInLeft hide">  {{headerslider1}} </h2>
                     </div>
                 </div>
                 <div class="imgList ">
                   <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                    <!-- <img class="section1-slider" id="section1-slider"  v.attr="src:slider1logo1"  alt=""> -->
                     <img :src="slider1logo1" class="animation-element panel1-img animated fadeInLeft"  alt="">
                      <!-- <img  class="animation-element panel1-img animated fadeInLeft"  src="http://localhost/mugs/wp-content/uploads/2019/02/1a.png" alt=""> -->
                  </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                       <img :src="slider1logo2" class="animation-element panel1-img animated fadeInLeft"  alt="">
                       <!-- <img   class="animation-element panel1-img animated fadeInLeft"  src="http://localhost/mugs/wp-content/uploads/2019/02/1b.png" alt=""> -->
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                       <img :src="slider1logo3" class="animation-element panel1-img animated fadeInLeft"  alt="">
                       <!-- <img class="animation-element panel1-img animated fadeInLeft" src="http://localhost/mugs/wp-content/uploads/2019/02/1c.png " alt=""> -->
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                       <img :src="slider1logo4" class="animation-element panel1-img animated fadeInLeft"  alt="">
                       <!-- <img class="animation-element panel1-img animated fadeInLeft" src=" http://localhost/mugs/wp-content/uploads/2019/02/1d.png" alt=""> -->
                      </div></div>
                 </div>
                 <div class="p">
                     <div class="pObj animated fadeInLeft">
                       <p>  {{ headertextsect2}}  </p>
                       <p class="hide">    {{ headertextsect2rus}} </p>
                     </div>

                 </div>
             </div>
           </div>
         </section>
         <section class="panel animation-element animation-element-panel2 slide-left" id="panel2">
           <div class="bg2  slide-left-short"  id="bg2panel2">
             <div class="inside row">
                 <div class="title">
                     <div class="titleObj">

                         <h2> {{headertextsect2a}} </h2>
                           <h2 class="hide"> {{headertextsect2aruss}}</h2>


                     </div>
                 </div>
                 <div class="imgList">
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                       <img :src="slider2logo1" class="animation-element panel1-img animated fadeInLeft">
                       <!-- <img class="" src="http://le-mugs.com/wp-content/themes/mugs/images/3a.png"> -->
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                        <img :src="slider2logo2" class="animation-element panel1-img animated fadeInLeft">
                       <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/3b.png"> -->
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                        <img :src="slider2logo3" class="animation-element panel1-img animated fadeInLeft">
                       <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/3c.png"> -->
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                       <img :src="slider2logo4" class="animation-element panel1-img animated fadeInLeft">
                       <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/3d.png"> -->
                     </div></div>
                 </div>
                 <div class="p">
                     <div class="pObj">
                       <p> {{slider2text}}</p>

                        <p class="hide"> {{slider2textruss}}</p>
                     </div>
                 </div>
             </div>

           </div>
         </section>
         <section class="panel animation-element animation-element-panel3 slide-left" id="panel3">
            <div class="bg3">
             <div class="inside row">
                 <div class="title">
                     <div class="titleObj">
                         <h2> {{headertextsect2b}}</h2>
                         <h2 class="hide"> {{headertextsect2bruss}} </h2>
                     </div>
                 </div>
                 <div class="imgList">
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">

                        <img :src="slider3logo1" class="animation-element panel1-img animated fadeInLeft">
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">

                        <img :src="slider3logo2" class="animation-element panel1-img animated fadeInLeft">
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">

                        <img :src="slider3logo3" class="animation-element panel1-img animated fadeInLeft">
                     </div></div>
                     <div class="obj col-md-3 col-sm-6 col-xs-12"><div class="">
                        <img :src="slider3logo4" class="animation-element panel1-img animated fadeInLeft">

                     </div></div>
                 </div>
                 <div class="p">
                     <div class="pObj">
                        <p> {{slider3text}}</p>

                        <p class="hide"> {{slider3textruss}} </p>

                       </div>
                 </div>
             </div>
          </div>
         </section>
         <!-- <div class="bg1"></div> -->
         <!-- <div class="bg2"></div>
         <div class="bg3"></div> -->
     </div>
     <div class="section3 par" id="section3">
       <div class="container-fluid">
          <div class="row">
              <!-- <img :src="section3backimg" class="animation-element panel1-img animated fadeInLeft"> -->
            <div class="window-cerf"   v-bind:style="{ backgroundImage: 'url(' + section3backimg + ')' }">
            <!-- <div class="window-cerf" style="background-image: url(http://le-mugs.com/wp-content/themes/mugs/images/cerf.jpg);"> -->
                <!-- <div class="window-cerf"  :style="{'background-image': 'url(' + require({{section3backimg}}) + ')'}"> -->
                 <div class="lampe" style="">
                   <img :src="section3img">
                   <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/lampe-section3.png"> -->
                 </div>
                 <div class="textOverparallax" style="">
                     <h1> {{section3header}}</h1>

                      <h1 class="hide"> {{section3headerruss}}</h1>

                     <p class="texteng"> {{section3text}}</p>

                     <p class="textruss hide"> {{section3textruss}} </p>
                     <!-- <p>Au total 850m² de déco ultra léchée, mix de styles et de genres.</p> -->
                 </div>
             </div>
          </div>
       </div>
     </div>
     <div class="section4 par" id="section4">
        <div class="window-section4" v-bind:style="{ backgroundImage: 'url(' + section4backimg + ')' }">
          <div class="container-fluid">
            <div class="row">
              <div>
                <div class="animated window-section4-text" id="window-section4-text">
                    <h1> {{section4head}}</h1>
                    <h1 class="hide">  {{section4headruss}}</h1>
                    <p>{{section4text}}</p>
                    <p class="hide">{{section4textruss}} </p>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="section5 par" id="section5">
      <div class="window-section5 animation-element">
      <div class="container-fluid">
        <div class="row">
         <div class="parassol rouge animation-element">
            <img :src="section5img1">
           <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/parassol-rouge.png"> -->
         </div>
         <div class="parassol vert animation-element">
           <img :src="section5img2">
           <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/parassol-vert.png"> -->
         </div>
         <div class="parassol creme animation-element">
           <img :src="section5img3">
           <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/parassol-creme.png"> -->
         </div>
         <div class="calme">
             <div class="title">
                 <h1>{{section5header}}</h1>
                    <h1 class="hide">{{section5headerruss}}</h1>

                 <p> {{section5text}}</p>
                  <p class="hide"> {{section5textruss}}</p>
                 </div>
               </div>
                 <div   class="section5para">
                   <div v-bind:style="{ backgroundImage: 'url(' + section5backimg + ')' }"  class="parallax-window animation-element clearfix">
                    <!-- <img :src="section5backimg"> -->
                   <!-- <img  class="animation-element" src="http://le-mugs.com/wp-content/uploads/2015/07/DSC_0220-Modifier-1920x696.jpg"> -->
                 </div>
             </div>
     </div>
   </div>
  </div>
  </div>
  <div class="section5a par" id="section5a">
    <div class="container-fluid">
      <div class="row">
        <div class="viewcart-content clearfix">
          <a href="#" id="viewcart"   v-on:click="viewcart()"  class="" data-toggle="modal" data-target="#mymodalcart">
            <!-- <img src="http://localhost/mugs/wp-content/uploads/2019/03/cart-512.png" alt=""> -->
            <i class="fa fa-shopping-cart"></i>
            <div class="cart-check-icon carte" style=""> Cart </div>
            <div class="hiden cart-check-icon cartr" style=""> Корзинка </div>
          </a>

          <div class="content-cart modal modals" id="mymodalcart"  role="dialog">
                                  <!-- <div class="modal-dialog dialogs clearfix">
                                     <a  class="closes">   x    </a> -->
          <table class="shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
           <thead>
             <tr>
               <th class="product-remove"> {{carttable.delete}} </th>
               <th class="product-thumbnail"> {{carttable.thumbnail}}  </th>
               <th class="product-name"> {{carttable.product}} </th>
               <th class="product-price">{{carttable.price}}  </th>
               <th class="product-quantity"> {{carttable.quantity}} </th>
               <th class="product-subtotal"> {{carttable.subtotal}} </th>
               <th class="product-subtotal"> {{carttable.update}}  </th>

               <th>
                 <a  class="closesa">   x    </a>
               </th>
             </tr>
           </thead>
                 <!-- <h2>  {{viewcart.product_name}}</h2> -->
                 <!-- <p> {{viewcart.line_total}} </p> -->
              <tbody>
              <!-- <div v-for="viewcart in viewcarts" class="viewcarts"> -->
              <!-- {{viewcarts}} -->
              <tr v-for="viewcart in viewcarts" class="viewcarts woocommerce-cart-form__cart-item cart_item">

              <td class="product-remove">
                <!-- <a v-on:click="deletetocart('8f53295a73878494e9bc8dd6c3c7104f')"  href="#" class="remove" aria-label="Remove this item">×</a> -->
                    <!-- <a v-on:click="deletetocart('16a5cdae362b8d27a1d8f8c7b78b4330')"  href="#" class="remove" aria-label="Remove this item">×</a> -->
                    <a v-on:click="deletetocart(viewcart.key)"  href="#" class="remove" aria-label="Remove this item">×</a>
              </td>

              <td class="product-thumbnail">
                <div v-for="project in projects" class="projects">
                  <div  v-if="project.name ===viewcart.product_name">
                    <!-- <a href="http://localhost/mugs/product/product1/"> -->
                       <img :src="project.images[0].src" alt="">
                      <!-- <img width="300" height="300" src="http://localhost/mugs/wp-content/uploads/2019/03/Salade-mini-penne-1024x1004-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" sizes="(max-width: 300px) 100vw, 300px"> -->
                    <!-- </a> -->
                  </div>
               </div>
              </td>
              <td  class="product-name" data-title="Product"> <!--{{viewcart.product_name}}{{fields[project.id]}}-->
                <div v-for="project in projects" class="viewcart-product-name">
                  <div  v-if="project.name ===viewcart.product_name">
                     <a href="#"> {{viewcart.product_name}} </a>
                     <a href="#" class="hiden">  {{fields[project.id]}}    </a>
                  </div>
                </div>
             </td>
              <td class="product-price" data-title="Price">
                <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"></span>
                 <!-- {{viewcart.line_total}}  -->
                 <div v-for="project in projects" class="projects">
                   <div  v-if="project.name ===viewcart.product_name">
                      £ {{project.price}}
                   </div>
                 </div>
               </span>
              </td>

              <td class="product-quantity" data-title="Quantity">
                <div class="quantity">
                <label class="screen-reader-text" for="quantity_5c82c8e375f4c"></label>
                <!-- <p>  {{viewcart.quantity}} </p> -->

                <!-- <input type="number" v-model.number="quantityf" v-model.number="quantityf"  v-model.number="quantityf"  :value{{quantityf?quantityf:0}}  :value{{viewcart.quantity?viewcart.quantity:0}}  id="" class="input-text qty text" step="1" min="0" max="" name=""   title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" aria-labelledby=""> -->

                  <input type="number"  v-model="viewcart.quantity"     id="" class="input-text qty text" step="1" min="quantityf" max="" name=""   title="Qty"  pattern="[0-9]*">
                <!-- <input type="number" name="" value="viewcart.quantity"> -->
                <!-- <input type="number" id="quantity_5c82c8e375f4c" class="input-text qty text" step="1" min="0" max="" name="cart[c20ad4d76fe97759aa27a0c99bff6710][qty]" value="1" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" aria-labelledby="Product1 quantity"> -->
               </div>
            </td>
            <td class="product-subtotal" data-title="Total">
                <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>
                  {{viewcart.line_subtotal}} </span>
            </td>

             <td> <!---->
              <button   v-on:click="updatecart(viewcart.key,viewcart.quantity)"  type="submit" class="update_cart button" name="update_cart" value="Update cart"> {{carttable.update}} </button>
             </td>

            </tr>

            <!-- <tr v-for="totalc in totalcarta" class=""> -->


            <tr class="last-tr">
              <td> {{carttable.totalcart}} </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td> £ {{totalcarta.subtotal}} </td>
              <td></td>
               <!-- <td>  </td> -->
           </tr>



          <!-- <tr>
          <td colspan="6" class="actions">

                        <div class="coupon">
                <label for="coupon_code">Coupon:</label> <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code"> <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply coupon</button>
                            </div>

            <button type="submit" class="button" name="update_cart" value="Update cart">Update cart</button>


            <input type="hidden" id="woocommerce-cart-nonce" name="woocommerce-cart-nonce" value="6864b5c2ef"><input type="hidden" name="_wp_http_referer" value="/mug/wp-json/wp/v2/pages/16">				</td>
          </tr> -->
                <!-- </div> -->
                </tbody>
                </table>
<!--
                <div class="cart-collaterals">
                  	<div class="cart_totals ">
                  	<!-- <h2>Cart totals</h2> --
                  	<table class="shop_table shop_table_responsive" cellspacing="0">
                  		<tbody><tr class="cart-subtotal">
                  			<th>Subtotal</th>
                  			<td data-title="Subtotal"><span class="woocommerce-Price-amount amount">
                          <span class="woocommerce-Price-currencySymbol">£</span> {{totalcart}} 570.00</span></td>
                  		</tr>
                  		<tr class="order-total">
                  			<th>Total</th>
                  			<td data-title="Total"><strong><span class="woocommerce-Price-amount amount">
                          <span class="woocommerce-Price-currencySymbol">£</span>570.00</span></strong> </td>
                  		</tr>
                  	</tbody>
                  </table>

                  </div>
                  </div> -->

          </div>
        </div>






        </div>

        <div class="plate1" style="">
              <div  v-for="categoryall in categoriesall" class="">
                  <div  v-if="categoryall.id ===16"  class="categorynames">
                      <!-- {{categoryall.image.src}} -->
                     <!-- <p class="categ-names  animated"  id="cat1">  {{categoryall.name}} </p> -->
                     <p class="categ-names  animated"  id="cat1"> {{categoryall.name}} </p>
                      <p class="categ-names hide animated"  id="cat1"> {{category1russ}} </p>

                      <!-- <p> {{fieldscat}}  </p> -->

                      <img :src="categoryall.image.src" alt="">

                      <!-- {{categoryall.slug}} -->
                    <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/salade-lentilles.png"> -->

                  <div class="rollover" data-id="1" style="cursor: pointer;">
                       <a class="animated roundbtn" style="" data-toggle="modal" data-target="#myModal1">
                        <!-- <p> DISOVRER</p> -->
                         <!-- <p class="categ-foods">  {{categoryall.name}} </p> -->

                          <p class="categ-foods">  {{categoryall.name}}   </p>
                           <p class="categ-foods hide">  {{category1russ}} </p>
                      </a>
                  </div>
                </div>
              </div>

                  <div id="myModal1" class="modal modals" role="dialog">

                      <div class="modal-dialog dialogs clearfix single-products">
                         <a  class="closes">   x    </a>

                          <div class="modal-body row clearfix">
                             <div  v-for="category in categories" class="">
                                 <!-- <div  v-if="category.id ==="> -->
                                    <!-- {{category}} -->
                                    <div v-for="project in projects" class="col-md-12 clearfix">
                                       <div  v-if="category.name  === project.name ">
                                         <!-- {{category.id}} -->
                                         <div class="col-md-6">
                                            <!-- <img :src="project.images[0].src" alt=""> width: 474.6px-->

                                            <hooper>
                                              <slide>
                                                <li style="">  <img  class="" v-if="project.images[1].src"  :src="project.images[1].src" alt=""> </li>
                                              </slide>
                                              <slide>
                                              <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li>
                                              </slide>

                                              <hooper-navigation slot="hooper-addons">  </hooper-navigation>

                                            </hooper>

                                            <!-- <template>
                                              <carousel :data="data" :controls="true"> </carousel>
                                              <!-- <div class="broadcast">
                                                   <feather type="radio"></feather>
                                                   <carousel :data="data" :controls="false" :indicators="false" :interval="3000" direction="up"></carousel>
                                                 </div> --
                                            </template> -->


                                         </div>
                                          <div class="col-md-6 project-text">
                                             <!-- {{project.images[0].src}} -->
                                            <h2>  {{project.name}} </h2>
                                            <h2 class="hide"> {{fields[project.id]}} </h2>
                                            <!--
                                            <h2>   {{producttitle1a}} </h2>
 -->


                                               <!-- {{getSectionProductField(project.id, 'product-title-russ')}} -->


                                            <!-- {{productstitles}} -->
                                            <!-- {{project.id}} -v-on:click="getSectionProductField(project.id)-->


                                            <!-- <div class="" v-for="productstit in productstitles">

                                            </div> -->
                                            <!-- {{productstitles}} -->


                                             <!-- <button type="button"  v-on:click="getSectionProductField(project.id, 'product-title-russ')" name="button">{{ project.name}} </button> -->


                                            <!-- <p class="desc" id="desc">   {{project.description}}  </p> -->
                                             <p> {{carttable.price}}: {{project.price}} $ </p>
                                          </div>

                                            <button type="submit"    v-on:click="addtocart(category.id,1)"   name="add-to-cart" value="" class="single_add_to_cart_button button alt"> {{carttable.addtocart}} </button>


                                            <!-- <button type="button"  name="button"> View Product </button> -->

                                       </div>
                                     </div>
                                 <!-- </div> -->
                             </div>
                                <!-- {{addtochart}} -->


                          </div>
                     </div>
                  </div>

                     <!-- <div class="popup-view clearfix">
                         <a  id="close"  href="#" class="closes-pop">
                           <img src="http://localhost/watch/wp-content/uploads/2019/02/close.png" alt="">
                        </a>
                         <div v-for="project in projects" class="projects">
                             <div  v-if="project.id ===12">
                               <div class="col-md-6">
                                  <img :src="project.images[0].src" alt="">
                               </div>
                                <div class="col-md-6">
                                   <!-- {{project.images[0].src}} --
                                  <h2>  {{project.name}}</h2>
                                   <p> {{project.description}} </p>
                                   <p> Price: {{project.price}} $ </p>
                                </div>
                                  <button type="submit" name="add-to-cart" value="" class="single_add_to_cart_button button alt">Add to cart</button>
                                    {{addtocarts}}
                             </div>
                           </div>
                     </div> -->




        </div>

        <div class="salade">
                <svg version="1.1" id="saladesvg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="231px" height="235px" viewBox="0 0 231 235" enable-background="new 0 0 231 235" xml:space="preserve">
            		<path fill="none" id="sletter" class="animated" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M56.067,151.306c-17.035,11.384,14.359,32.447,14.041,43.604c-0.158,5.514-5.896,10.26-9.939,4.512" style=""></path>

                <path fill="none"  class="animated" id="aletter"  stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M80.68,197.038c-2.11-9.591-4.262-19.246-5.044-29.055c-0.305-3.837-1.978-15.474,1.658-18.477
            		c6.355-5.25,11.338,22.138,12.108,25.838c1.362,6.547,2.554,13.129,3.806,19.698" style=""></path>

                <path fill="none" stroke="#FFFFFF"  stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M76.3,173.701c4.094-0.816,8.147-1.641,12.25-2.384" style=""></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" class="animated"  id="lletter"  stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M93.374,142.937c3.393,10.579,6.874,21.157,9.862,31.859c0.989,3.546,1.525,16.052,4.985,18.251c2.019,1.283,4.241-0.085,5.94-1.44" style="stroke-dasharray: 59.1355px; stroke-dashoffset: 37px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill=""  class="animated" id="aletter" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M126.412,188.779c-2.912-8.051-5.671-16.153-7.471-24.535c-1.354-6.297-4.063-16.146-1.811-22.523
            		c1.872-5.296,4.417-2.811,6.947,1.03c4.432,6.732,6.953,15.228,9.003,22.942c1.903,7.155,2.954,14.368,3.308,21.756" style=""></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M119.538,167.326c4.359-0.975,8.601-2.391,12.86-3.713" style="stroke-dasharray: 13.3895px; stroke-dashoffset: 13.3895px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M152.354,187.67c-5.855-17.212-13.708-35.068-17.342-52.877c15.597,12.94,24.518,27.666,20.501,48.758
            		c-0.378,1.973-0.468,5.715-3.103,4.563" style="stroke-dasharray: 118.243px; stroke-dashoffset: 118.243px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M163.606,149.81c3.682-5.109,8.679-12.736,3.249-18.496c-4.514-4.787-7.268-1.504-6.469,3.787c1.255,8.307,4.28,15.909,4.839,24.436
            		c0.355,5.433-0.631,16.602,4.674,20.277c6.201,4.297,7.63-6.062,8.231-10.159" style="stroke-dasharray: 95.3963px; stroke-dashoffset: 95.3963px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M183.119,121.871c-8.739,8.894,1.753,22.563,6.873,30.581c3.477,5.444,11.717,18.015,4.701,24.409
            		c-2.077,1.893-3.842,1.789-5.698-0.721" style="stroke-dasharray: 67.7791px; stroke-dashoffset: 67.7791px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M65.878,62.003c2.403,8.323,3.878,16.878,6.058,25.257c0.508,1.947,4.323,17.91,8.244,10.331" style="stroke-dasharray: 43.3577px; stroke-dashoffset: 43.3577px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M85.613,58.235c-7.611,1.468-2.527,11.245-1.443,15.902c1.132,4.865,0.25,18.271,4.555,21.619c1.5,1.167,3.508,1.065,5.258,0.451" style="stroke-dasharray: 46.4054px; stroke-dashoffset: 46.4054px; visibility: visible; stroke-width: 6px;"></path>

              	<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M84.614,79.465c2.125-0.501,4.428-0.919,6.431-1.608" style="stroke-dasharray: 6.63239px; stroke-dashoffset: 6.63239px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M97.642,56.072c-9.674,8.819,19.948,35.264,8.523,38.972c-2.015,0.653-3.395-0.919-4.089-2.829" style="stroke-dasharray: 49.3723px; stroke-dashoffset: 49.3723px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M57.841,56.294c-3.027-2.057-6.174-3.629-8.758-6.264" style="stroke-dasharray: 10.7922px; stroke-dashoffset: 10.7922px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M84.394,45.817c-1.068-4.389-1.503-8.363-1.664-12.75" style="stroke-dasharray: 12.8815px; stroke-dashoffset: 12.8815px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M112.386,58.401c2.921-3.876,5.252-8.061,7.539-12.307" style="stroke-dasharray: 14.4471px; stroke-dashoffset: 14.4471px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M118.817,80.518c5.339,0.017,11.047-0.568,16.352,0.167" style="stroke-dasharray: 16.3705px; stroke-dashoffset: 16.3705px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M112.054,106.405c3.372,3.597,7.634,9.307,11.752,11.975" style="stroke-dasharray: 16.8243px; stroke-dashoffset: 16.8243px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M87.663,111.562c0.319,5.956-1.43,11.809-1.385,17.737" style="stroke-dasharray: 17.8136px; stroke-dashoffset: 17.8136px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M63.605,103.634c-5.007,2.913-10.255,6.414-15.743,8.425" style="stroke-dasharray: 17.8825px; stroke-dashoffset: 17.8825px; visibility: visible; stroke-width: 6px;"></path>
            		<path fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
            		M53.406,78.634c-5.277,1.131-11.173,2.068-16.631,2.051" style="stroke-dasharray: 16.7881px; stroke-dashoffset: 16.7881px; visibility: visible; stroke-width: 6px;"></path>
            	</svg>
            	</div>





              <!-- <svg version="1.1" id="tracesvg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1031px" height="3544px" viewBox="0 0 1031 3544" enable-background="new 0 0 1031 3544" xml:space="preserve">
          		<path id="p1" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="0" d="M845,14.04
          		c94.488-0.933,147.798,113.116,61,198.96c-112.197,110.964-250.383,70.569-402,133c-110.712,45.587-171.223,130.125-158.981,201.27" style="stroke-dasharray: 977.677px; stroke-dashoffset: 443px; visibility: visible;"></path>

            	<path id="p2" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M395.214,636.783
          		C508.019,750.449,735.719,626.242,785,780c18.75,58.5,0.346,121.5-10.028,149.343" style="stroke-dasharray: 591.915px; stroke-dashoffset: 591.915px; visibility: visible;"></path>

            	<path id="p3" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M719,1080.551
          		C685.436,1165,677,1284,735,1326c47.015,34.045,115.498,12.164,131-45c16-59-23-111-88-112c-84.843-1.306-125.168,89.977-138.98,151
          		c-15.885,70.191,14.48,139.643,57.16,193.202" style="stroke-dasharray: 1021.02px; stroke-dashoffset: 1021.02px; visibility: visible;"></path>

            	<path id="p4" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M784.698,1636.219
          		c35.149,46.862,48.542,101.471-3.998,141.429c-52.421,39.867-115.838,17.305-165.888-13.571
          		c-53.508-33.005-222.409-144.596-354.4-151.492c-65.354-3.416-132.975,15.642-173.593,70.394
          		c-35.042,47.233-43.539,112.665-22.847,167.587c22.548,59.844,76.491,95.053,137.791,106.104
          		c81.652,14.722,130.323-30.101,213.6-42.669c112.637-17,195.638,54.803,221.399,130.602" style="stroke-dasharray: 1780.41px; stroke-dashoffset: 1780.41px; visibility: visible;"></path>

              <path id="p5" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M679.961,2196
          		c15.618,110-32.448,221.008-163.556,202.901C437.362,2387.983,326,2354,248,2411c-69.651,50.899-70.48,127.04-64.81,178.391" style="stroke-dasharray: 787.031px; stroke-dashoffset: 787.031px; visibility: visible;"></path>

              <path id="p6" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M223.544,2718.265
          		c19.247,66.11,179.788,263.739,297.122,209.739c49.069-22.583,50-86-0.667-117.333c-43.041-26.617-106-8-114,43.333
          		c-13.321,85.474,76,101.996,136,210.663" style="stroke-dasharray: 943.531px; stroke-dashoffset: 943.531px; visibility: visible;"></path>

            	<path id="p7" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M597,3185
          		c0,0,60.092,149.502,40.768,359" style="stroke-dasharray: 364.043px; stroke-dashoffset: 364.043px; visibility: visible;"></path>
          		</svg> -->

              <svg version="1.1" id="tracesvg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1031px" height="3544px" viewBox="0 0 1031 3544" enable-background="new 0 0 1031 3544" xml:space="preserve">

              <path id="p1" fill="none"   class="animated" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="0" d="M845,14.04
          		c94.488-0.933,147.798,113.116,61,198.96c-112.197,110.964-250.383,70.569-402,133c-110.712,45.587-171.223,130.125-158.981,201.27" style=""></path>

              <path id="p2" fill="none" class="animated" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M395.214,636.783
          		C508.019,750.449,735.719,626.242,785,780c18.75,58.5,0.346,121.5-10.028,149.343" style=""></path>

              <path id="p3" fill="none" class="animated" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M719,1080.551
          		C685.436,1165,677,1284,735,1326c47.015,34.045,115.498,12.164,131-45c16-59-23-111-88-112c-84.843-1.306-125.168,89.977-138.98,151
          		c-15.885,70.191,14.48,139.643,57.16,193.202" style=""></path>


              <!-- <path id="p3" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M719,1080.551
                        		C585.436,1165,677,2000,735,1326c47.015,34.045,115.498,12.164,131-45c16-59-23-111-88-112c-84.843-1.306-125.168,89.1277-138.98,151
                        		c-35.885,200.191,44.48,139.743,57.16,393.202" class="animated p3stroke"></path> -->

<!--
              <path id="p4" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="0" d="M845,14.04
          		c94.488-0.933,147.798,113.116,61,198.96c-112.197,110.964-250.383,70.569-402,133c-110.712,45.587-171.223,130.125-158.981,201.27" style="stroke-dasharray: 977.677px;
                  stroke-dashoffset:0px;
                  visibility: visible" ></path> -->



              <!-- <path id="p3" fill="none"   class="animated" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="0" d="M845,14.04
             c94.488-0.933,147.798,113.116,61,198.96c-112.197,110.964-250.383,70.569-402,133c-110.712,45.587-171.223,130.125-158.981,201.27" style=""></path> -->


              <!-- <path id="p3" fill="none" class="animated" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M784.698,1636.219
            		c35.149,46.862,48.542,101.471-3.998,141.429c-52.421,39.867-115.838,17.305-165.888-13.571
            		c-53.508-33.005-222.409-144.596-354.4-151.492c-65.354-3.416-132.975,15.642-173.593,70.394
            		c-35.042,47.233-43.539,112.665-22.847,167.587c22.548,59.844,76.491,95.053,137.791,106.104
            		c81.652,14.722,130.323-30.101,213.6-42.669c112.637-17,195.638,54.803,221.399,130.602" style="">
              </path> -->

              <!-- <path id="p3" fill="none" class="animated"  stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M679.961,2196
		              c15.618,110-32.448,221.008-163.556,202.901C437.362,2387.983,326,2354,248,2411c-69.651,50.899-70.48,127.04-64.81,178.391" style="">
              </path> -->

            	<!-- <path id="p4" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M784.698,1636.219
          		c35.149,46.862,48.542,101.471-3.998,141.429c-52.421,39.867-115.838,17.305-165.888-13.571
          		c-53.508-33.005-222.409-144.596-354.4-151.492c-65.354-3.416-132.975,15.642-173.593,70.394
          		c-35.042,47.233-43.539,112.665-22.847,167.587c22.548,59.844,76.491,95.053,137.791,106.104
          		c81.652,14.722,130.323-30.101,213.6-42.669c112.637-17,195.638,54.803,221.399,130.602" style="stroke-dasharray: 1780.41px; stroke-dashoffset: 0px; visibility: visible;"></path> -->

            	<!-- <path id="p5" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M679.961,2196
          		c15.618,110-32.448,221.008-163.556,202.901C437.362,2387.983,326,2354,248,2411c-69.651,50.899-70.48,127.04-64.81,178.391" style="stroke-dasharray: 787.031px; stroke-dashoffset: 0px; visibility: visible;"></path>

              <path id="p6" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M223.544,2718.265
          		c19.247,66.11,179.788,263.739,297.122,209.739c49.069-22.583,50-86-0.667-117.333c-43.041-26.617-106-8-114,43.333
          		c-13.321,85.474,76,101.996,136,210.663" style="stroke-dasharray: 943.531px; stroke-dashoffset: 0px; visibility: visible;"></path>

            	<path id="p7" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-miterlimit="10" d="M597,3185
          		c0,0,60.092,149.502,40.768,359" style="stroke-dasharray: 364.043px; stroke-dashoffset: 0px; visibility: visible;"></path>-->

            	</svg>

              <!-- <svg class="letter--b" viewBox="0 0 80 100">
                <path d="M5,5
                         c80,0 80,45 0,45
                         c80,0 80,45 0,45z" />
              </svg> -->


          <div class="woocommerce-product-disp">

          <div class="planchecharcuterie" style="">

            <div  v-for="categoryall in categoriesall" class="">
                <div  v-if="categoryall.id ===17" class="categorynames">

                     <!-- <p class="categ-names animated" id="cat2">  {{categoryall.name}} </p>
 -->
                     <p class="categ-names  animated"  id="cat2">  {{categoryall.name}}  </p>
                      <p class="categ-names hide animated"  id="cat2"> {{category2russ}} </p>
                    <!-- {{categoryall.image.src}} -->
                    <img :src="categoryall.image.src" alt="">
                    <!-- {{categoryall.slug}} -->
                  <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/salade-lentilles.png"> -->


            <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/planche-charcuteries.png"> -->
              <div class="rollover" data-id="2" style="cursor: pointer;">
                <a class="animated roundbtn" style="" data-toggle="modal" data-target="#myModal">
                  <!-- <p> DISOVRER</p> -->
                   <!-- <p class="categ-foods">  {{categoryall.name}} </p> -->

                   <p class="categ-foods">  {{categoryall.name}}  </p>
                    <p class="categ-foods hide">  {{category2russ}} </p>
                </a>
              </div>
              </div>
            </div>

               <div id="myModal" class="modal modals" role="dialog">

                   <div class="modal-dialog dialogs clearfix single-products">
                      <a  class="closes">   x    </a>

                       <div class="modal-body row">

                         <!-- {{categoriespitzza}} -->
                         <div  v-for="categorypit in categoriespitzza" class="">
                             <!-- <div  v-if="category.id ==="> -->
                                <!-- {{categorypit.id}} -->
                                <div v-for="project in projects" class="col-md-12 clearfix">
                                   <div  v-if="categorypit.name  === project.name ">
                                     <!-- {{category.id}} -->
                                     <div class="col-md-6">
                                        <!-- <img :src="project.images[0].src" alt=""> -->


                                        <hooper>
                                          <slide>
                                            <li style="">  <img  class="" v-if="project.images[1].src"  :src="project.images[1].src" alt=""> </li>
                                          </slide>
                                          <slide>
                                          <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li>
                                          </slide>


                                         <hooper-navigation slot="hooper-addons">  </hooper-navigation>


                                        </hooper>
                                     </div>
                                      <div class="col-md-6 project-text">
                                         <!-- {{project.images[0].src}} -->
                                        <h2>  {{project.name}}</h2>
                                          <h2 class="hide"> {{fields[project.id]}} </h2>
                                        <!-- <p class="desc">   {{project.description}}  </p> -->
                                         <p> {{carttable.price}}: {{project.price}} $ </p>
                                      </div>
                                        <button type="submit"    v-on:click="addtocart(categorypit.id,1)"   name="add-to-cart" value="" class="single_add_to_cart_button button alt"> {{carttable.addtocart}} </button>
                                        <!-- <button type="button"  name="button"> View Product </button> -->
                                 </div>
                                 </div>
                             <!-- </div> -->
                         </div>



                       </div>

                  </div>
               </div>

               <!-- <div class="popup-view clearfix">
                   <a  id="close"  href="#" class="closes-pop">
                     <img src="http://localhost/watch/wp-content/uploads/2019/02/close.png" alt="">
                  </a>
                  <div v-for="project in projects" class="projects">
                   <div  v-if="project.id ===179">
                      <div class="col-md-6">
                         <img :src="project.images[0].src" alt="">
                      </div>
                       <div class="col-md-6">
                           <h2>  {{project.name}}</h2>
                           <p> {{project.description}} </p>
                           <p> Price: {{project.price}} $ </p>
                        </div>
                    </div>
                  </div>

                </div> -->

          </div>
          <div class="burger" style="">
            <div  v-for="categoryall in categoriesall" class="">
                <div  v-if="categoryall.id ===18" class="categorynames">

                   <!-- <p class="categ-names animated" id="cat3">  {{categoryall.name}} </p> -->

                    <p class="categ-names animated" id="cat3">  {{categoryall.name}}  </p>
                     <p class="categ-names hide animated" id="cat3">  {{category3russ}} </p>
                    <!-- {{categoryall.image.src}} -->
                    <img :src="categoryall.image.src" alt="">
                    <!-- {{categoryall.slug}} -->
                  <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/salade-lentilles.png"> -->


            <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/burger-boeuf-seul.png"> -->
              <div class="rollover" data-id="2" style="cursor: pointer;">
                <a class="animated roundbtn" style="" data-toggle="modal" data-target="#myModal3">
                   <!-- <p class="categ-foods">   {{categoryall.name}} </p> -->
                   <p class="categ-foods">  {{categoryall.name}}  </p>
                    <p class="categ-foods hide">  {{category3russ}} </p>
                </a>
              </div>
            </div>
          </div>

              <div id="myModal3" class="modal modals" role="dialog">

                  <div class="modal-dialog dialogs clearfix single-products">
                     <a  class="closes">   x    </a>

                      <div class="modal-body row">

                        <div  v-for="categorybar in categoriesbarbecue" class="">

                               <div v-for="project in projects" class="col-md-12 clearfix">
                                  <div  v-if="categorybar.name  === project.name ">

                                    <div class="col-md-6">

                                      <hooper>
                                        <slide>
                                          <li style="">  <img  class="" v-if="project.images[1].src"  :src="project.images[1].src" alt=""> </li>
                                        </slide>
                                        <slide>
                                        <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li>
                                        </slide>


                                      <hooper-navigation slot="hooper-addons">  </hooper-navigation>


                                      </hooper>

                                      <!-- <div id="slidergallery" name="">

                                        <a href="#" class=" control_next_gal" onclick="">   <i class="fa fa-angle-right"></i> </a>
                                        <a href="#" class=" control_prev_gal"  onclick=""> <i class="fa fa-angle-left"></i> </a>
                                        <ul>
                                          <li>  <img  class="mySlides" v-if="project.images[1].src"  :src="project.images[1].src" alt=""> </li>
                                          <li>  <img class="mySlides"  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li>

                                        </ul>
                                      </div> -->

                                        <!-- <img :src="project.images[2].src" alt=""> -->
                                    </div>
                                     <div class="col-md-6 project-text">

                                       <h2>  {{project.name}}</h2>
                                         <h2 class="hide"> {{fields[project.id]}} </h2>
                                       <!-- <p class="desc">   {{project.description}}  </p> -->
                                        <p> {{carttable.price}}: {{project.price}} $ </p>
                                     </div>
                                       <button type="submit"    v-on:click="addtocart(categorybar.id,1)"   name="add-to-cart" value="" class="single_add_to_cart_button button alt"> {{carttable.addtocart}} </button>

                                        <!-- <button type="button"  name="button"> View Product </button> -->
                                  </div>
                                </div>

                        </div>
                      </div>


              </div>
            </div>
          </div>
    </div>
  </div>
  </div>
</div>


  <div class="section6 par" id="section6">
    <div class="window-section6">
    <div class="container-fluid">
      <div class="row">
         <div class="text-section6 animation-element bounce-up" style="">
            <h1> {{section6header}}  </h1>
            <h1 class="hide"> {{section6headerruss}}  </h1>
            <p>{{section6text}} </p>
            <p class="hide"> {{section6textruss}}</p>
         </div>
          <div class="parallax-window">
          <img :src="section6img">
          <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/slidehandmade.jpg"> text-section6-->
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section7 par" id="section7">
  <div class="container-fluid">
    <div class="row">

    <!-- <div id="slider">
      <a href="#" class=" control_next">   <i class="fa fa-angle-right"></i> </a>
      <a href="#" class=" control_prev"> <i class="fa fa-angle-left"></i> </a><ul>
        <li class="animatedslider">  <div class="slide img0" v-bind:style="{ backgroundImage: 'url(' + slider1 + ')' }"></div> </li>
        <li  class="animatedslider">  <div class="slide img1 "  v-bind:style="{ backgroundImage: 'url(' + slider2 + ')' }" ></div> </li>
        <li  class="animatedslider"><div class="slide img0" v-bind:style="{ backgroundImage: 'url(' + slider3 + ')' }" ></div></li>
        <li  class="animatedslider">  <div class="slide img1"  v-bind:style="{ backgroundImage: 'url(' + slider4 + ')' }" ></div></li>
      </ul>
    </div> -->
<!-- <div v-for="project in projects" > -->

    <hooper>
      <slide>
        <div class="slide1 "  v-bind:style="{ backgroundImage: 'url(' + slider1 + ')' }" ></div>
        <!-- <li style="">
          <img  class="" v-if="project.images[1].src"  :src="project.images[1].src" alt="">
         </li> -->
      </slide>
      <slide>
      <!-- <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li> -->
        <div class="slide1 "  v-bind:style="{ backgroundImage: 'url(' + slider2 + ')' }" ></div>
      </slide>
      <slide>
      <!-- <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li> -->
        <div class="slide1 "  v-bind:style="{ backgroundImage: 'url(' + slider3  + ')' }" ></div>
      </slide>

      <slide>
      <!-- <li style="">   <img class=""  v-if="project.images[2].src"  :src="project.images[2].src" alt="">  </li> -->
        <div class="slide1 "  v-bind:style="{ backgroundImage: 'url(' + slider4  + ')' }" ></div>
      </slide>


      <hooper-navigation slot="hooper-addons">  </hooper-navigation>

    </hooper>





      <!-- </div> -->


   </div>
</div>
</div>
<div class="section8 par" id="section8">
  <div class="container-fluid">
    <div class="row">
        <div class="animation-element paragraph par8" style="">
             <h1>   {{section8header}} </h1>
             <h1 class="hide"> {{section8headerruss}}</h1>
             <p>  {{section8text}} </p>
             <p class="hide"> {{section8textruss}} </p>
         </div>
         <div class="equipe1 animation-element slide-left" style="">
             <img :src="imgleft1">
           <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/equipe1.jpg">equipe2 -->
         </div>
         <div class="equipe2a slide-right animation-element " style="">
             <img :src="imgright">
           <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/equipe2.jpg"> -->
         </div>
         <div class="equipe3 animation-element slide-left" style="">
              <img :src="imgleft2">
             <!-- <img src="http://le-mugs.com/wp-content/themes/mugs/images/equipe3.jpg"> -->
         </div></div>
  </div>
</div>
<div class="section9 par" id="section9">
  <div class="container-fluid">
    <div class="row">
    <div class="slide-info">
            <div class="legume legume1" style=""><img src="http://le-mugs.com/wp-content/themes/mugs/images/Fenouil.png"></div>
            <!-- <div class="legume legume2" style="transform: translate3d(0px, 50px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/Legume-1.png"></div>
            <div class="legume legume3" style="transform: translate3d(0px, 350px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/Legume-2.png"></div>
            <div class="legume legume4" style="transform: translate3d(0px, 75px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/oignon.png"></div>
            <div class="legume legume5" style="transform: translate3d(0px, 150px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/Salade.png"></div>
            <div class="legume legume6" style="transform: translate3d(0px, 300px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/Celeri.png"></div>
            <div class="legume legume7" style="transform: translate3d(0px, 500px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/courge.png"></div>
            <div class="legume legume8" style="transform: translate3d(0px, 200px, 0px);"><img src="http://le-mugs.com/wp-content/themes/mugs/images/tomates.png"></div> -->
        </div>
    <!-- <div class="row"> -->
      <div class="info-container">
      <div class="info  animated" id="info">
      <div class="horaires">
        <div class="title">
            <h3>{{section9header}}</h3>
            <h3 class="hide"> {{section9headerruss}}</h3>
            <div class="days">
             <p>  {{section9lefttext}} </p>
               <p class="hide"> {{section9lefttextruss}} </p>
            </div>

            <!-- <div class="days">

            </div> -->
            <div class="hours">
                <p>  {{section9righttext}}      </p>
                <p class="hide">  {{section9righttextruss}}  </p>
            </div>
          </div>
        </div>
      </div>

    </div>
    <!-- </div> -->
    <!-- <div class="row"> src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
      &q=1827 W Verdugo Ave" allowfullscreen> -->
       <!-- {{sectionmap}}
        <iframe
           width="600"
           height="450"
           frameborder="0" style="border:0"
           :src="iframeUrl"
              allowfullscreen>
         </iframe> -->

         <iframe
            width="600"
            height="450"
            frameborder="0" style="border:0"
            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
              &q=Los Angeles, CA, USA"
               allowfullscreen>
          </iframe>

         <!-- <iframe
            width="600"
            height="450"
            frameborder="0" style="border:0" src ="maparam"
                 allowfullscreen>
          </iframe> -->
    <!-- </div> -->
    </div>
  </div>
</div>


<div class="footer">


       <div class="formcontent" id="subForm">

				<div class="text_wrapp col-md-6">
					<input name="add_email" id="add_email"  type="email"  v-model="emailsubscribe"  :placeholder="carttable.placeholder" required="">
				</div>

				<div class="bnt_wrapp col-md-6">
            <a href="#" v-on:click="addsubscribe(emailsubscribe)" class="btn"> {{carttable.subscribebut}}</a>

				</div>

      </div>


</div>

<!-- <Footer/> -->



<!-- <div class="apisection">
 <p> I am here </p>
 {{homeback}}
   {{slider1logo1}}
</div> -->
   </div>
  </div>
</div>
</template>
<script>

  // import '../assets/js/custom.js'
  import Header from '../components/Header';
  import Footer from '../components/Footer';
  import sectio1Api from '@/services/api/section1.js'
  import { Hooper, Slide, Navigation as HooperNavigation  } from 'hooper'
  import 'hooper/dist/hooper.css'
  import axios from 'axios'
  const oauthSignature   = require('oauth-signature');
  //Vue.http.options.root = 'http://localhost/mugs/';
   // import {HTTP} from '../http-common';
   // import {
   //  Hooper,
   //  Slide,
   //  Navigation as HooperNavigation
   //  } from 'hooper';


  export default {
    //name:'getSectionField',
    name:'getSectionWoocommproduct',
    components: {
      Header,
      Footer,
     Hooper,
     Slide,
      HooperNavigation

   },
   // props: [''],
    data() {
      return {
        products: [],
        //errors: [],
        loading:true,
        pages: [],
        obj:{},
        pageone:'',
        hometextrus :' ',
        homeback: '',
        headerlogo: '',
        headerslider1: ' ',
        headertextsect2: '',
        headertextsect2rus: '',
        headertextsect2a: '',
        headertextsect2aruss : '',

        barbeqlogo: '',

        slider1logo1: '',
        slider1logo2: '',
        slider1logo3: ' ',
        slider1logo4: ' ',
        slider2logo1: ' ',
        slider2logo2: ' ',
        slider2logo3: ' ',
        slider2logo4: ' ',
        slider2text: ' ',
        slider2textruss: ' ',
        headertextsect2b: '',
        headertextsect2bruss: '',
        slider3logo1: ' ',
        slider3logo2: ' ',
        slider3logo3: ' ',
        slider3logo4: ' ',
        slider3text: ' ',
        slider3textruss: ' ',
        section3backimg: ' ',
        section3img: ' ',
        section3header: ' ',
        section3headerruss: ' ',
        section3text: ' ',
        section3textruss: ' ',
        section4backimg: ' ',
        section4head: ' ',
        section4headruss: ' ',
        section4text: ' ',
        section4textruss: ' ',
        section5backimg: ' ',
        section5header: ' ',
        section5headerruss: ' ',
        section5text: ' ',
        section5textruss:' ',
        section5img1: ' ',
        section5img2: ' ',
        section5img3: ' ',
        section6header: ' ',
        section6headerruss: ' ',
        section6text: ' ',
        section6textruss: ' ',
        section6img: ' ',slider1: '', slider2: '',slider3: '',slider4: '',
        imgleft1: ' ',imgleft2: ' ', imgright: ' ', section8header: ' ',section8headerruss: ' ',  section8text: ' ', section8textruss: ' ',
        section9header: ' ',section9headerruss:' ',  section9lefttext: ' ', section9lefttextruss: ' ', section9righttext: ' ', section9righttextruss: ' ', sectionmap: ' ',maparam: ' ',
        product1: ' ',
        projects:[],
        fields:{},
        fieldscat: {},
        projectsa:[],
        categories:[],
        categoriespitzza:[],
        categoriesbarbecue:[],
        categoriesall:[],
        viewcarts:[],
        addtocarts:[],
        addtocarts2:[],
        addtocarts3:[],
        totalcarta:[],
        category1:'',
        category1russ:'',
        category2:'',
        category2russ:'',
        category3:'',
        category3russ:'',

        dexnerv:2,

        footertext: '',
        footertextruss: '',

        list: '',
        ip: "",

        menu1: ' ',
        menu1r: ' ',
        menu2: ' ',
        menu2r: ' ',
        menu3: ' ',
        menu3r: ' ',
        menu4: ' ',
        menu4r: ' ',
        menu5: ' ',
        menu5r: ' ',
        menu5a: ' ',
        menu5ar: ' ',
        menu6: ' ',
        menu6r: ' ',
        menu7: ' ',
        menu7r: ' ',
        menu8: ' ',
        menu8r: ' ',
        menu9: ' ',
        menu9r: ' ',
        menu10: ' ',
        menu10r: ' ',

        emailsubscribe: '',

        firstname:'',
        lastname:'',
        billingaddress1: '',
        billingaddress2: '',
        billingcity: '',
        billingcompany: '',
        billingcountry: '',
        billingemail: '',
        billingphone: '',
        billingpostcode: '',
        billingcomments: '',
        paymentmethod: ' ',

      //  quantityf: '',
      //  quantityf: 0,
          quantityf: [],


        methodpay: '',
        productstitles:[],
        producttitle: ' ',
        producttitle1: ' ',
        producttitle1a: [],
        errors: [],

          carttable : {
                 delete:"Delete",
                 thumbnail:"Thumbnail",
                 product:"Product",
                 price: "Price",
                  quantity: "Quantity",
                  subtotal: "Subtotal",
                  update: "Update",
                  totalcart:"Total Cart",
                  addtocart:"Add to Cart",
                  viewcartbutton:"View Product",
                  homemenu:"Home",
                  checkout:"Checkout",
                  products:"Products",
                  placeholder:"Enter your email here",
                  subscribebut: "Subscribe",

              },

          checkouttable : {
                 billingdetail:"Billing Detail",
                 firstname: "First Name",
                 lastname:"Last Name",
                 companyname:"Company Name",
                 county:"Country",
                 selectcountry:"Select Country",
                 selectoption: "Select an option...",
                 streetaddress: "Street address",
                 apartment: "Apartment, suite, unit etc.",
                 town: "Town / City",
                 state:"State / County",
                 postcode:"Postcode/ZIP",
                 phone: "Phone",
                 email:"Email Address",
                 additionalgeneration: "Additional information",
                 ordernotes: "Order notes (optional)",
                 yourorder: "Your Order",
                 total:"Total",
                 basc:"Direct bank transfer",
                 bascdesc:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
                 cheque: "Check payments",
                 chequedesc: "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
                 cod: "Cash on delivery",
                 coddesc: "Pay with cash upon delivery.",
                 paypal:"Paypal",
                 paypaldesc:"Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
                 whatispaypal:"What is Paypal?",
                 placeorder:"Place Order"
              },

        // data: [
        //   '<div class="example-slide">Slide 1</div>',
        //   '<div class="example-slide">Slide 2</div>',
        //   '<div class="example-slide">Slide 3</div>',
        // ],
       //  data: [
       //   {
       //     id: 1,
       //     message: 'Rolling broadcast message',
       //     content(createElement, content) {
       //       return createElement('a', {
       //         attrs: {
       //           href: '#',
       //         },
       //
       //         class: 'broadcast-content',
       //       }, [
       //         createElement('span', [`${content.message} ${content.id}`]),
       //         createElement('feather', {
       //           props: {
       //             size: 16,
       //             type: 'chevron-right',
       //           },
       //         }),
       //       ]);
       //     },
       //   },
       //   {
       //     id: 2,
       //     message: 'Rolling broadcast message',
       //     content(createElement, content) {
       //       return createElement('a', {
       //         attrs: {
       //           href: '#',
       //         },
       //
       //         class: 'broadcast-content',
       //       }, [
       //         createElement('span', [`${content.message} ${content.id}`]),
       //         createElement('feather', {
       //           props: {
       //             size: 16,
       //             type: 'chevron-right',
       //           },
       //         }),
       //       ]);
       //     },
       //   },
       //   {
       //     id: 3,
       //     message: 'Rolling broadcast message',
       //     content(createElement, content) {
       //       return createElement('a', {
       //         attrs: {
       //           href: '#',
       //         },
       //
       //         class: 'broadcast-content',
       //       }, [
       //         createElement('span', [`${content.message} ${content.id}`]),
       //         createElement('feather', {
       //           props: {
       //             size: 16,
       //             type: 'chevron-right',
       //           },
       //         }),
       //       ]);
       //     },
       //   },
       // ],


        // datainp: {
        //       product_id: "12",
        //       quantity: "1"
        // },

        // product_id: "12",
        // quantity: "1",
        // response: "",
        // totalcart: 0
      }
    },
      created:function() {
        return axios.get('http://localhost/mugs/wp-json/acf/v3/pages').then(response=>{
         for(let project in response.data) {
           this.projects.push(response.data[project]);
         }
       }, error=> {
        alert(error);
      });
    },

    methods:{


      changerussion : function() {
                  this.carttable.delete = "Удалить";
                  this.carttable.thumbnail= "Картина";
                  this.carttable.product= "Товар";
                  this.carttable.price= "Чена";
                  this.carttable.quantity= "Количество";
                  this.carttable.subtotal= "Подуровень";
                  this.carttable.update= "Обновить";
                  this.carttable.totalcart = "Общая Корзина",
                  this.carttable.viewcartbutton ="View Productrus",
                  this.carttable.addtocart ="Добавить в Корзину",
                  this.carttable.placeholder= "Введите свой адрес э. почты",
                    this.carttable.subscribebut= "Подписываться",
                  this.carttable.homemenu = "Главная",
                  this.carttable.checkout = "Испытание",
                    this.carttable.products = "Товары",
                  this.checkouttable.billingdetail="Платежная информация",
                  this.checkouttable.firstname="Имя",
                  this.checkouttable.lastname="Фамилия",
                  this.checkouttable.companyname="Название Компании",
                  this.checkouttable.county="Страна",
                  this.checkouttable.selectcountry= "Выберите страну...",
                  this.checkouttable.selectoption="Выберите опцию ...",
                  this.checkouttable.streetaddress="Адрес улицы",
                  this.checkouttable.apartment="Квартира, люкс, блок и т. Д.",
                  this.checkouttable.town="Город",
                  this.checkouttable.state="Штат / Страна",
                  this.checkouttable.postcode="Почтовый индекс",
                  this.checkouttable.phone="Телефон",
                  this.checkouttable.email="Эл. адрес",
                  this.checkouttable.additionalgeneration= "Дополнительная информация",
                  this.checkouttable.ordernotes = "Примечания к заказу (необязательно)",
                  this.checkouttable.yourorder ="Твоя очередь",
                  this.checkouttable.total ="Сумма",
                  this.checkouttable.basc= "Прямой банковский перевод",
                  this.checkouttable.bascdesc= "Внесите платеж прямо на наш банковский счет. Пожалуйста, используйте ваш идентификатор заказа в качестве ссылки для оплаты. Ваш заказ не будет отправлен, пока средства не будут очищены на нашем счете.",
                  this.checkouttable.cheque= "Проверить платежи",
                  this.checkouttable.chequedesc= "Пожалуйста, отправьте чек в Название магазина, Улица магазина, Город магазина, Штат Штат / округ, Почтовый индекс магазина.",
                  this.checkouttable.cod= "Оплата при доставке",
                  this.checkouttable.coddesc= "Оплата наличными при доставке.",
                  this.checkouttable.paypal= "Пайпал",
                  this.checkouttable.paypaldesc= "Оплатить через Пайпал; Вы можете оплатить с помощью кредитной карты, если у вас нет учетной записи Пайпал.",
                  this.checkouttable.whatispaypal= "Что такое Пайпал?",
                  this.checkouttable.placeorder ="Разместить заказ",

                  jQuery("#ru-lang").click(function(event){
                    jQuery(".bloc h1:first-child").removeClass("show");
                    jQuery(".bloc h1:first-child").addClass("hide");
                    jQuery(".bloc h1:nth-last-child(1)").addClass("show");


                    jQuery(".panel .titleObj h2:nth-last-child(1)").addClass("show");
                    jQuery(".panel .titleObj h2:first-child").removeClass("show");
                    jQuery(".panel .titleObj h2:first-child").addClass("hide");


                    jQuery(".panel .pObj p:nth-last-child(1)").addClass("show");
                    jQuery(".panel .pObj p:first-child").removeClass("show");
                    jQuery(".panel .pObj p:first-child").addClass("hide");


                    jQuery(".window-cerf .textOverparallax h1:nth-last-child(3)").addClass("show");
                    jQuery(".window-cerf .textOverparallax h1:first-child").removeClass("show");
                    jQuery(".window-cerf .textOverparallax h1:first-child").addClass("hide");


                    jQuery(".window-cerf .textOverparallax .textruss").addClass("show");
                    jQuery(".window-cerf .textOverparallax .texteng").removeClass("show");
                    jQuery(".window-cerf .textOverparallax .texteng").addClass("hide");



                  jQuery(".window-section4-text h1:nth-child(2)").addClass("show");
                  jQuery(".window-section4-text h1:first-child").removeClass("show");
                  jQuery(".window-section4-text  h1:first-child").addClass("hide");

                  jQuery(".window-section4-text p:nth-last-child(1)").addClass("show");
                  jQuery(".window-section4-text p:nth-last-child(2)").removeClass("show");
                  jQuery(".window-section4-text  p:nth-last-child(2)").addClass("hide");

                  jQuery(".calme .title h1:nth-child(2)").addClass("show");
                  jQuery(".calme .title h1:first-child").removeClass("show");
                  jQuery(".calme .title  h1:first-child").addClass("hide");


                  jQuery(".calme .title p:nth-last-child(1)").addClass("show");
                  jQuery(".calme .title p:nth-last-child(2)").removeClass("show");
                  jQuery(".calme .title p:nth-last-child(2)").addClass("hide");

                  jQuery(".text-section6 h1:nth-child(2)").addClass("show");
                  jQuery(".text-section6 h1:first-child").removeClass("show");
                  jQuery(".text-section6 h1:first-child").addClass("hide");



                  jQuery(".text-section6 p:nth-last-child(1)").addClass("show");
                  jQuery(".text-section6 p:nth-last-child(2)").removeClass("show");
                  jQuery(".text-section6 p:nth-last-child(2)").addClass("hide");



                  jQuery(".horaires .title h3:nth-child(2)").addClass("show");
                  jQuery(".horaires .title h3:first-child").removeClass("show");
                  jQuery(".horaires .title h3:first-child").addClass("hide");


                  jQuery(".horaires .title .days p:nth-child(2)").addClass("show");
                  jQuery(".horaires .title .days p:first-child").removeClass("show");
                  jQuery(".horaires .title .days p:first-child").addClass("hide");



                  jQuery(".horaires .title .hours p:nth-child(2)").addClass("show");
                  jQuery(".horaires .title .hours p:first-child").removeClass("show");
                  jQuery(".horaires .title .hours p:first-child").addClass("hide");

                  jQuery(".par8 h1:nth-child(2)").addClass("show");
                  jQuery(".par8 h1:first-child").removeClass("show");
                  jQuery(".par8 h1:first-child").addClass("hide");

                  jQuery(".par8 p:nth-last-child(1)").addClass("show");
                  jQuery(".par8 p:nth-last-child(2)").removeClass("show");
                  jQuery(".par8 p:nth-last-child(2)").addClass("hide");


                  jQuery(".modals .project-text  h2:nth-child(2)").addClass("show");
                  jQuery(".modals .project-text h2:first-child").removeClass("show");
                  jQuery(".modals .project-text h2:first-child").addClass("hide");



                jQuery(".categorynames .categ-names:nth-child(2)").addClass("show");
                jQuery(".categorynames .categ-names:first-child").removeClass("show");
                jQuery(".categorynames .categ-names:first-child").addClass("hide");



                  jQuery(".roundbtn .categ-foods:nth-child(2)").addClass("show");
                  jQuery(".roundbtn .categ-foods:first-child").removeClass("show");
                  jQuery(".roundbtn .categ-foods:first-child").addClass("hide");


                  jQuery(".viewcart-product-name div a:nth-last-child(1)").addClass("show");
                  jQuery(".viewcart-product-name div a:first-child").removeClass("show");
                  jQuery(".viewcart-product-name div a:first-child").addClass("hide");


                  jQuery(".checkout-product-name div a:nth-last-child(1)").addClass("show");
                  jQuery(".checkout-product-name div a:first-child").removeClass("show");
                  jQuery(".checkout-product-name div a:first-child").addClass("hide");


                  // jQuery(".vNav .sect-menu .labelactive.labelr").addClass("shown labelactive");
                  // jQuery(".vNav .sect-menu .labelactive.labele").removeClass("shown");
                  // jQuery(".vNav .sect-menu .labelactive.labele").addClass("hiden");
                  // jQuery(".vNav .sect-menu .labelactive.labele").removeClass("labelactive");



                  jQuery(".vNav .sect-menu .labelr").removeClass("hiden");
                  jQuery(".vNav .sect-menu .labelr").addClass("shown");

                  jQuery(".vNav .sect-menu .labele").removeClass("shown");
                  jQuery(".vNav .sect-menu .labele").addClass("hiden");



                  jQuery("#viewcart .cartr").removeClass("hiden");
                  jQuery("#viewcart .cartr").addClass("shown");

                  jQuery("#viewcart .carte").removeClass("shown");
                  jQuery("#viewcart .carte").addClass("hiden");


                  jQuery("#checkout-content div:nth-last-child(1)").removeClass("hiden");
                   jQuery("#checkout-content div:nth-last-child(1)").addClass("shown");

                   jQuery("#checkout-content div:nth-last-child(2)").removeClass("shown");
                    jQuery("#checkout-content div:nth-last-child(2)").addClass("hiden");




                 // jQuery(".footer p:nth-child(2)").removeClass("hiden");
                  jQuery(".footer p:nth-child(2)").addClass("show");

                  jQuery(".footer p:first-child").removeClass("show");
                  jQuery(".footer p:first-child").addClass("hide");



                  jQuery(".project-text-prod  h2:nth-child(2)").addClass("show");

                  jQuery(".project-text-prod  h2:first-child").removeClass("show");
                  jQuery(".project-text-prod  h2:first-child").addClass("hide");

                    event.preventDefault();

                   })

              },
      changeenglish : function() {
            this.carttable.delete = "Delete";
            this.carttable.thumbnail= "Thumbnail";
            this.carttable.product= "Product";
            this.carttable.price= "Price";
            this.carttable.quantity= "Quantity";
            this.carttable.subtotal= "Subtotal";
            this.carttable.update= "Update";
            this.carttable.totalcart = "Total Cart",
                this.carttable.viewcartbutton ="ViewProducteng",
                    this.carttable.homemenu = "Home",
                    this.carttable.checkout = "Checkout",
                      this.carttable.products = "Products",
                      this.carttable.placeholder= "Enter your email here",
                        this.carttable.subscribebut= "Subscribe",
            this.carttable.addtocart ="Add to Cart",
            this.checkouttable.billingdetail="Billing Detail",
            this.checkouttable.firstname="First Name",
            this.checkouttable.lastname="Last Name",
            this.checkouttable.companyname="Company Name",
            this.checkouttable.county="Country",
            this.checkouttable.selectcountry= "Select Country ...",
            this.checkouttable.selectoption="Select an option ...",
            this.checkouttable.streetaddress="Street address",
            this.checkouttable.apartment="Apartment, suite, unit etc.",
            this.checkouttable.town="Town / City",
            this.checkouttable.state="State / County",
            this.checkouttable.postcode="Postcode/ZIP",
            this.checkouttable.phone="Phone",
            this.checkouttable.email="Email Address",
            this.checkouttable.additionalgeneration="Additional Information",
            this.checkouttable.ordernotes ="Order notes (optional)",
            this.checkouttable.yourorder ="Your Order"
            this.checkouttable.total ="Total",
            this.checkouttable.basc= "Direct bank transfer",
            this.checkouttable.bascdesc= "Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
            this.checkouttable.cheque= "Check payments",
            this.checkouttable.chequedesc= "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
            this.checkouttable.cod= "Cash on delivery",
            this.checkouttable.coddesc= "Pay with cash upon delivery.",
            this.checkouttable.paypal= "Paypal",
            this.checkouttable.paypaldesc= "Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
            this.checkouttable.whatispaypal= "What is Paypal?",
            this.checkouttable.placeorder ="Place Order",


            jQuery("#eng-lang").click(function(event){

            jQuery(".bloc h1:first-child").addClass("show");
            jQuery(".bloc h1:nth-last-child(1)").removeClass("show");
            jQuery(".bloc h1:nth-last-child(1)").addClass("hide");

            jQuery(".panel .titleObj h2:first-child").addClass("show");
            jQuery(".panel  .titleObj h2:nth-last-child(1)").removeClass("show");
            jQuery(".panel .titleObj h2:nth-last-child(1)").addClass("hide");


            jQuery(".panel .pObj p:first-child").addClass("show");
            jQuery(".panel .pObj p:nth-last-child(1)").removeClass("show");
            jQuery(".panel .pObj p:nth-last-child(1)").addClass("hide");


            jQuery(".window-cerf .textOverparallax h1:first-child").addClass("show");
            jQuery(".window-cerf .textOverparallax h1:nth-last-child(3)").removeClass("show");
            jQuery(".window-cerf .textOverparallax h1:nth-last-child(3)").addClass("hide");


            jQuery(".window-cerf .textOverparallax .texteng").addClass("show");
            jQuery(".window-cerf .textOverparallax .textruss").removeClass("show");
            jQuery(".window-cerf .textOverparallax .textruss").addClass("hide");



            jQuery(".window-section4-text h1:first-child").addClass("show");
            jQuery(".window-section4-text h1:nth-child(2)").removeClass("show");
            jQuery(".window-section4-text h1:nth-child(2)").addClass("hide");

            jQuery(".window-section4-text p:nth-last-child(2)").addClass("show");
            jQuery(".window-section4-text p:nth-last-child(1)").removeClass("show");
            jQuery(".window-section4-text p:nth-last-child(1)").addClass("hide");


            jQuery(".calme .title h1:first-child").addClass("show");
            jQuery(".calme .title h1:nth-child(2)").removeClass("show");
            jQuery(".calme .title h1:nth-child(2)").addClass("hide");

            jQuery(".calme .title p:nth-last-child(2)").addClass("show");
            jQuery(".calme .title p:nth-last-child(1)").removeClass("show");
            jQuery(".calme .title p:nth-last-child(1)").addClass("hide");

            jQuery(".text-section6 h1:first-child").addClass("show");
            jQuery(".text-section6 h1:nth-child(2)").removeClass("show");
            jQuery(".text-section6 h1:nth-child(2)").addClass("hide");



            jQuery(".text-section6 p:nth-last-child(2)").addClass("show");
            jQuery(".text-section6 p:nth-last-child(1)").removeClass("show");
            jQuery(".text-section6 p:nth-last-child(1)").addClass("hide");




            jQuery(".horaires .title h3:first-child").addClass("show");
            jQuery(".horaires .title h3:nth-child(2)").removeClass("show");
            jQuery(".horaires .title h3:nth-child(2)").addClass("hide");



            jQuery(".horaires .title .days p:first-child").addClass("show");
            jQuery(".horaires .title .days p:nth-child(2)").removeClass("show");
            jQuery(".horaires .title .days p:nth-child(2)").addClass("hide");


            jQuery(".horaires .title .hours p:first-child").addClass("show");
            jQuery(".horaires .title .hours p:nth-child(2)").removeClass("show");
            jQuery(".horaires .title .hours  p:nth-child(2)").addClass("hide");

            jQuery(".par8 h1:first-child").addClass("show");
            jQuery(".par8 h1:nth-child(2)").removeClass("show");
            jQuery(".par8 h1:nth-child(2)").addClass("hide");

            jQuery(".par8 p:nth-last-child(2)").addClass("show");
            jQuery(".par8 p:nth-last-child(1)").removeClass("show");
            jQuery(".par8 p:nth-last-child(1)").addClass("hide");



            jQuery(".modals .project-text h2:first-child").addClass("show");
            jQuery(".modals .project-text h2:nth-child(2)").removeClass("show");
            jQuery(".modals .project-text h2:nth-child(2)").addClass("hide");



            jQuery(".viewcart-product-name div a:first-child").addClass("show");
            jQuery(".viewcart-product-name div a:nth-last-child(1)").removeClass("show");
            jQuery(".viewcart-product-name div a:nth-last-child(1)").addClass("hide");


            jQuery(".checkout-product-name div a:first-child").addClass("show");
            jQuery(".checkout-product-name div a:nth-last-child(1)").removeClass("show");
            jQuery(".checkout-product-name div a:nth-last-child(1)").addClass("hide");




            jQuery(".categorynames .categ-names:first-child").addClass("show");
            jQuery(".categorynames .categ-names:nth-child(2)").removeClass("show");
            jQuery(".categorynames .categ-names:nth-child(2)").addClass("hide");


            jQuery(".roundbtn .categ-foods:first-child").addClass("show");
            jQuery(".roundbtn .categ-foods:nth-child(2)").removeClass("show");
            jQuery(".roundbtn .categ-foods:nth-child(2)").addClass("hide");





            // jQuery(".vNav .sect-menu .labelactive.labele").addClass("shown labelactive");
            // jQuery(".vNav .sect-menu .labelactive.labelr").removeClass("shown");
            // jQuery(".vNav .sect-menu .labelactive.labelr").addClass("hiden");
            // jQuery(".vNav .sect-menu .labelactive.labelr").removeClass("labelactive");


            jQuery(".vNav .sect-menu .labele").removeClass("hiden");
            jQuery(".vNav .sect-menu .labele").addClass("shown");

            jQuery(".vNav .sect-menu .labelr").removeClass("shown");
            jQuery(".vNav .sect-menu .labelr").addClass("hiden");




            jQuery("#viewcart .carte").removeClass("hiden");
              jQuery("#viewcart .carte").addClass("shown");

            jQuery("#viewcart .cartr").removeClass("shown");
             jQuery("#viewcart .cartr").addClass("hiden");

            jQuery("#checkout-content div:nth-last-child(2)").removeClass("hiden");
             jQuery("#checkout-content div:nth-last-child(2)").addClass("shown");

             jQuery("#checkout-content div:nth-last-child(1)").removeClass("shown");
             jQuery("#checkout-content div:nth-last-child(1)").addClass("hiden");


             // jQuery(".footer p:first-child").removeClass("hiden");
              jQuery(".footer p:first-child").addClass("show");

              jQuery(".footer p:nth-child(2)").removeClass("show");
              jQuery(".footer p:nth-child(2)").addClass("hide");

                event.preventDefault();

            })

      },



      getSectionProductField:function(id, field) {
        return axios.get('http://localhost/mugs/wp-json/acf/v3/pages/' +id+"/"+field).then(response => {
          return response;
        })
      },

      addtocart:function(product_id, quantity) {
        //console.log("adddcarteli");
        var httpMethod = 'POST';
        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var url ="http://localhost/mugs/wp-json/wc/v2/cart/add/";
        var parameters = {

              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'

          }

          var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
          var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

          var string = 'OAuth ';
          for (var key in parameters) {
             if (parameters.hasOwnProperty(key)) {
                 string += key + '=' + parameters[key] + ',';
             }
          }
          string += 'oauth_signature=' + signature;

            //console.log("addddd");

        return  axios.post(url,  {'product_id':product_id,'quantity':1},
             { headers: {  'Authorization': string }  }
           ).then(response => {
              // console.log("addddd");
              //comm
              sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
              });

             console.log(response);
            return response;
          });

      },

      updatecart:function(cart_item_key, quantity) {
        //console.log("adddcarteli");
        var httpMethod = 'POST';
        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var url ="http://localhost/mugs/wp-json/wc/v2/cart/cart-item/";
        var parameters = {

              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'

          }

          var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
          var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

          var string = 'OAuth ';
          for (var key in parameters) {
             if (parameters.hasOwnProperty(key)) {
                 string += key + '=' + parameters[key] + ',';
             }
          }
          string += 'oauth_signature=' + signature;

            //console.log("addddd");

        return  axios.post(url,  {'cart_item_key':cart_item_key,'quantity':quantity},
             { headers: {  'Authorization': string }  }
           ).then(response => {
              // console.log("addddd");

              ////commm
              sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
              });

             console.log(response);
            return response;
          });

      },



     viewcart:function() {

        var httpMethod = 'GET';
        var timestamp=Math.round(Date.now()/1000);
        var   url = 'http://localhost/mugs/wp-json/wc/v2/cart';
        //var url ='http://localhost/mugs/wp-json/wc/v3/products/categories';
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var parameters = {
              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'
          }
          var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
          var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
         var string = 'OAuth ';
         for (var key in parameters) {
            if (parameters.hasOwnProperty(key)) {
                string += key + '=' + parameters[key] + ',';
            }
         }
        string += 'oauth_signature=' + signature ;

        return axios.get(url,
           { headers: {  'Authorization': string }  }
         ).then(response => {
          return response;
        });



      },

      deletetocart:function(cart_item_key) {
        console.log("deletecarteli");
        var httpMethod = 'DELETE';
        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var url ="http://localhost/mugs/wp-json/wc/v2/cart/cart-item/";
        var parameters = {
              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'
          }

          var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
          var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

          var string = 'OAuth ';
          for (var key in parameters) {
             if (parameters.hasOwnProperty(key)) {
                 string += key + '=' + parameters[key] + ',';
             }
          }
          string += 'oauth_signature=' + signature;


          console.log(string);

            //console.log("addddd");

        // return  axios.delete(url, { headers: {  'Authorization': string }  }, {data:{'cart_item_key':cart_item_key}}
          return  axios.delete(url,  {data:{'cart_item_key':cart_item_key}, headers: {  'Authorization': string }}
           ).then(response => {
             ///commm
             sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
             });
              // console.log("addddd");
             console.log(response);
            return response;
          });

      },

      totalcart:function(){
         ///
         var httpMethod = 'GET';
         var timestamp=Math.round(Date.now()/1000);
         var   url = 'http://localhost/mugs/wp-json/wc/v2/cart/totals';
         //var url ='http://localhost/mugs/wp-json/wc/v3/products/categories';
         var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
         var parameters = {
               'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
               'oauth_nonce' : nonce,
               'oauth_timestamp' : timestamp,
               'oauth_signature_method' : 'HMAC-SHA1'
           }
           var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
           var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);
          var string = 'OAuth ';
          for (var key in parameters) {
             if (parameters.hasOwnProperty(key)) {
                 string += key + '=' + parameters[key] + ',';
             }
          }
         string += 'oauth_signature=' + signature ;

         return axios.get(url,
            { headers: {  'Authorization': string }  }
          ).then(response => {

            sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
            });
            // sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
            // });
           return response;
         });
      },


      processpayment:function(order_id, payment_method) {
        console.log("I am process payment");

        var url ="http://localhost/mugs/wp-json/wc/v2/process_payment/";
        var httpMethod = 'POST';
        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var parameters = {
              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'
          }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;

        return  axios.post(url,  {'order_id':order_id,'payment_method':payment_method},
             { headers: {  'Authorization': string }  }
           ).then(response => {
             // console.log("chigalissspaymentaddddd");

             console.log(response);
             sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
              });
            return response;
          });


      },
      processcheckout:function(billing_first_name,billing_last_name,billing_company,billing_country,billing_address_1,billing_address_2,billing_city,billing_postcode,billing_phone,billing_email,
      order_comments,methodpay) {
        console.log("I am process checkout");

        var url ="http://localhost/mugs/wp-json/wc/v2/cart/process_checkout_wc/";
        var httpMethod = 'POST';
        var timestamp=Math.round(Date.now()/1000);
        var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
        var parameters = {
              'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
              'oauth_nonce' : nonce,
              'oauth_timestamp' : timestamp,
              'oauth_signature_method' : 'HMAC-SHA1'
          }

        var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
        var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

        var string = 'OAuth ';
        for (var key in parameters) {
           if (parameters.hasOwnProperty(key)) {
               string += key + '=' + parameters[key] + ',';
           }
        }
        string += 'oauth_signature=' + signature;



        return  axios.post(url,  {'billing_first_name':billing_first_name,'billing_last_name':billing_last_name,
          'billing_company':billing_company, 'billing_country':billing_country, 'billing_address_1':billing_address_1, 'billing_address_2':billing_address_2,
          'billing_city':billing_city, 'billing_postcode':billing_postcode, 'billing_phone':billing_phone, 'billing_email':billing_email,
          'order_comments':order_comments,'methodpay':methodpay },
             { headers: {  'Authorization': string }  }
           ).then(response => {
             //console.log("chigalissspaymentaddddd");
             console.log(response);
             this.processpayment( response.data, methodpay);
             sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
             });
            return response;
          });

      },


     addsubscribe:function(add_email) {

       var url ="http://localhost/mugs/wp-json/subscription/v1/emailsub";
       var httpMethod = 'POST';



       var timestamp=Math.round(Date.now()/1000);
       var nonce = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 6);
       var parameters = {
             'oauth_consumer_key' : 'ck_c730f9e077e564101db07be014d8701187098d70',
             'oauth_nonce' : nonce,
             'oauth_timestamp' : timestamp,
             'oauth_signature_method' : 'HMAC-SHA1'
         }

       var consumerSecret = 'cs_85520983dd05c56f87bb83f7d506bf400f8f5da1';
       var signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret);

       var string = 'OAuth ';
       for (var key in parameters) {
          if (parameters.hasOwnProperty(key)) {
              string += key + '=' + parameters[key] + ',';
          }
       }
       string += 'oauth_signature=' + signature;
       console.log(string);

               console.log("I am email subscibe");

      /// return  axios.post(url,  {'add_email':add_email },


      return  axios.post(url,  {'add_email':add_email},
           { headers: {  'Authorization': string }  }
         ).then(response => {
           console.log(response);
          return response;
        });

      // return axios.get(url,
      //    { headers: {  'Authorization': string }  }
      //  ).then(response => {
      //      console.log("I am email subscibe1");
      //   return response;
      // });

       // return  axios.get(url,
       // { headers: {  'Authorization': string }  }
       //    ).then(response => {
       //
       //      console.log(response);
       //             console.log("I am email subscibe1");
       //
       //     return response;
       //   });

     },




    },
    mounted: function () {
      // this.getCart();
      //this.total();
      this.getSectionProductField(id, field);
      this.addtocart(product_id, quantity);
      this.updatecart(cart_item_key, quantity);
      this.processpayment(order_id, payment_method);
      this.processcheckout(billing_first_name,billing_last_name,billing_company,billing_country,billing_address_1,billing_address_2,billing_city,billing_postcode,billing_phone,billing_email,
      order_comments,methodpay);
      this.deletetocart(cart_item_key);

      this.addsubscribe(add_email);


    },

    computed: {
        iframeUrl: function (sectionmap) {
          // https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s
          //   &q=1827 W Verdugo Ave
            return 'https://www.google.com/maps/embed/v1/place?key=AIzaSyAU9942IQIFjNETyBwIskb_NuVF2dMNm_s&q={sectionmap}';
      }
    },

    mounted() {
          // axios({ method: "GET", "url": "https://httpbin.org/ip" }).then(result => {
          //     this.ip = result.data.origin;
          //     //console.log(ip);
          // }, error => {
          //     console.error(error);
          // });

          // this.nextTick(()=> {
            jQuery(document).ready(function (){
               jQuery('.carousel').carousel();

               jQuery(".closes").click(function(){
                   $("body").css("overflow","auto");
                   $(this).parents(".modals").css("display","none");

                   jQuery("#section1-slider").addClass("img-wid2");


                });

               jQuery(".roundbtn").click(function(){
                     jQuery(this).parents(".rollover").next(".modals").css("display","block");
                    jQuery(this).parents(".rollover").next(".modals").addClass("in");

                  // $("body").css("overflow","hidden");
                });

                jQuery(".closesa").click(function(){
                    $("body").css("overflow","auto");
                   $(this).parents(".modals").css("display","none");
                    jQuery("#section1-slider").removeClass("img-wid2a");
                    jQuery("#section1-slider").addClass("img-wid2");

                 });



                 var x = jQuery('#desc').html();
                 jQuery('.rollover').click(function() {
                    //console.log(x);
                    //jQuery(".desc").css("color","red");
                     //var p = $(".desc").find('p');
                    jQuery("#desc").find('p').text();
                     jQuery('body').append(x);
                 });

                   // $(".abc").on("load", function() {
                   //     alert('started');
                   // }

               jQuery('body').on('load', '.desc', function(){
                 jQuery(".desc").css("display","none");
                  alert("desc exists");
               });



                jQuery('.vNav ul li a').click(function(){
                     jQuery('html, body').animate({
                        scrollTop: jQuery( jQuery.attr(this, 'href') ).offset().top
                    }, 800);
                     return false;
                   });

                   jQuery('.vNav a').hover(function() {
                           jQuery(this).find('div').show();
                           }, function() {
                           jQuery(this).find('div').hide();
                   });


                   jQuery(document).scroll(function(){
                   var parPosition = [];
                   jQuery('.par').each(function() {
                         parPosition.push(jQuery(this).offset().top);
                     });
                   var position = jQuery(document).scrollTop();
                   var index;
                        for (var i=0; i<parPosition.length; i++) {
                        index=0;
                        if(i!=9) {
                          // console.log(parPosition.length);
                          // console.log(parPosition[10]);
                          // console.log(parPosition[5]);
                           // console.log(position);
                           // console.log(+parPosition[1+1] - +jQuery( window ).height()/2);
                             if (position < +parPosition[i+1] - +jQuery( window ).height()/2 && position >  parPosition[i]-+jQuery( window ).height()/2) {
                                    index = i;
                                    break;
                                 }
                         }
                         else {
                              if ( position >  parPosition[i]-+jQuery( window ).height()/2){
                                 index=9;
                                 break;
                             }
                         }
                     }

                     jQuery('.vNav ul li a').find('div').removeClass('labelactive');
                     jQuery('.vNav ul li a:eq('+index+')').find('div').addClass('labelactive');

                     jQuery('.vNav ul li a').removeClass("circleactive");
                     jQuery('.vNav ul li a:eq('+index+')').addClass('circleactive');
                });


               jQuery('.vNav ul li a').find('div').click(function () {
                 jQuery('.vNav ul li a').find('div').removeClass('labelactive');
                 jQuery(this).addClass('labelactive');

                  jQuery('.vNav ul li a').removeClass("circleactive");
                  jQuery(this).parent("a").addClass('circleactive');
                 });

              // jQuery(".product-name").attr("class", "hii");

              //
              // jQuery('.carousel').carousel();


                 var $animation_elements = $('.animation-element');
                 var $window = $(window);

                 function check_if_in_view() {
                   var window_height = $window.height();
                   var window_top_position = $window.scrollTop();
                   var window_bottom_position = (window_top_position + window_height);

                   $.each($animation_elements, function() {
                     var $element = $(this);
                     var element_height = $element.outerHeight();
                     var element_top_position = $element.offset().top;
                     var element_bottom_position = (element_top_position + element_height);

                     //check to see if this current container is within viewport
                     if ((element_bottom_position >= window_top_position) &&
                         (element_top_position <= window_bottom_position)) {
                         $element.addClass('in-view');


                     } else {
                       $element.removeClass('in-view');
                     }
                   });
                 }

                 $window.on('scroll resize', check_if_in_view);
                 $window.trigger('scroll');


               // Slider


              $('#checkbox').change(function(){
                setInterval(function () {
                    moveRight();
                    moveRightGal();
                }, 3000);
              });

             var slideCount = $('#slider ul li').length;
             var slideWidth = $('#slider ul li').width();
             var slideHeight = $('#slider ul li').height();
             var sliderUlWidth = slideCount * slideWidth;

             $('#slider').css({ width: slideWidth, height: slideHeight });

             $('#slider ul').css({ width: sliderUlWidth, marginLeft: - slideWidth });

                $('#slider ul li:last-child').prependTo('#slider ul');

                function moveLeft() {
                    $('#slider ul').animate({
                        left: + slideWidth
                    }, 200, function () {
                        $('#slider ul li:last-child').prependTo('#slider ul');
                        $('#slider ul').css('left', '');
                    });
                };

                function moveRight() {
                    $('#slider ul').animate({
                        left: - slideWidth
                    }, 200, function () {
                        $('#slider ul li:first-child').appendTo('#slider ul');
                        $('#slider ul').css('left', '');
                    });
                };

                $('a.control_prev').click(function (event) {
                    moveLeft();
                    event.preventDefault();
                });

                $('a.control_next').click(function (event) {
                    moveRight();
                      event.preventDefault();
                });


                // slider gallery


                var slideCountgal = $('#slidergallery ul li').length;
               var slideWidthgal = $('#slidergallery ul li').width();
               var slideHeightgal = $('#slidergallery ul li').height();
               var sliderUlWidthgal = slideCountgal * slideWidthgal;

               $('#slidergallery').css({ width: slideWidthgal, height: slideHeightgal });

               $('#slidergallery ul').css({ width: sliderUlWidthgal, marginLeft: - slideWidthgal });

                  $('#slidergallery ul li:last-child').prependTo('#slidergallery ul');

                  function moveLeftGal() {
                      $('#slidergallery ul').animate({
                          left: + slideWidthgal
                      }, 200, function () {
                          $('#slidergallery ul li:last-child').prependTo('#slidergallery ul');
                          $('#slidergallery ul').css('left', '');
                      });
                  };

                  function moveRightGal() {
                      $('#slidergallery ul').animate({
                          left: - slideWidthgal
                      }, 200, function () {
                          $('#slidergallery ul li:first-child').appendTo('#slidergallery ul');
                          $('#slidergallery ul').css('left', '');
                      });
                  };

                  $('a.control_prev_gal').click(function (event) {
                      moveLeftGal();
                      event.preventDefault();
                  });

                  $('a.control_next_gal').click(function (event) {
                         moveRightGal();
                        event.preventDefault();
                  });


              /////////////

                $(".viewcart-content").find("#viewcart").on("click", function (event){
                      $ ( this ).addClass ( "active" );
                      $ ( this ).next(".content-cart").slideToggle();
                      event.preventDefault();
                });

                $(".checkout-content").find("#checkout-content").on("click", function (event){
                      $ ( this ).addClass ( "active" );
                      $ ( this ).next("#mymodalcheckout").slideToggle();
                      event.preventDefault();
                });


                  });



                  var nerv = 2;



               if(nerv ==2 ) {

                   console.log(nerv);

                  window.onscroll = function() {scrollFunction(); scrollSection2();scrollFunctionSecpanel3(); scrollFunctionSec(); scrollFunctionSecpanel2();  scrollSection4(); scrollSection9();scrollSection5a(); };

                    function scrollFunction() {
                      if (document.documentElement.scrollTop < 700 && document.documentElement.scrollTop > 0) {


                         if(document.getElementById("secton1")) {

                           document.getElementById("secton1").classList.add("fixed-section1");

                             ////document.getElementById("secton1").classList.add("fixed-section1");
                           ////document.getElementsByClassName("section1-slider").style.width= "101%";
                            document.getElementById("containerText").style.display ="block";
                            document.getElementById("containerText").classList.add("fadeInUpBig");
                            document.getElementById("titleslide").style.opacity ="0";
                             document.getElementById("titleslide").classList.remove("fadeInDownBig");
                             document.getElementById("blackscreen").classList.add("fadeIn");


                             if (document.getElementById("section1-slider").classList.contains("img-wid")) {
                                 document.getElementById("section1-slider").classList.remove("img-wid");
                             }

                                //document.getElementById("titleslide").classList.add("fadeInUpBig");
                        }
                      } else {

                        if (!(document.getElementById("section1-slider").classList.contains("img-wid"))) {
                            document.getElementById("section1-slider").classList.add("img-wid");
                        }


                            document.getElementById("secton1").classList.remove("fixed-section1");
                            document.getElementById("containerText").style.display ="none";
                            document.getElementById("containerText").classList.remove("fadeInUpBig");
                             document.getElementById("titleslide").style.opacity ="1";
                             document.getElementById("titleslide").classList.add("fadeInDownBig");
                              document.getElementById("blackscreen").classList.remove("fadeIn");
                      }
                    }


                    function scrollFunctionSec() {
                      if (document.documentElement.scrollTop < 1600) {
                         if(document.getElementById("section2")) {

                            document.getElementById("panel1").classList.add("unfixed-section2");
                            document.getElementById("panel2").classList.add("fixed-section2");
                            //document.getElementById("bg2panel2").classList.add("slide-panel2");
                        }
                      } else {
                              document.getElementById("panel1").classList.remove("unfixed-section2");
                              document.getElementById("panel2").classList.remove("fixed-section2");
                              //  document.getElementById("bg2panel2").classList.remove("slide-panel2");
                      }
                    }


                    function scrollFunctionSecpanel2() {
                      if (document.documentElement.scrollTop < 1200) {
                         if(document.getElementById("section2")) {


                            document.getElementById("panel2").classList.add("unfixed-section2");
                            document.getElementById("panel1").classList.add("fixed-section2");
                        }
                      } else {
                              document.getElementById("panel2").classList.remove("unfixed-section2");
                                document.getElementById("panel1").classList.remove("fixed-section2");
                      }
                    }

                    function scrollFunctionSecpanel3() {
                      if (document.documentElement.scrollTop < 2000) {
                         if(document.getElementById("section2")) {

                             // document.getElementById("panel1").classList.add("unfixed-section2");
                             //  document.getElementById("panel2").classList.add("unfixed-section2");
                            document.getElementById("panel3").classList.add("fixed-section2");
                        }
                      } else {
                                document.getElementById("panel3").classList.remove("fixed-section2");
                                // document.getElementById("panel1").classList.remove("unfixed-section2");
                                //   document.getElementById("panel2").classList.remove("unfixed-section2");
                      }
                    }

                    function scrollSection2() {
                      if (document.documentElement.scrollTop > 500 && document.documentElement.scrollTop < 1800) {
                        document.getElementById("section2").classList.add("fixsect2");
                        document.getElementById("section3").classList.add("topsection3");
                      } else {
                           document.getElementById("section2").classList.remove("fixsect2");
                           document.getElementById("section3").classList.remove("topsection3");
                      }
                    }



                    function scrollSection4() {
                      // if (document.documentElement.scrollTop > 500 && document.documentElement.scrollTop < 1900) {
                      //   document.getElementById("section2").classList.add("fixsect2");
                      // } else {
                      //      document.getElementById("section2").classList.remove("fixsect2");
                      // }
                        if (document.documentElement.scrollTop > 2555 && document.documentElement.scrollTop < 3199) {
                            //document.getElementsByClassName("window-section4-text").classList.add("");
                            document.getElementById("window-section4-text").classList.add("windowsection4text");
                            document.getElementById("window-section4-text").classList.remove("windowsection4text-up");
                        } else {
                          document.getElementById("window-section4-text").classList.remove("windowsection4text");
                          document.getElementById("window-section4-text").classList.add("windowsection4text-up");
                        }

                        // if (document.documentElement.scrollTop < 3199) {
                        // //  document.getElementById("window-section4-text").classList.add("windowsection4text-up");
                        //  }


                    }


                    /*---infotop--*/


                    function scrollSection9() {
                      if (document.documentElement.scrollTop > 5991 ) {
                        document.getElementById("info").classList.add("infoanim");
                        document.getElementById("info").classList.remove("windowsection4text-up");
                        //document.getElementById("info").classList.remove("window-section4-text");
                      } else {
                        document.getElementById("info").classList.remove("infoanim");
                          document.getElementById("info").classList.add("windowsection4text-up");
                      }

                    }
                    /*3856 */
                    function scrollSection5a() {

                      if (document.documentElement.scrollTop > 3823 ) {
                        document.getElementById("sletter").classList.add("Sstroke");
                          document.getElementById("aletter").classList.add("Astroke");
                            document.getElementById("lletter").classList.add("Lstroke");

                           document.getElementById("p1").classList.add("p1stroke");


                             // document.getElementById("cat1").classList.add("flipInX");


                      } else {

                        document.getElementById("sletter").classList.remove("Sstroke");
                        document.getElementById("aletter").classList.remove("Astroke");
                        document.getElementById("lletter").classList.remove("Lstroke");

                         document.getElementById("p1").classList.remove("p1stroke");
                             // document.getElementById("cat1").classList.remove("flipInX");

                      }

                      if (document.documentElement.scrollTop > 4300 ) {
                        document.getElementById("p2").classList.add("p2stroke");
                         // document.getElementById("cat2").classList.add("flipInX");

                      }
                      else {
                           document.getElementById("p2").classList.remove("p2stroke");
                            // document.getElementById("cat2").classList.remove("flipInX");
                      }

                      if (document.documentElement.scrollTop > 4800 ) {

                        document.getElementById("p3").classList.add("p3stroke");
                        // document.getElementById("cat3").classList.add("flipInX");

                      }
                      else {
                           document.getElementById("p3").classList.remove("p3stroke");
                            // document.getElementById("cat3").classList.remove("flipInX");
                      }

                    }

                  }

                  // }
                  // else {
                  //   console.log("not exist1");
                  // }

                  //}


                    // e.preventDefault();
          // });
    },
    created() {
      // sectio1Api.getSectionWoocommproduct(12).then(product1=>{ this.product1=product1.data["name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      // sectio1Api.getSectionWoocommproduct().then(products=>{ this.products=products.data["name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      //  })
        // sectio1Api.getSectionWoocommproduct(12);
      sectio1Api.getProductCategory(16).then(categories=>{ this.categories=categories.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })
        sectio1Api.getProductCategory(17).then(categoriespitzza=>{ this.categoriespitzza=categoriespitzza.data}).catch(error => console.log(error)).finally(() => {this.loading = true
          })
       sectio1Api.getProductCategory(18).then(categoriesbarbecue=>{ this.categoriesbarbecue=categoriesbarbecue.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })


        sectio1Api.getProductCategories().then(categoriesall=>{ this.categoriesall=categoriesall.data}).catch(error => console.log(error)).finally(() => {this.loading = true
        })

          // sectio1Api.getSectionField(454, "category1").then(category1=>{ this.category1=category1.data["category1"];}).catch(error => console.log(error)).finally(() => {this.loading = true
          // })

        // sectio1Api.getProductCategories().then(async function(categoriesall){
        //
        //   let data = categoriesall.data;
        //   var fieldscat = {};
        // for( let i = 0; i < data.length; i++){
        //   await sectio1Api.getSectionField(454, "category1russ").then(async function(ttt){
        //     fieldscat[(data[i]).id] = await ttt.data["category1russ"];
        //   }).catch(error => console.log(error)).finally(() => {})
        // }
        // console.log(fieldscat)
        //   return fieldscat;
        // }).then(fieldscat=>{ this.fieldscat=fieldscat}).catch(error => console.log(error)).finally(() => {this.loading = true
        // })


       sectio1Api.getSectionWoocommproduct().then(projects=>{ this.projects=projects.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       })

              sectio1Api.getSectionWoocommproduct().then(async function(products){
                let data = products.data;
                var fields = {};
              for( let i = 0; i < data.length; i++){
                await sectio1Api.getSectionProductField((data[i]).id,"product-title-russ").then(async function(ttt){
                  fields[(data[i]).id] = await ttt.data["product-title-russ"];
                }).catch(error => console.log(error)).finally(() => {})
              }
              // console.log(fields)
              return fields;
            }).then(fields=>{ this.fields=fields}).catch(error => console.log(error)).finally(() => {this.loading = true
              })
       // sectio1Api.getSectionProductField(12,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       // })

       sectio1Api.getSectionProductField(179,"product-title-russ").then(producttitle=>{ this.producttitle=producttitle.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       })



       // sectio1Api.getSectionProductField( sectio1Api.getSectionWoocommproduct().then(projectsa=>{ this.projectsa=projectsa.data["id"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       //    }),"product-title-russ").then(producttitle1a=>{ this.producttitle1a=producttitle1a.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       // })

       // sectio1Api.getSectionProductField(id,"product-title-russ").then(productstitles=>{ this.productstitles=productstitles.data["product-title-russ"]}).catch(error => console.log(error)).finally(() => {this.loading = true
       // })





       // sectio1Api.addtocart(12,1).then(addtocarts=>{ this.addtocarts=addtocarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       //  })
       // sectio1Api.addtocart(179,1).then(addtocarts2=>{ this.addtocarts2=addtocarts2.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       //  })
       // sectio1Api.addtocart(181,1).then(addtocarts3=>{ this.addtocarts3=addtocarts3.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       //  })



    sectio1Api.totalcart().then(totalcarta=>{ this.totalcarta = totalcarta.data

       }).catch(error => console.log(error)).finally(() => {this.loading = true
    })


     // sectio1Api.totalcart().then(async function(totalcarta){
     //     let data = totalcarta.data;
     //     //var fieldscat = {};
     //   // for( let i = 0; i < data.length; i++){
     //   //   await sectio1Api.getSectionProductField((data[i]).id,"product-title-russ").then(async function(ttt){
     //   //     fields[(data[i]).id] = await ttt.data["product-title-russ"];
     //   //   }).catch(error => console.log(error)).finally(() => {})
     //   // }
     //   return  await sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
     //    });
     //   return data;
     // }).catch(error => console.log(error)).finally(() => {this.loading = true
     //  })

      sectio1Api.viewcart().then(viewcarts=>{ this.viewcarts=viewcarts.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       })


       // sectio1Api.getSectionFields().then(productstitles=>{ this.productstitles=productstitles.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       //  })



       // sectio1Api.getMap(sectionmap).then(maparam=>{ this.maparam=maparam.data}).catch(error => console.log(error)).finally(() => {this.loading = true
       // })

      // sectio1Api.getSectionWoocommproduct().then(products=>{ this.products=products.data["name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })

      sectio1Api.getSectionField(72, "menu-item-name").then(menu1=>{ this.menu1=menu1.data["menu-item-name"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(72, "menu-item-name-russ").then(menu1r=>{ this.menu1r=menu1r.data["menu-item-name-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(72, "home-text").then(pageone=>{ this.pageone=pageone.data["home-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(72, "home-text-rus").then(hometextrus=>{ this.hometextrus=hometextrus.data["home-text-rus"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(72, "logo").then(barbeqlogo=>{ this.barbeqlogo=barbeqlogo.data["logo"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


      // sectio1Api.getfieldurl().then(projects=>{ this.projects=projects.data}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(72, "home-back-image").then(homeback=>{ this.homeback=homeback.data["home-back-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


      sectio1Api.getSectionField(75, "menu-item2").then(menu2=>{ this.menu2=menu2.data["menu-item2"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "menu-item2-russ").then(menu2r=>{ this.menu2r=menu2r.data["menu-item2-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "slider1-header").then(headerlogo=>{ this.headerlogo=headerlogo.data["slider1-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "slider1-header-russ").then(headerslider1=>{ this.headerslider1=headerslider1.data["slider1-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "slider-1-logo-1").then(slider1logo1=>{ this.slider1logo1=slider1logo1.data["slider-1-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-1-logo-2").then(slider1logo2=>{ this.slider1logo2=slider1logo2.data["slider-1-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-1-logo-3").then(slider1logo3=>{ this.slider1logo3=slider1logo3.data["slider-1-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-1-logo-4").then(slider1logo4=>{ this.slider1logo4=slider1logo4.data["slider-1-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
      sectio1Api.getSectionField(75 , 'slider-1-text').then(headertextsect2=>{ this.headertextsect2=headertextsect2.data["slider-1-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75 , 'slider-1-text-russ').then(headertextsect2rus=>{ this.headertextsect2rus=headertextsect2rus.data["slider-1-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75 , 'slider2-header').then(headertextsect2a=>{ this.headertextsect2a=headertextsect2a.data["slider2-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75 , 'slider2-header-russ').then(headertextsect2aruss=>{ this.headertextsect2aruss=headertextsect2aruss.data["slider2-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "slider-2-logo-1").then(slider2logo1=>{ this.slider2logo1=slider2logo1.data["slider-2-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-2-logo-2")
      .then(slider2logo2=>{ this.slider2logo2=slider2logo2.data["slider-2-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-2-logo-3").then(slider2logo3=>{ this.slider2logo3=slider2logo3.data["slider-2-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-2-logo-4").then(slider2logo4=>{ this.slider2logo4=slider2logo4.data["slider-2-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
      sectio1Api.getSectionField(75, "slider-2-text")
      .then(slider2text=>{ this.slider2text=slider2text.data["slider-2-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75, "slider-2-text-russ")
      .then(slider2textruss=>{ this.slider2textruss=slider2textruss.data["slider-2-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(75 , 'slider3-header')
      .then(headertextsect2b=>{ this.headertextsect2b=headertextsect2b.data["slider3-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


      sectio1Api.getSectionField(75 , 'slider3-header-russ')
      .then(headertextsect2bruss=>{ this.headertextsect2bruss=headertextsect2bruss.data["slider3-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-logo-1").then(slider3logo1=>{ this.slider3logo1=slider3logo1.data["slider-3-logo-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-logo-2")
      .then(slider3logo2=>{ this.slider3logo2=slider3logo2.data["slider-3-logo-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-logo-3")
      .then(slider3logo3=>{ this.slider3logo3=slider3logo3.data["slider-3-logo-3"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-logo-4")
      .then(slider3logo4=>{ this.slider3logo4=slider3logo4.data["slider-3-logo-4"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-text")
      .then(slider3text=>{ this.slider3text=slider3text.data["slider-3-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(75, "slider-3-text-russ")
      .then(slider3textruss=>{ this.slider3textruss=slider3textruss.data["slider-3-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(80, "menu-item3").then(menu3=>{ this.menu3=menu3.data["menu-item3"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(80, "menu-item3-russ").then(menu3r=>{ this.menu3r=menu3r.data["menu-item3-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


      sectio1Api.getSectionField(473, "footer-text").then(footertext=>{ this.footertext=footertext.data["footer-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(473, "footer-text-russ").then(footertextruss=>{ this.footertextruss=footertextruss.data["footer-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })


      sectio1Api.getSectionField(80, "back-image")
      .then(section3backimg=>{ this.section3backimg=section3backimg.data["back-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(80, "section3-image")
      .then(section3img=>{ this.section3img=section3img.data["section3-image"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(80, "section3-header")
      .then(section3header=>{ this.section3header=section3header.data["section3-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(80, "section3-header-russ")
      .then(section3headerruss=>{ this.section3headerruss=section3headerruss.data["section3-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(80, "section3-text")
      .then(section3text=>{ this.section3text=section3text.data["section3-text"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(80, "section3-text-russ")
      .then(section3textruss=>{ this.section3textruss=section3textruss.data["section3-text-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(91, "menu-item4").then(menu4=>{ this.menu4=menu4.data["menu-item4"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(91, "menu-item4-russ").then(menu4r=>{ this.menu4r=menu4r.data["menu-item4-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(91, "section4-back-img")
      .then(section4backimg=>{ this.section4backimg=section4backimg.data["section4-back-img"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(91, "section4-header")
      .then(section4head=>{ this.section4head=section4head.data["section4-header"];})
      .catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(91, "section4-header-russ")
      .then(section4headruss=>{ this.section4headruss=section4headruss.data["section4-header-russ"];})
      .catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(91, "section4-text")
      .then(section4text=>{ this.section4text=section4text.data["section4-text"];})
      .catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(91, "section4-text-russ")
      .then(section4textruss=>{ this.section4textruss=section4textruss.data["section4-text-russ"];})
      .catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(95, "menu-item5").then(menu5=>{ this.menu5=menu5.data["menu-item5"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(95, "menu-item5-russ").then(menu5r=>{ this.menu5r=menu5r.data["menu-item5-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      sectio1Api.getSectionField(95, "section5-back-img")
      .then(section5backimg=>{ this.section5backimg=section5backimg.data["section5-back-img"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-header")
      .then(section5header=>{ this.section5header=section5header.data["section5-header"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-header-russ")
      .then(section5headerruss=>{ this.section5headerruss=section5headerruss.data["section5-header-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-text")
      .then(section5text=>{ this.section5text=section5text.data["section5-text"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-text-russ")
      .then(section5textruss=>{ this.section5textruss=section5textruss.data["section5-text-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-img-1")
      .then(section5img1=>{ this.section5img1=section5img1.data["section5-img-1"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(95, "section5-img-2")
      .then(section5img2=>{ this.section5img2=section5img2.data["section5-img-2"]["url"];}).catch(error => console.log(error)).finally(() => {this.loading = true})
      sectio1Api.getSectionField(95, "section5-img-3")
      .then(section5img3=>{ this.section5img3=section5img3.data["section5-img-3"]["url"];}).catch(error => console.log(error))
      .finally(() => {
        this.loading = true
      })



      sectio1Api.getSectionField(454, "menu-item5a").then(menu5a=>{ this.menu5a=menu5a.data["menu-item5a"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })
      sectio1Api.getSectionField(454, "menu-item5a-russ").then(menu5ar=>{ this.menu5ar=menu5ar.data["menu-item5a-russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      // sectio1Api.getSectionField(454, "category1").then(category1=>{ this.category1=category1.data["category1"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(454, "category1russ").then(category1russ=>{ this.category1russ=category1russ.data["category1russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      // sectio1Api.getSectionField(454, "category2").then(category2=>{ this.category2=category2.data["category2"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(454, "category2russ").then(category2russ=>{ this.category2russ=category2russ.data["category2russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })

      // sectio1Api.getSectionField(454, "category3").then(category3=>{ this.category3=category3.data["category3"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      // })
      sectio1Api.getSectionField(454, "category3russ").then(category3russ=>{ this.category3russ=category3russ.data["category3russ"];}).catch(error => console.log(error)).finally(() => {this.loading = true
      })



      sectio1Api.getSectionField(99, "menu-item6")
      .then(menu6=>{ this.menu6=menu6.data["menu-item6"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(99, "menu-item6-russ")
      .then(menu6r=>{ this.menu6r=menu6r.data["menu-item6-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(99, "section6-header")
      .then(section6header=>{ this.section6header=section6header.data["section6-header"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(99, "section6-header-russ")
      .then(section6headerruss=>{ this.section6headerruss=section6headerruss.data["section6-header-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(99, "section6-text")
      .then(section6text=>{ this.section6text=section6text.data["section6-text"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(99, "section6-text-russ")
      .then(section6textruss=>{ this.section6textruss=section6textruss.data["section6-text-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(99, "section6-img")
      .then(section6img=>{ this.section6img=section6img.data["section6-img"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(102, "menu-item7")
      .then(menu7=>{ this.menu7=menu7.data["menu-item7"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(102, "menu-item7-russ")
      .then(menu7r=>{ this.menu7r=menu7r.data["menu-item7-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(102, "slider1")
      .then(slider1=>{ this.slider1=slider1.data["slider1"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(102, "slider2")
      .then(slider2=>{ this.slider2=slider2.data["slider2"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(102, "slider3").then(slider3=>{ this.slider3=slider3.data["slider3"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(102, "slider4")
      .then(slider4=>{ this.slider4=slider4.data["slider4"]["url"];}).catch(error => console.log(error))
      .finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(105, "menu-item8")
      .then(menu8=>{ this.menu8=menu8.data["menu-item8"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(105, "menu-item8-russ")
      .then(menu8r=>{ this.menu8r=menu8r.data["menu-item8-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(105, "image-left1")
      .then(imgleft1=>{ this.imgleft1=imgleft1.data["image-left1"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "image-left2")
      .then(imgleft2=>{ this.imgleft2=imgleft2.data["image-left2"]["url"];}).catch(error => console.log(error))
      .finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "Image-Right")
      .then(imgright=>{ this.imgright=imgright.data["Image-Right"]["url"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "section8-header")
      .then(section8header=>{ this.section8header=section8header.data["section8-header"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "section8-header-russ")
      .then(section8headerruss=>{ this.section8headerruss=section8headerruss.data["section8-header-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "section8-text")
      .then(section8text=>{ this.section8text=section8text.data["section8-text"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(105, "section8-text-russ")
      .then(section8textruss=>{ this.section8textruss=section8textruss.data["section8-text-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(108, "menu-item9")
      .then(menu9=>{ this.menu9=menu9.data["menu-item9"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(108, "menu-item9-russ")
      .then(menu9r=>{ this.menu9r=menu9r.data["menu-item9-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })


      sectio1Api.getSectionField(108, "section9-header")
      .then(section9header=>{ this.section9header=section9header.data["section9-header"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(108, "section9-header-russ")
      .then(section9headerruss=>{ this.section9headerruss=section9headerruss.data["section9-header-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(108, "section-left-text")
      .then(section9lefttext=>{ this.section9lefttext=section9lefttext.data["section-left-text"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(108, "section-left-text-russ")
      .then(section9lefttextruss=>{ this.section9lefttextruss=section9lefttextruss.data["section-left-text-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
      sectio1Api.getSectionField(108, "section-reft-text")
      .then(section9righttext=>{ this.section9righttext=section9righttext.data["section-reft-text"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      sectio1Api.getSectionField(108, "section-right-text-russ")
      .then(section9righttextruss=>{ this.section9righttextruss=section9righttextruss.data["section-right-text-russ"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })

      // sectio1Api.getSectionField(108, "section-reft-text")
      // .then(section9righttext=>{ this.section9righttext=section9righttext.data["section-reft-text"];}).catch(error => console.log(error)).finally(() => {
      //   this.loading = true
      // })

      sectio1Api.getSectionField(108, "section-map")
      .then(sectionmap=>{ this.sectionmap=sectionmap.data["section-map"];}).catch(error => console.log(error)).finally(() => {
        this.loading = true
      })
    },}</script>


    <style lang="scss">
    #app {font-family: 'Avenir', Helvetica, Arial, sans-serif;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;text-align: center;color: #2c3e50;}
    #nav {padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

</style>
