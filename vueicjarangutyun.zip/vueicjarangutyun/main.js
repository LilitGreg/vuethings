import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// import '.services/api/ml'
// import carousel from 'vue-owl-carousel'
import VueResource from 'vue-resource';
import StaticMap from 'vue-static-map';
import './assets/css/styleb.css';
Vue.use(VueResource);
import axios from 'axios'
import { Hooper, Slide, Navigation as HooperNavigation } from 'hooper'
import 'hooper/dist/hooper.css'
// import VueCarousel from '@chenfengyuan/vue-carousel'
// Vue.component(VueCarousel.name, VueCarousel)
Vue.config.productionTip = false
// export default {
// components: { carousel },}
// import jQuery from  'jquery'
// global.$ = jQuery
window.$ = require('jquery')
window.JQuery = require('jquery')
Vue.config.productionTip = false
new Vue({
  router,
  store,
  render: h => h(App)}).$mount('#app')
