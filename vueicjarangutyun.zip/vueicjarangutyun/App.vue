<template>
  <div id="app" class="page">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/checkout">Checkout</router-link>
        <router-link to="/barbequeproducts"> Products </router-link>
    </div> -->

    <div class="dropdown drop-button">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fa fa-bars"></i>
      </button>
      <div class="dropdown-menu ddmenu" aria-labelledby="dropdownMenuButton">
        <!-- <a    class="dropdown-item" href="/">Homen</a> -->
          <router-link   class="dropdown-item" to="/">Home</router-link>
          <router-link class="dropdown-item" to="/checkout">Checkout</router-link>
            <router-link  class="dropdown-item" to="/barbequeproducts"> Products </router-link>

      </div>
    </div>

    <!-- <div class="dropdown drop-button">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fa fa-bars"></i>
      </button>
      <div class="dropdown-menu ddmenu" aria-labelledby="dropdownMenuButton">

          <router-link   class="dropdown-item" to="/">Home</router-link>
          <router-link class="dropdown-item" to="/checkout">Checkout</router-link>
            <router-link  class="dropdown-item" to="/barbequeproducts"> Products </router-link>

      </div>
    </div> -->
    <!-- <div id="lang_sel_list" class="">
          <ul>
              <li class="icl-en" id="eng-lang">
                 <a href="#eng-lang"  v-on:click="changeenglish()"  class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mug/wp-content/uploads/2019/03/en.png" alt="en" title="English">&nbsp;
                 </a>
              </li>
                <li class="icl-ru" id="ru-lang">
                  <a href="#ru-lang"  v-on:click="changerussion()"   class="lang_sel_other">
                   <img class="iclflag" src="http://localhost/mug/wp-content/uploads/2019/03/ru.png" alt="ru" title="Русский">&nbsp;
                 </a>
              </li>
            </ul>
      </div> -->




<!--
    <div class="vNav">
          <ul class="vNav">
               <li class="animated fadeInDown">
                   <a href="#secton1" class="sect-menu">
                       <div class="labelactive labele">   {{menu1}}</div>
                        <div class="hiden labelr">  {{menu1r}} </div>
                   </a>
               </li>
               <li class="animated fadeInDown">
                   <a href="#section2"   class="sect-menu">
                       <div class="labele" > {{menu2}} </div>
                       <div class="hiden labelr">   {{menu2r}}   </div>
                   </a>
               </li>
               <li class="animated fadeInDown">
                   <a href="#section3"  class="sect-menu">
                       <div class="labele">   {{menu3}} </div>
                        <div class="hiden labelr">     {{menu3r}}  </div>
                   </a>
               </li>
               <li class="animated fadeInDown">
                   <a href="#section4"  class="sect-menu">
                       <div class="labele">  {{menu4}}</div>
                       <div class="hiden labelr">   {{menu4r}}   </div>
                   </a>
               </li>
                <li class="animated fadeInDown">
                   <a href="#section5"  class="sect-menu">
                        <div class="labele">  {{menu5}}</div>
                        <div class="hiden labelr">  {{menu5r}} </div>
                   </a>
               </li>
               <li class="animated fadeInDown">
                  <a href="#section5a"  class="sect-menu">
                      <div class="labele">  {{menu5a}} </div>
                      <div class="hiden labelr">  {{menu5ar}} </div>
                  </a>
              </li>
               <li class="animated fadeInDown">
                  <a href="#section6"  class="sect-menu">
                      <div class="labele"> {{menu6}} </div>
                      <div class="hiden labelr">  {{menu6r}} </div>
                  </a>
              </li>
              <li class="animated fadeInDown">
                 <a href="#section7"  class="sect-menu">
                     <div class="labele"> {{menu7}}</div>
                      <div class="hiden labelr">  {{menu7r}} </div>
                 </a>
             </li>
             <li class="animated fadeInDown">
                <a href="#section8"  class="sect-menu">
                    <div class="labele">{{menu8}}</div>
                    <div class="hiden labelr"> {{menu8r}} </div>
                </a>
            </li>
            <li class="animated fadeInDown">
               <a href="#section9"  class="sect-menu">
                   <div class="labele">{{menu9}}</div>
                   <div class="hiden labelr">{{ menu9r}} </div>
               </a>
           </li>
        </ul>
       </div> -->
    <router-view>


    </router-view>
  </div>
</template>


<script>
export default {
  //name:'getSectionField',
  name:'all',
  components: {

 },

 data() {
   return {

     // carttable : {
     //        delete:"Delete",
     //        thumbnail:"Thumbnail",
     //        product:"Product",
     //        price: "Price",
     //         quantity: "Quantity",
     //         subtotal: "Subtotal",
     //         update: "Update",
     //         totalcart:"Total Cart",
     //         addtocart:"Add to Cart"
     //
     //     },
     //
     // checkouttable : {
     //        billingdetail:"Billing Detail",
     //        firstname: "First Name",
     //        lastname:"Last Name",
     //        companyname:"Company Name",
     //        county:"Country",
     //        selectcountry:"Select Country",
     //        selectoption: "Select an option...",
     //        streetaddress: "Street address",
     //        apartment: "Apartment, suite, unit etc.",
     //        town: "Town / City",
     //        state:"State / County",
     //        postcode:"Postcode/ZIP",
     //        phone: "Phone",
     //        email:"Email Address",
     //        additionalgeneration: "Additional information",
     //        ordernotes: "Order notes (optional)",
     //        yourorder: "Your Order",
     //        total:"Total",
     //        basc:"Direct bank transfer",
     //        bascdesc:"Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
     //        cheque: "Check payments",
     //        chequedesc: "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
     //        cod: "Cash on delivery",
     //        coddesc: "Pay with cash upon delivery.",
     //        paypal:"Paypal",
     //        paypaldesc:"Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
     //        whatispaypal:"What is Paypal?",
     //        placeorder:"Place Order"
     //     }


   }
 },

 methods:{



   // changerussion : function() {
   //             this.carttable.delete = "Удалить";
   //             this.carttable.thumbnail= "Картина";
   //             this.carttable.product= "Товар";
   //             this.carttable.price= "Чена";
   //             this.carttable.quantity= "Количество";
   //             this.carttable.subtotal= "Подуровень";
   //             this.carttable.update= "Обновить";
   //             this.carttable.totalcart = "Общая Корзина",
   //             this.carttable.addtocart ="Добавить в Корзину",
   //             this.checkouttable.billingdetail="Платежная информация",
   //             this.checkouttable.firstname="Имя",
   //             this.checkouttable.lastname="Фамилия",
   //             this.checkouttable.companyname="Название Компании",
   //             this.checkouttable.county="Страна",
   //             this.checkouttable.selectcountry= "Выберите страну...",
   //             this.checkouttable.selectoption="Выберите опцию ...",
   //             this.checkouttable.streetaddress="Адрес улицы",
   //             this.checkouttable.apartment="Квартира, люкс, блок и т. Д.",
   //             this.checkouttable.town="Город",
   //             this.checkouttable.state="Штат / Страна",
   //             this.checkouttable.postcode="Почтовый индекс",
   //             this.checkouttable.phone="Телефон",
   //             this.checkouttable.email="Эл. адрес",
   //             this.checkouttable.additionalgeneration= "Дополнительная информация",
   //             this.checkouttable.ordernotes = "Примечания к заказу (необязательно)",
   //             this.checkouttable.yourorder ="Твоя очередь",
   //             this.checkouttable.total ="Сумма",
   //             this.checkouttable.basc= "Прямой банковский перевод",
   //             this.checkouttable.bascdesc= "Внесите платеж прямо на наш банковский счет. Пожалуйста, используйте ваш идентификатор заказа в качестве ссылки для оплаты. Ваш заказ не будет отправлен, пока средства не будут очищены на нашем счете.",
   //             this.checkouttable.cheque= "Проверить платежи",
   //             this.checkouttable.chequedesc= "Пожалуйста, отправьте чек в Название магазина, Улица магазина, Город магазина, Штат Штат / округ, Почтовый индекс магазина.",
   //             this.checkouttable.cod= "Оплата при доставке",
   //             this.checkouttable.coddesc= "Оплата наличными при доставке.",
   //             this.checkouttable.paypal= "Пайпал",
   //             this.checkouttable.paypaldesc= "Оплатить через Пайпал; Вы можете оплатить с помощью кредитной карты, если у вас нет учетной записи Пайпал.",
   //             this.checkouttable.whatispaypal= "Что такое Пайпал?",
   //             this.checkouttable.placeorder ="Разместить заказ"
   //
   //         },
   // changeenglish : function() {
   //       this.carttable.delete = "Delete";
   //       this.carttable.thumbnail= "Thumbnail";
   //       this.carttable.product= "Product";
   //       this.carttable.price= "Price";
   //       this.carttable.quantity= "Quantity";
   //       this.carttable.subtotal= "Subtotal";
   //       this.carttable.update= "Update";
   //       this.carttable.totalcart = "Total Cart",
   //       this.carttable.addtocart ="Add to Cart",
   //       this.checkouttable.billingdetail="Billing Detail",
   //       this.checkouttable.firstname="First Name",
   //       this.checkouttable.lastname="Last Name",
   //       this.checkouttable.companyname="Company Name",
   //       this.checkouttable.county="Country",
   //       this.checkouttable.selectcountry= "Select Country ...",
   //       this.checkouttable.selectoption="Select an option ...",
   //       this.checkouttable.streetaddress="Street address",
   //       this.checkouttable.apartment="Apartment, suite, unit etc.",
   //       this.checkouttable.town="Town / City",
   //       this.checkouttable.state="State / County",
   //       this.checkouttable.postcode="Postcode/ZIP",
   //       this.checkouttable.phone="Phone",
   //       this.checkouttable.email="Email Address",
   //       this.checkouttable.additionalgeneration="Additional Information",
   //       this.checkouttable.ordernotes ="Order notes (optional)",
   //       this.checkouttable.yourorder ="Your Order"
   //       this.checkouttable.total ="Total",
   //       this.checkouttable.basc= "Direct bank transfer",
   //       this.checkouttable.bascdesc= "Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.",
   //       this.checkouttable.cheque= "Check payments",
   //       this.checkouttable.chequedesc= "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.",
   //       this.checkouttable.cod= "Cash on delivery",
   //       this.checkouttable.coddesc= "Pay with cash upon delivery.",
   //       this.checkouttable.paypal= "Paypal",
   //       this.checkouttable.paypaldesc= "Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.",
   //       this.checkouttable.whatispaypal= "What is Paypal?",
   //       this.checkouttable.placeorder ="Place Order"
   //
   // }


 }
}


</script>
